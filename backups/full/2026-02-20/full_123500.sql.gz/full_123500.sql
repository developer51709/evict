--
-- PostgreSQL database dump
--

-- Dumped from database version 16.10
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY ticket.button DROP CONSTRAINT IF EXISTS button_guild_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_items DROP CONSTRAINT IF EXISTS user_items_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.starboard_entry DROP CONSTRAINT IF EXISTS starboard_entry_guild_id_emoji_fkey;
ALTER TABLE IF EXISTS ONLY public.poll_votes DROP CONSTRAINT IF EXISTS poll_votes_poll_id_fkey;
ALTER TABLE IF EXISTS ONLY public.employee_stats DROP CONSTRAINT IF EXISTS employee_stats_business_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contracts DROP CONSTRAINT IF EXISTS contracts_business_id_fkey;
ALTER TABLE IF EXISTS ONLY public.clownboard_entry DROP CONSTRAINT IF EXISTS clownboard_entry_guild_id_emoji_fkey;
ALTER TABLE IF EXISTS ONLY public.business_stats DROP CONSTRAINT IF EXISTS business_stats_business_id_fkey;
ALTER TABLE IF EXISTS ONLY public.business_jobs DROP CONSTRAINT IF EXISTS business_jobs_business_id_fkey;
ALTER TABLE IF EXISTS ONLY music.playlist_tracks DROP CONSTRAINT IF EXISTS playlist_tracks_playlist_id_fkey;
ALTER TABLE IF EXISTS ONLY level.role DROP CONSTRAINT IF EXISTS role_guild_id_fkey;
ALTER TABLE IF EXISTS ONLY level.notification DROP CONSTRAINT IF EXISTS notification_guild_id_fkey;
ALTER TABLE IF EXISTS ONLY level.member DROP CONSTRAINT IF EXISTS member_guild_id_fkey;
ALTER TABLE IF EXISTS ONLY level.config DROP CONSTRAINT IF EXISTS config_guild_id_fkey;
ALTER TABLE IF EXISTS ONLY lastfm.tracks DROP CONSTRAINT IF EXISTS tracks_user_id_fkey;
ALTER TABLE IF EXISTS ONLY lastfm.crowns DROP CONSTRAINT IF EXISTS crowns_user_id_artist_fkey;
ALTER TABLE IF EXISTS ONLY lastfm.artists DROP CONSTRAINT IF EXISTS artists_user_id_fkey;
ALTER TABLE IF EXISTS ONLY lastfm.albums DROP CONSTRAINT IF EXISTS albums_user_id_fkey;
ALTER TABLE IF EXISTS ONLY voicemaster.configuration DROP CONSTRAINT IF EXISTS configuration_pkey;
ALTER TABLE IF EXISTS ONLY voicemaster.channels DROP CONSTRAINT IF EXISTS channels_pkey;
ALTER TABLE IF EXISTS ONLY voice.config DROP CONSTRAINT IF EXISTS config_guild_id_key;
ALTER TABLE IF EXISTS ONLY voice.channels DROP CONSTRAINT IF EXISTS channels_pkey;
ALTER TABLE IF EXISTS ONLY verification.settings DROP CONSTRAINT IF EXISTS settings_pkey;
ALTER TABLE IF EXISTS ONLY verification.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY verification.logs DROP CONSTRAINT IF EXISTS logs_pkey;
ALTER TABLE IF EXISTS ONLY transcribe.rate_limit DROP CONSTRAINT IF EXISTS rate_limit_pkey;
ALTER TABLE IF EXISTS ONLY transcribe.channels DROP CONSTRAINT IF EXISTS channels_pkey;
ALTER TABLE IF EXISTS ONLY track.vanity DROP CONSTRAINT IF EXISTS vanity_pkey;
ALTER TABLE IF EXISTS ONLY track.username DROP CONSTRAINT IF EXISTS username_pkey;
ALTER TABLE IF EXISTS ONLY timer.purge DROP CONSTRAINT IF EXISTS purge_pkey;
ALTER TABLE IF EXISTS ONLY timer.message DROP CONSTRAINT IF EXISTS message_pkey;
ALTER TABLE IF EXISTS ONLY ticket.open DROP CONSTRAINT IF EXISTS open_pkey;
ALTER TABLE IF EXISTS ONLY ticket.config DROP CONSTRAINT IF EXISTS config_guild_id_key;
ALTER TABLE IF EXISTS ONLY ticket.button DROP CONSTRAINT IF EXISTS button_pkey;
ALTER TABLE IF EXISTS ONLY streaks.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY streaks.restore_log DROP CONSTRAINT IF EXISTS restore_log_pkey;
ALTER TABLE IF EXISTS ONLY streaks.config DROP CONSTRAINT IF EXISTS config_pkey;
ALTER TABLE IF EXISTS ONLY stats.word_usage DROP CONSTRAINT IF EXISTS word_usage_pkey;
ALTER TABLE IF EXISTS ONLY stats.custom_commands DROP CONSTRAINT IF EXISTS custom_commands_pkey;
ALTER TABLE IF EXISTS ONLY stats.config DROP CONSTRAINT IF EXISTS config_pkey;
ALTER TABLE IF EXISTS ONLY statistics.daily DROP CONSTRAINT IF EXISTS daily_pkey;
ALTER TABLE IF EXISTS ONLY statistics.daily_channels DROP CONSTRAINT IF EXISTS daily_channels_pkey;
ALTER TABLE IF EXISTS ONLY snipe.ignore DROP CONSTRAINT IF EXISTS ignore_pkey;
ALTER TABLE IF EXISTS ONLY snipe.filter DROP CONSTRAINT IF EXISTS filter_guild_id_key;
ALTER TABLE IF EXISTS ONLY reskin.webhook DROP CONSTRAINT IF EXISTS webhook_pkey;
ALTER TABLE IF EXISTS ONLY reskin.config DROP CONSTRAINT IF EXISTS config_user_id_key;
ALTER TABLE IF EXISTS ONLY reposters.disabled DROP CONSTRAINT IF EXISTS disabled_pkey;
ALTER TABLE IF EXISTS ONLY public.whitelist DROP CONSTRAINT IF EXISTS whitelist_guild_id_key;
ALTER TABLE IF EXISTS ONLY public.welcome_message DROP CONSTRAINT IF EXISTS welcome_message_pkey;
ALTER TABLE IF EXISTS ONLY public.webhook DROP CONSTRAINT IF EXISTS webhook_pkey;
ALTER TABLE IF EXISTS ONLY public.warn_actions DROP CONSTRAINT IF EXISTS warn_actions_guild_id_threshold_key;
ALTER TABLE IF EXISTS ONLY public.vape DROP CONSTRAINT IF EXISTS vape_pkey;
ALTER TABLE IF EXISTS ONLY public.vanity_sniper DROP CONSTRAINT IF EXISTS vanity_sniper_guild_id_key;
ALTER TABLE IF EXISTS ONLY public.vanity DROP CONSTRAINT IF EXISTS vanity_guild_id_key;
ALTER TABLE IF EXISTS ONLY public.user_transactions DROP CONSTRAINT IF EXISTS user_transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.user_items DROP CONSTRAINT IF EXISTS user_items_user_id_item_id_key;
ALTER TABLE IF EXISTS ONLY public.user_cards DROP CONSTRAINT IF EXISTS user_cards_user_id_card_id_key;
ALTER TABLE IF EXISTS ONLY public.tracker DROP CONSTRAINT IF EXISTS tracker_pkey;
ALTER TABLE IF EXISTS ONLY public.timezones DROP CONSTRAINT IF EXISTS timezones_user_id_key;
ALTER TABLE IF EXISTS ONLY public.thread DROP CONSTRAINT IF EXISTS thread_pkey;
ALTER TABLE IF EXISTS ONLY public.tags DROP CONSTRAINT IF EXISTS tags_guild_id_name_key;
ALTER TABLE IF EXISTS ONLY public.tag_aliases DROP CONSTRAINT IF EXISTS tag_aliases_guild_id_alias_key;
ALTER TABLE IF EXISTS ONLY public.suggestion_votes DROP CONSTRAINT IF EXISTS suggestion_votes_message_id_user_id_key;
ALTER TABLE IF EXISTS ONLY public.sticky_message DROP CONSTRAINT IF EXISTS sticky_message_pkey;
ALTER TABLE IF EXISTS ONLY public.starboard DROP CONSTRAINT IF EXISTS starboard_pkey;
ALTER TABLE IF EXISTS ONLY public.starboard_entry DROP CONSTRAINT IF EXISTS starboard_entry_pkey;
ALTER TABLE IF EXISTS ONLY public.socials_saved_gradients DROP CONSTRAINT IF EXISTS socials_saved_gradients_pkey;
ALTER TABLE IF EXISTS ONLY public.socials_saved_colors DROP CONSTRAINT IF EXISTS socials_saved_colors_user_id_name_key;
ALTER TABLE IF EXISTS ONLY public.socials DROP CONSTRAINT IF EXISTS socials_pkey;
ALTER TABLE IF EXISTS ONLY public.socials_gradients DROP CONSTRAINT IF EXISTS socials_gradients_pkey;
ALTER TABLE IF EXISTS ONLY public.social_links DROP CONSTRAINT IF EXISTS social_links_user_id_type_key;
ALTER TABLE IF EXISTS ONLY public.social_links DROP CONSTRAINT IF EXISTS social_links_pkey;
ALTER TABLE IF EXISTS ONLY public.shop_items DROP CONSTRAINT IF EXISTS shop_items_pkey;
ALTER TABLE IF EXISTS ONLY public.shop_items DROP CONSTRAINT IF EXISTS shop_items_name_key;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_pkey;
ALTER TABLE IF EXISTS ONLY public.roleplay DROP CONSTRAINT IF EXISTS roleplay_pkey;
ALTER TABLE IF EXISTS ONLY public.role_shops DROP CONSTRAINT IF EXISTS role_shops_pkey;
ALTER TABLE IF EXISTS ONLY public.response_trigger DROP CONSTRAINT IF EXISTS response_trigger_pkey;
ALTER TABLE IF EXISTS ONLY public.reskin DROP CONSTRAINT IF EXISTS reskin_pkey;
ALTER TABLE IF EXISTS ONLY public.reaction_trigger DROP CONSTRAINT IF EXISTS reaction_trigger_pkey;
ALTER TABLE IF EXISTS ONLY public.reaction_role DROP CONSTRAINT IF EXISTS reaction_role_pkey;
ALTER TABLE IF EXISTS ONLY public.quoter DROP CONSTRAINT IF EXISTS quoter_guild_id_key;
ALTER TABLE IF EXISTS ONLY public.pubsub DROP CONSTRAINT IF EXISTS pubsub_id_key;
ALTER TABLE IF EXISTS ONLY public.publisher DROP CONSTRAINT IF EXISTS publisher_pkey;
ALTER TABLE IF EXISTS ONLY public.prefix DROP CONSTRAINT IF EXISTS prefix_pkey;
ALTER TABLE IF EXISTS ONLY public.polls DROP CONSTRAINT IF EXISTS polls_pkey;
ALTER TABLE IF EXISTS ONLY public.poll_votes DROP CONSTRAINT IF EXISTS poll_votes_poll_id_user_id_key;
ALTER TABLE IF EXISTS ONLY public.poll_votes DROP CONSTRAINT IF EXISTS poll_votes_pkey;
ALTER TABLE IF EXISTS ONLY public.pets DROP CONSTRAINT IF EXISTS pets_pkey;
ALTER TABLE IF EXISTS ONLY public.pet_trades DROP CONSTRAINT IF EXISTS pet_trades_pkey;
ALTER TABLE IF EXISTS ONLY public.pet_adventures DROP CONSTRAINT IF EXISTS pet_adventures_pkey;
ALTER TABLE IF EXISTS ONLY public.payment DROP CONSTRAINT IF EXISTS payment_guild_id_key;
ALTER TABLE IF EXISTS ONLY public.message_ranks DROP CONSTRAINT IF EXISTS message_ranks_pkey;
ALTER TABLE IF EXISTS ONLY public.member_stats DROP CONSTRAINT IF EXISTS member_stats_pkey;
ALTER TABLE IF EXISTS ONLY public.lovense_devices DROP CONSTRAINT IF EXISTS lovense_devices_pkey;
ALTER TABLE IF EXISTS ONLY public.lovense_consent DROP CONSTRAINT IF EXISTS lovense_consent_pkey;
ALTER TABLE IF EXISTS ONLY public.lovense_config DROP CONSTRAINT IF EXISTS lovense_config_pkey;
ALTER TABLE IF EXISTS ONLY public.lottery_history DROP CONSTRAINT IF EXISTS lottery_history_pkey;
ALTER TABLE IF EXISTS ONLY public.logging DROP CONSTRAINT IF EXISTS logging_pkey;
ALTER TABLE IF EXISTS ONLY public.logging_history DROP CONSTRAINT IF EXISTS logging_history_pkey;
ALTER TABLE IF EXISTS ONLY public.jobs DROP CONSTRAINT IF EXISTS jobs_pkey;
ALTER TABLE IF EXISTS ONLY public.job_applications DROP CONSTRAINT IF EXISTS job_applications_pkey;
ALTER TABLE IF EXISTS ONLY public.invite_tracking DROP CONSTRAINT IF EXISTS invite_tracking_pkey;
ALTER TABLE IF EXISTS ONLY public.invite_stats DROP CONSTRAINT IF EXISTS invite_stats_pkey;
ALTER TABLE IF EXISTS ONLY public.invite_rewards DROP CONSTRAINT IF EXISTS invite_rewards_pkey;
ALTER TABLE IF EXISTS ONLY public.invite_config DROP CONSTRAINT IF EXISTS invite_config_pkey;
ALTER TABLE IF EXISTS ONLY public.incidents DROP CONSTRAINT IF EXISTS incidents_pkey;
ALTER TABLE IF EXISTS ONLY public.hourly_metrics DROP CONSTRAINT IF EXISTS hourly_metrics_pkey;
ALTER TABLE IF EXISTS ONLY public.highlights DROP CONSTRAINT IF EXISTS highlights_pkey;
ALTER TABLE IF EXISTS ONLY public.hardban DROP CONSTRAINT IF EXISTS hardban_pkey;
ALTER TABLE IF EXISTS ONLY public.guildblacklist DROP CONSTRAINT IF EXISTS guildblacklist_guild_id_key;
ALTER TABLE IF EXISTS ONLY public.guild_verification DROP CONSTRAINT IF EXISTS guild_verification_pkey;
ALTER TABLE IF EXISTS ONLY public.goodbye_message DROP CONSTRAINT IF EXISTS goodbye_message_pkey;
ALTER TABLE IF EXISTS ONLY public.giveaway_settings DROP CONSTRAINT IF EXISTS giveaway_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.gift_logs DROP CONSTRAINT IF EXISTS gift_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.gallery DROP CONSTRAINT IF EXISTS gallery_pkey;
ALTER TABLE IF EXISTS ONLY public.forcenick DROP CONSTRAINT IF EXISTS forcenick_pkey;
ALTER TABLE IF EXISTS ONLY public.feedback DROP CONSTRAINT IF EXISTS feedback_pkey;
ALTER TABLE IF EXISTS ONLY public.fake_permissions DROP CONSTRAINT IF EXISTS fake_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.employee_stats DROP CONSTRAINT IF EXISTS employee_stats_pkey;
ALTER TABLE IF EXISTS ONLY public.economy DROP CONSTRAINT IF EXISTS economy_pkey;
ALTER TABLE IF EXISTS ONLY public.economy_access DROP CONSTRAINT IF EXISTS economy_access_pkey;
ALTER TABLE IF EXISTS ONLY public.donators DROP CONSTRAINT IF EXISTS donators_pkey;
ALTER TABLE IF EXISTS ONLY public.dockets DROP CONSTRAINT IF EXISTS dockets_pkey;
ALTER TABLE IF EXISTS ONLY public.docket_channels DROP CONSTRAINT IF EXISTS docket_channels_pkey;
ALTER TABLE IF EXISTS ONLY public.dalle_credits DROP CONSTRAINT IF EXISTS dalle_credits_pkey;
ALTER TABLE IF EXISTS ONLY public.daily_stats DROP CONSTRAINT IF EXISTS daily_stats_pkey;
ALTER TABLE IF EXISTS ONLY public.daily_metrics DROP CONSTRAINT IF EXISTS daily_metrics_pkey;
ALTER TABLE IF EXISTS ONLY public.daily_messages DROP CONSTRAINT IF EXISTS daily_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.crypto DROP CONSTRAINT IF EXISTS crypto_pkey;
ALTER TABLE IF EXISTS ONLY public.counter DROP CONSTRAINT IF EXISTS counter_pkey;
ALTER TABLE IF EXISTS ONLY public.contracts DROP CONSTRAINT IF EXISTS contracts_pkey;
ALTER TABLE IF EXISTS ONLY public.contracts DROP CONSTRAINT IF EXISTS contracts_employee_id_key;
ALTER TABLE IF EXISTS ONLY public.config DROP CONSTRAINT IF EXISTS config_pkey;
ALTER TABLE IF EXISTS ONLY public.clownboard DROP CONSTRAINT IF EXISTS clownboard_pkey;
ALTER TABLE IF EXISTS ONLY public.clownboard_entry DROP CONSTRAINT IF EXISTS clownboard_entry_pkey;
ALTER TABLE IF EXISTS ONLY public.card_market DROP CONSTRAINT IF EXISTS card_market_pkey;
ALTER TABLE IF EXISTS ONLY public.card_drop_channels DROP CONSTRAINT IF EXISTS card_drop_channels_pkey;
ALTER TABLE IF EXISTS ONLY public.card_daily DROP CONSTRAINT IF EXISTS card_daily_pkey;
ALTER TABLE IF EXISTS ONLY public.businesses DROP CONSTRAINT IF EXISTS businesses_pkey;
ALTER TABLE IF EXISTS ONLY public.businesses DROP CONSTRAINT IF EXISTS businesses_owner_id_key;
ALTER TABLE IF EXISTS ONLY public.businesses DROP CONSTRAINT IF EXISTS businesses_name_key;
ALTER TABLE IF EXISTS ONLY public.business_stats DROP CONSTRAINT IF EXISTS business_stats_pkey;
ALTER TABLE IF EXISTS ONLY public.business_jobs DROP CONSTRAINT IF EXISTS business_jobs_pkey;
ALTER TABLE IF EXISTS ONLY public.boosters_lost DROP CONSTRAINT IF EXISTS boosters_lost_pkey;
ALTER TABLE IF EXISTS ONLY public.booster_role DROP CONSTRAINT IF EXISTS booster_role_pkey;
ALTER TABLE IF EXISTS ONLY public.boost_message DROP CONSTRAINT IF EXISTS boost_message_pkey;
ALTER TABLE IF EXISTS ONLY public.boost_history DROP CONSTRAINT IF EXISTS boost_history_pkey;
ALTER TABLE IF EXISTS ONLY public.blunt DROP CONSTRAINT IF EXISTS blunt_pkey;
ALTER TABLE IF EXISTS ONLY public.blacklist DROP CONSTRAINT IF EXISTS blacklist_user_id_key;
ALTER TABLE IF EXISTS ONLY public.birthdays DROP CONSTRAINT IF EXISTS birthdays_user_id_key;
ALTER TABLE IF EXISTS ONLY public.beta_dashboard DROP CONSTRAINT IF EXISTS beta_dashboard_pkey;
ALTER TABLE IF EXISTS ONLY public.backup DROP CONSTRAINT IF EXISTS backup_pkey;
ALTER TABLE IF EXISTS ONLY public.avatar_history DROP CONSTRAINT IF EXISTS avatar_history_user_id_avatar_url_key;
ALTER TABLE IF EXISTS ONLY public.avatar_history_settings DROP CONSTRAINT IF EXISTS avatar_history_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.avatar_current DROP CONSTRAINT IF EXISTS avatar_current_pkey;
ALTER TABLE IF EXISTS ONLY public.auto_role DROP CONSTRAINT IF EXISTS auto_role_pkey;
ALTER TABLE IF EXISTS ONLY public.appeals DROP CONSTRAINT IF EXISTS appeals_pkey;
ALTER TABLE IF EXISTS ONLY public.appeal_templates DROP CONSTRAINT IF EXISTS appeal_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.appeal_config DROP CONSTRAINT IF EXISTS appeal_config_pkey;
ALTER TABLE IF EXISTS ONLY public.antiraid DROP CONSTRAINT IF EXISTS antiraid_pkey;
ALTER TABLE IF EXISTS ONLY public.antinuke DROP CONSTRAINT IF EXISTS antinuke_guild_id_key;
ALTER TABLE IF EXISTS ONLY public.aliases DROP CONSTRAINT IF EXISTS aliases_pkey;
ALTER TABLE IF EXISTS ONLY public.afk DROP CONSTRAINT IF EXISTS afk_user_id_key;
ALTER TABLE IF EXISTS ONLY public.access_tokens DROP CONSTRAINT IF EXISTS access_tokens_pkey;
ALTER TABLE IF EXISTS ONLY porn.config DROP CONSTRAINT IF EXISTS config_pkey;
ALTER TABLE IF EXISTS ONLY music.playlists DROP CONSTRAINT IF EXISTS playlists_pkey;
ALTER TABLE IF EXISTS ONLY music.playlist_tracks DROP CONSTRAINT IF EXISTS playlist_tracks_pkey;
ALTER TABLE IF EXISTS ONLY music.history DROP CONSTRAINT IF EXISTS history_pkey;
ALTER TABLE IF EXISTS ONLY level.role DROP CONSTRAINT IF EXISTS role_role_id_key;
ALTER TABLE IF EXISTS ONLY level.role DROP CONSTRAINT IF EXISTS role_pkey;
ALTER TABLE IF EXISTS ONLY level.notification DROP CONSTRAINT IF EXISTS notification_pkey;
ALTER TABLE IF EXISTS ONLY level.member DROP CONSTRAINT IF EXISTS member_pkey;
ALTER TABLE IF EXISTS ONLY level.config DROP CONSTRAINT IF EXISTS config_guild_id_key;
ALTER TABLE IF EXISTS ONLY lastfm.tracks DROP CONSTRAINT IF EXISTS tracks_pkey;
ALTER TABLE IF EXISTS ONLY lastfm.hidden DROP CONSTRAINT IF EXISTS hidden_pkey;
ALTER TABLE IF EXISTS ONLY lastfm.crowns DROP CONSTRAINT IF EXISTS crowns_pkey;
ALTER TABLE IF EXISTS ONLY lastfm.crown_updates DROP CONSTRAINT IF EXISTS crown_updates_pkey;
ALTER TABLE IF EXISTS ONLY lastfm.config DROP CONSTRAINT IF EXISTS config_user_id_key;
ALTER TABLE IF EXISTS ONLY lastfm.artists DROP CONSTRAINT IF EXISTS artists_pkey;
ALTER TABLE IF EXISTS ONLY lastfm.albums DROP CONSTRAINT IF EXISTS albums_pkey;
ALTER TABLE IF EXISTS ONLY joindm.config DROP CONSTRAINT IF EXISTS config_pkey;
ALTER TABLE IF EXISTS ONLY invoke_history.commands DROP CONSTRAINT IF EXISTS commands_pkey;
ALTER TABLE IF EXISTS ONLY history.moderation DROP CONSTRAINT IF EXISTS moderation_pkey;
ALTER TABLE IF EXISTS ONLY fun.wyr_channels DROP CONSTRAINT IF EXISTS wyr_channels_pkey;
ALTER TABLE IF EXISTS ONLY fortnite.rotation DROP CONSTRAINT IF EXISTS rotation_guild_id_key;
ALTER TABLE IF EXISTS ONLY fortnite.reminder DROP CONSTRAINT IF EXISTS reminder_pkey;
ALTER TABLE IF EXISTS ONLY fortnite."authorization" DROP CONSTRAINT IF EXISTS authorization_user_id_key;
ALTER TABLE IF EXISTS ONLY feeds.youtube DROP CONSTRAINT IF EXISTS youtube_pkey;
ALTER TABLE IF EXISTS ONLY feeds.twitter DROP CONSTRAINT IF EXISTS twitter_pkey;
ALTER TABLE IF EXISTS ONLY feeds.tiktok DROP CONSTRAINT IF EXISTS tiktok_pkey;
ALTER TABLE IF EXISTS ONLY feeds.soundcloud DROP CONSTRAINT IF EXISTS soundcloud_pkey;
ALTER TABLE IF EXISTS ONLY feeds.reddit DROP CONSTRAINT IF EXISTS reddit_pkey;
ALTER TABLE IF EXISTS ONLY feeds.pinterest DROP CONSTRAINT IF EXISTS pinterest_pkey;
ALTER TABLE IF EXISTS ONLY feeds.instagram DROP CONSTRAINT IF EXISTS instagram_pkey;
ALTER TABLE IF EXISTS ONLY family.profiles DROP CONSTRAINT IF EXISTS profiles_pkey;
ALTER TABLE IF EXISTS ONLY family.members DROP CONSTRAINT IF EXISTS members_pkey;
ALTER TABLE IF EXISTS ONLY family.marriages DROP CONSTRAINT IF EXISTS marriages_pkey;
ALTER TABLE IF EXISTS ONLY economy_schema.transactions DROP CONSTRAINT IF EXISTS transactions_pkey;
ALTER TABLE IF EXISTS ONLY economy.transactions DROP CONSTRAINT IF EXISTS transactions_pkey;
ALTER TABLE IF EXISTS ONLY disboard.config DROP CONSTRAINT IF EXISTS config_guild_id_key;
ALTER TABLE IF EXISTS ONLY counting.config DROP CONSTRAINT IF EXISTS config_pkey;
ALTER TABLE IF EXISTS ONLY commands.restricted DROP CONSTRAINT IF EXISTS restricted_pkey;
ALTER TABLE IF EXISTS ONLY commands.ignore DROP CONSTRAINT IF EXISTS ignore_pkey;
ALTER TABLE IF EXISTS ONLY commands.disabled DROP CONSTRAINT IF EXISTS disabled_pkey;
ALTER TABLE IF EXISTS ONLY auto.media DROP CONSTRAINT IF EXISTS unique_media_config;
ALTER TABLE IF EXISTS ONLY auto.media DROP CONSTRAINT IF EXISTS media_pkey;
ALTER TABLE IF EXISTS ONLY audio.statistics DROP CONSTRAINT IF EXISTS statistics_pkey;
ALTER TABLE IF EXISTS ONLY audio.recently_played DROP CONSTRAINT IF EXISTS recently_played_pkey;
ALTER TABLE IF EXISTS ONLY audio.playlists DROP CONSTRAINT IF EXISTS playlists_pkey;
ALTER TABLE IF EXISTS ONLY audio.playlists DROP CONSTRAINT IF EXISTS playlists_guild_id_user_id_playlist_url_key;
ALTER TABLE IF EXISTS ONLY audio.playlist_tracks DROP CONSTRAINT IF EXISTS playlist_tracks_pkey;
ALTER TABLE IF EXISTS ONLY audio.playlist_tracks DROP CONSTRAINT IF EXISTS playlist_tracks_guild_id_user_id_playlist_url_track_uri_key;
ALTER TABLE IF EXISTS ONLY audio.config DROP CONSTRAINT IF EXISTS config_guild_id_key;
ALTER TABLE IF EXISTS ONLY alerts.twitch DROP CONSTRAINT IF EXISTS twitch_pkey;
ALTER TABLE IF EXISTS verification.logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS streaks.restore_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_transactions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.socials_saved_gradients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.socials_gradients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.social_links ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.shop_items ALTER COLUMN item_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.poll_votes ALTER COLUMN vote_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.pets ALTER COLUMN pet_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.pet_trades ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.pet_adventures ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.lottery_history ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.logging_history ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.job_applications ALTER COLUMN application_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.gift_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.dockets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.card_market ALTER COLUMN listing_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.businesses ALTER COLUMN business_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.business_jobs ALTER COLUMN job_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.appeals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS music.playlists ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS music.playlist_tracks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS music.history ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS invoke_history.commands ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS history.moderation ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS economy_schema.transactions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS economy.transactions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS auto.media ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS audio.recently_played ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS audio.playlists ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS audio.playlist_tracks ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS voicemaster.configuration;
DROP TABLE IF EXISTS voicemaster.channels;
DROP TABLE IF EXISTS voice.config;
DROP TABLE IF EXISTS voice.channels;
DROP TABLE IF EXISTS verification.settings;
DROP TABLE IF EXISTS verification.sessions;
DROP SEQUENCE IF EXISTS verification.logs_id_seq;
DROP TABLE IF EXISTS verification.logs;
DROP TABLE IF EXISTS transcribe.rate_limit;
DROP TABLE IF EXISTS transcribe.channels;
DROP TABLE IF EXISTS track.vanity;
DROP TABLE IF EXISTS track.username;
DROP TABLE IF EXISTS timer.purge;
DROP TABLE IF EXISTS timer.message;
DROP TABLE IF EXISTS ticket.open;
DROP TABLE IF EXISTS ticket.config;
DROP TABLE IF EXISTS ticket.button;
DROP TABLE IF EXISTS streaks.users;
DROP SEQUENCE IF EXISTS streaks.restore_log_id_seq;
DROP TABLE IF EXISTS streaks.restore_log;
DROP TABLE IF EXISTS streaks.config;
DROP TABLE IF EXISTS stats.word_usage;
DROP TABLE IF EXISTS stats.custom_commands;
DROP TABLE IF EXISTS stats.config;
DROP TABLE IF EXISTS statistics.daily_channels;
DROP TABLE IF EXISTS statistics.daily;
DROP TABLE IF EXISTS snipe.ignore;
DROP TABLE IF EXISTS snipe.filter;
DROP TABLE IF EXISTS reskin.webhook;
DROP TABLE IF EXISTS reskin.config;
DROP TABLE IF EXISTS reposters.disabled;
DROP TABLE IF EXISTS public.whitelist;
DROP TABLE IF EXISTS public.welcome_message;
DROP TABLE IF EXISTS public.webhook;
DROP TABLE IF EXISTS public.warn_actions;
DROP TABLE IF EXISTS public.vape;
DROP TABLE IF EXISTS public.vanity_sniper;
DROP TABLE IF EXISTS public.vanity;
DROP TABLE IF EXISTS public.uwulock;
DROP SEQUENCE IF EXISTS public.user_transactions_id_seq;
DROP TABLE IF EXISTS public.user_transactions;
DROP TABLE IF EXISTS public.user_items;
DROP TABLE IF EXISTS public.user_cards;
DROP TABLE IF EXISTS public.tracker;
DROP TABLE IF EXISTS public.timezones;
DROP TABLE IF EXISTS public.thread;
DROP TABLE IF EXISTS public.tags;
DROP TABLE IF EXISTS public.tag_aliases;
DROP TABLE IF EXISTS public.suggestion_votes;
DROP TABLE IF EXISTS public.suggestion_entries;
DROP TABLE IF EXISTS public.suggestion;
DROP TABLE IF EXISTS public.sticky_message;
DROP TABLE IF EXISTS public.starboard_entry;
DROP TABLE IF EXISTS public.starboard;
DROP SEQUENCE IF EXISTS public.socials_saved_gradients_id_seq;
DROP TABLE IF EXISTS public.socials_saved_gradients;
DROP TABLE IF EXISTS public.socials_saved_colors;
DROP SEQUENCE IF EXISTS public.socials_gradients_id_seq;
DROP TABLE IF EXISTS public.socials_gradients;
DROP TABLE IF EXISTS public.socials_details;
DROP TABLE IF EXISTS public.socials;
DROP SEQUENCE IF EXISTS public.social_links_id_seq;
DROP TABLE IF EXISTS public.social_links;
DROP TABLE IF EXISTS public.shutup;
DROP SEQUENCE IF EXISTS public.shop_items_item_id_seq;
DROP TABLE IF EXISTS public.shop_items;
DROP TABLE IF EXISTS public.settings;
DROP TABLE IF EXISTS public.selfprefix;
DROP TABLE IF EXISTS public.roleplay;
DROP TABLE IF EXISTS public.role_shops;
DROP TABLE IF EXISTS public.response_trigger;
DROP TABLE IF EXISTS public.reskin_user;
DROP TABLE IF EXISTS public.reskin;
DROP TABLE IF EXISTS public.reminders;
DROP TABLE IF EXISTS public.reaction_trigger;
DROP TABLE IF EXISTS public.reaction_role;
DROP TABLE IF EXISTS public.quoter;
DROP TABLE IF EXISTS public.pubsub;
DROP TABLE IF EXISTS public.publisher;
DROP TABLE IF EXISTS public.prefixex;
DROP TABLE IF EXISTS public.prefix;
DROP TABLE IF EXISTS public.polls;
DROP SEQUENCE IF EXISTS public.poll_votes_vote_id_seq;
DROP TABLE IF EXISTS public.poll_votes;
DROP TABLE IF EXISTS public.pingonjoin;
DROP SEQUENCE IF EXISTS public.pets_pet_id_seq;
DROP TABLE IF EXISTS public.pets;
DROP SEQUENCE IF EXISTS public.pet_trades_id_seq;
DROP TABLE IF EXISTS public.pet_trades;
DROP SEQUENCE IF EXISTS public.pet_adventures_id_seq;
DROP TABLE IF EXISTS public.pet_adventures;
DROP TABLE IF EXISTS public.payment;
DROP TABLE IF EXISTS public.name_history;
DROP TABLE IF EXISTS public.mod;
DROP TABLE IF EXISTS public.message_ranks;
DROP TABLE IF EXISTS public.member_stats;
DROP TABLE IF EXISTS public.lovense_shares;
DROP TABLE IF EXISTS public.lovense_devices;
DROP TABLE IF EXISTS public.lovense_consent;
DROP TABLE IF EXISTS public.lovense_connections;
DROP TABLE IF EXISTS public.lovense_config;
DROP SEQUENCE IF EXISTS public.lottery_history_id_seq;
DROP TABLE IF EXISTS public.lottery_history;
DROP SEQUENCE IF EXISTS public.logging_history_id_seq;
DROP TABLE IF EXISTS public.logging_history;
DROP TABLE IF EXISTS public.logging;
DROP TABLE IF EXISTS public.jobs;
DROP SEQUENCE IF EXISTS public.job_applications_application_id_seq;
DROP TABLE IF EXISTS public.job_applications;
DROP TABLE IF EXISTS public.jail;
DROP TABLE IF EXISTS public.invite_tracking;
DROP TABLE IF EXISTS public.invite_stats;
DROP TABLE IF EXISTS public.invite_rewards;
DROP TABLE IF EXISTS public.invite_config;
DROP TABLE IF EXISTS public.incidents;
DROP TABLE IF EXISTS public.immune;
DROP TABLE IF EXISTS public.hourly_metrics;
DROP TABLE IF EXISTS public.highlights;
DROP TABLE IF EXISTS public.hardban;
DROP TABLE IF EXISTS public.guildblacklist;
DROP TABLE IF EXISTS public.guild_verification;
DROP TABLE IF EXISTS public.goodbye_message;
DROP TABLE IF EXISTS public.gnames;
DROP TABLE IF EXISTS public.giveaway_settings;
DROP TABLE IF EXISTS public.giveaway;
DROP SEQUENCE IF EXISTS public.gift_logs_id_seq;
DROP TABLE IF EXISTS public.gift_logs;
DROP TABLE IF EXISTS public.gallery;
DROP TABLE IF EXISTS public.forcenick;
DROP TABLE IF EXISTS public.feedback;
DROP TABLE IF EXISTS public.fake_permissions;
DROP TABLE IF EXISTS public.employee_stats;
DROP TABLE IF EXISTS public.economy_access;
DROP TABLE IF EXISTS public.economy;
DROP TABLE IF EXISTS public.donators;
DROP SEQUENCE IF EXISTS public.dockets_id_seq;
DROP TABLE IF EXISTS public.dockets;
DROP TABLE IF EXISTS public.docket_channels;
DROP TABLE IF EXISTS public.dalle_credits;
DROP TABLE IF EXISTS public.daily_stats;
DROP TABLE IF EXISTS public.daily_metrics;
DROP TABLE IF EXISTS public.daily_messages;
DROP TABLE IF EXISTS public.crypto;
DROP TABLE IF EXISTS public.counter;
DROP TABLE IF EXISTS public.contracts;
DROP TABLE IF EXISTS public.config;
DROP TABLE IF EXISTS public.confess_replies;
DROP TABLE IF EXISTS public.confess_mute;
DROP TABLE IF EXISTS public.confess_members;
DROP TABLE IF EXISTS public.confess_blacklist;
DROP TABLE IF EXISTS public.confess;
DROP TABLE IF EXISTS public.clownboard_entry;
DROP TABLE IF EXISTS public.clownboard;
DROP TABLE IF EXISTS public.cases;
DROP SEQUENCE IF EXISTS public.card_market_listing_id_seq;
DROP TABLE IF EXISTS public.card_market;
DROP TABLE IF EXISTS public.card_drop_channels;
DROP TABLE IF EXISTS public.card_daily;
DROP SEQUENCE IF EXISTS public.businesses_business_id_seq;
DROP TABLE IF EXISTS public.businesses;
DROP TABLE IF EXISTS public.business_stats;
DROP SEQUENCE IF EXISTS public.business_jobs_job_id_seq;
DROP TABLE IF EXISTS public.business_jobs;
DROP TABLE IF EXISTS public.boosters_lost;
DROP TABLE IF EXISTS public.booster_role;
DROP TABLE IF EXISTS public.boost_message;
DROP TABLE IF EXISTS public.boost_history;
DROP TABLE IF EXISTS public.blunt;
DROP TABLE IF EXISTS public.blacklist;
DROP TABLE IF EXISTS public.birthdays;
DROP TABLE IF EXISTS public.beta_dashboard;
DROP TABLE IF EXISTS public.backup;
DROP TABLE IF EXISTS public.avatar_history_settings;
DROP TABLE IF EXISTS public.avatar_history;
DROP TABLE IF EXISTS public.avatar_current;
DROP TABLE IF EXISTS public.autokick;
DROP TABLE IF EXISTS public.auto_role;
DROP SEQUENCE IF EXISTS public.appeals_id_seq;
DROP TABLE IF EXISTS public.appeals;
DROP TABLE IF EXISTS public.appeal_templates;
DROP TABLE IF EXISTS public.appeal_config;
DROP TABLE IF EXISTS public.antiraid;
DROP TABLE IF EXISTS public.antinuke;
DROP TABLE IF EXISTS public.aliases;
DROP TABLE IF EXISTS public.afk;
DROP TABLE IF EXISTS public.access_tokens;
DROP TABLE IF EXISTS porn.config;
DROP SEQUENCE IF EXISTS music.playlists_id_seq;
DROP TABLE IF EXISTS music.playlists;
DROP SEQUENCE IF EXISTS music.playlist_tracks_id_seq;
DROP TABLE IF EXISTS music.playlist_tracks;
DROP SEQUENCE IF EXISTS music.history_id_seq;
DROP TABLE IF EXISTS music.history;
DROP TABLE IF EXISTS level.role;
DROP TABLE IF EXISTS level.notification;
DROP TABLE IF EXISTS level.member;
DROP TABLE IF EXISTS level.config;
DROP TABLE IF EXISTS lastfm.tracks;
DROP TABLE IF EXISTS lastfm.hidden;
DROP TABLE IF EXISTS lastfm.crowns;
DROP TABLE IF EXISTS lastfm.crown_updates;
DROP TABLE IF EXISTS lastfm.config;
DROP TABLE IF EXISTS lastfm.artists;
DROP TABLE IF EXISTS lastfm.albums;
DROP TABLE IF EXISTS joindm.config;
DROP SEQUENCE IF EXISTS invoke_history.commands_id_seq;
DROP TABLE IF EXISTS invoke_history.commands;
DROP SEQUENCE IF EXISTS history.moderation_id_seq;
DROP TABLE IF EXISTS history.moderation;
DROP TABLE IF EXISTS fun.wyr_channels;
DROP TABLE IF EXISTS fortnite.rotation;
DROP TABLE IF EXISTS fortnite.reminder;
DROP TABLE IF EXISTS fortnite."authorization";
DROP TABLE IF EXISTS feeds.youtube;
DROP TABLE IF EXISTS feeds.twitter;
DROP TABLE IF EXISTS feeds.tiktok;
DROP TABLE IF EXISTS feeds.soundcloud;
DROP TABLE IF EXISTS feeds.reddit;
DROP TABLE IF EXISTS feeds.pinterest;
DROP TABLE IF EXISTS feeds.instagram;
DROP TABLE IF EXISTS family.profiles;
DROP TABLE IF EXISTS family.members;
DROP TABLE IF EXISTS family.marriages;
DROP SEQUENCE IF EXISTS economy_schema.transactions_id_seq;
DROP TABLE IF EXISTS economy_schema.transactions;
DROP SEQUENCE IF EXISTS economy.transactions_id_seq;
DROP TABLE IF EXISTS economy.transactions;
DROP TABLE IF EXISTS disboard.config;
DROP TABLE IF EXISTS disboard.bump;
DROP TABLE IF EXISTS counting.config;
DROP TABLE IF EXISTS commands.usage;
DROP TABLE IF EXISTS commands.restricted;
DROP TABLE IF EXISTS commands.ignore;
DROP TABLE IF EXISTS commands.disabled;
DROP SEQUENCE IF EXISTS auto.media_id_seq;
DROP TABLE IF EXISTS auto.media;
DROP TABLE IF EXISTS audio.statistics;
DROP SEQUENCE IF EXISTS audio.recently_played_id_seq;
DROP TABLE IF EXISTS audio.recently_played;
DROP SEQUENCE IF EXISTS audio.playlists_id_seq;
DROP TABLE IF EXISTS audio.playlists;
DROP SEQUENCE IF EXISTS audio.playlist_tracks_id_seq;
DROP TABLE IF EXISTS audio.playlist_tracks;
DROP TABLE IF EXISTS audio.config;
DROP TABLE IF EXISTS alerts.twitch;
DROP EXTENSION IF EXISTS citext;
DROP SCHEMA IF EXISTS voicemaster;
DROP SCHEMA IF EXISTS voice;
DROP SCHEMA IF EXISTS verification;
DROP SCHEMA IF EXISTS transcribe;
DROP SCHEMA IF EXISTS track;
DROP SCHEMA IF EXISTS timer;
DROP SCHEMA IF EXISTS ticket;
DROP SCHEMA IF EXISTS streaks;
DROP SCHEMA IF EXISTS stats;
DROP SCHEMA IF EXISTS statistics;
DROP SCHEMA IF EXISTS snipe;
DROP SCHEMA IF EXISTS reskin;
DROP SCHEMA IF EXISTS reposters;
DROP SCHEMA IF EXISTS porn;
DROP SCHEMA IF EXISTS music;
DROP SCHEMA IF EXISTS level;
DROP SCHEMA IF EXISTS lastfm;
DROP SCHEMA IF EXISTS joindm;
DROP SCHEMA IF EXISTS invoke_history;
DROP SCHEMA IF EXISTS history;
DROP SCHEMA IF EXISTS fun;
DROP SCHEMA IF EXISTS fortnite;
DROP SCHEMA IF EXISTS feeds;
DROP SCHEMA IF EXISTS family;
DROP SCHEMA IF EXISTS economy_schema;
DROP SCHEMA IF EXISTS economy;
DROP SCHEMA IF EXISTS disboard;
DROP SCHEMA IF EXISTS counting;
DROP SCHEMA IF EXISTS commands;
DROP SCHEMA IF EXISTS auto;
DROP SCHEMA IF EXISTS audio;
DROP SCHEMA IF EXISTS alerts;
--
-- Name: alerts; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA alerts;


ALTER SCHEMA alerts OWNER TO postgres;

--
-- Name: audio; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA audio;


ALTER SCHEMA audio OWNER TO postgres;

--
-- Name: auto; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA auto;


ALTER SCHEMA auto OWNER TO postgres;

--
-- Name: commands; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA commands;


ALTER SCHEMA commands OWNER TO postgres;

--
-- Name: counting; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA counting;


ALTER SCHEMA counting OWNER TO postgres;

--
-- Name: disboard; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA disboard;


ALTER SCHEMA disboard OWNER TO postgres;

--
-- Name: economy; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA economy;


ALTER SCHEMA economy OWNER TO postgres;

--
-- Name: economy_schema; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA economy_schema;


ALTER SCHEMA economy_schema OWNER TO postgres;

--
-- Name: family; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA family;


ALTER SCHEMA family OWNER TO postgres;

--
-- Name: feeds; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA feeds;


ALTER SCHEMA feeds OWNER TO postgres;

--
-- Name: fortnite; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA fortnite;


ALTER SCHEMA fortnite OWNER TO postgres;

--
-- Name: fun; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA fun;


ALTER SCHEMA fun OWNER TO postgres;

--
-- Name: history; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA history;


ALTER SCHEMA history OWNER TO postgres;

--
-- Name: invoke_history; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA invoke_history;


ALTER SCHEMA invoke_history OWNER TO postgres;

--
-- Name: joindm; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA joindm;


ALTER SCHEMA joindm OWNER TO postgres;

--
-- Name: lastfm; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA lastfm;


ALTER SCHEMA lastfm OWNER TO postgres;

--
-- Name: level; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA level;


ALTER SCHEMA level OWNER TO postgres;

--
-- Name: music; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA music;


ALTER SCHEMA music OWNER TO postgres;

--
-- Name: porn; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA porn;


ALTER SCHEMA porn OWNER TO postgres;

--
-- Name: reposters; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA reposters;


ALTER SCHEMA reposters OWNER TO postgres;

--
-- Name: reskin; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA reskin;


ALTER SCHEMA reskin OWNER TO postgres;

--
-- Name: snipe; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA snipe;


ALTER SCHEMA snipe OWNER TO postgres;

--
-- Name: statistics; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA statistics;


ALTER SCHEMA statistics OWNER TO postgres;

--
-- Name: stats; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA stats;


ALTER SCHEMA stats OWNER TO postgres;

--
-- Name: streaks; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA streaks;


ALTER SCHEMA streaks OWNER TO postgres;

--
-- Name: ticket; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA ticket;


ALTER SCHEMA ticket OWNER TO postgres;

--
-- Name: timer; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA timer;


ALTER SCHEMA timer OWNER TO postgres;

--
-- Name: track; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA track;


ALTER SCHEMA track OWNER TO postgres;

--
-- Name: transcribe; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA transcribe;


ALTER SCHEMA transcribe OWNER TO postgres;

--
-- Name: verification; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA verification;


ALTER SCHEMA verification OWNER TO postgres;

--
-- Name: voice; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA voice;


ALTER SCHEMA voice OWNER TO postgres;

--
-- Name: voicemaster; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA voicemaster;


ALTER SCHEMA voicemaster OWNER TO postgres;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: twitch; Type: TABLE; Schema: alerts; Owner: postgres
--

CREATE TABLE alerts.twitch (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    twitch_id bigint NOT NULL,
    twitch_login text NOT NULL,
    last_stream_id bigint,
    role_id bigint,
    template text
);


ALTER TABLE alerts.twitch OWNER TO postgres;

--
-- Name: config; Type: TABLE; Schema: audio; Owner: postgres
--

CREATE TABLE audio.config (
    guild_id bigint NOT NULL,
    volume integer NOT NULL
);


ALTER TABLE audio.config OWNER TO postgres;

--
-- Name: playlist_tracks; Type: TABLE; Schema: audio; Owner: postgres
--

CREATE TABLE audio.playlist_tracks (
    id integer NOT NULL,
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    playlist_url text NOT NULL,
    track_title text NOT NULL,
    track_uri text NOT NULL,
    track_author text,
    album_name text,
    artwork_url text,
    added_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE audio.playlist_tracks OWNER TO postgres;

--
-- Name: playlist_tracks_id_seq; Type: SEQUENCE; Schema: audio; Owner: postgres
--

CREATE SEQUENCE audio.playlist_tracks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE audio.playlist_tracks_id_seq OWNER TO postgres;

--
-- Name: playlist_tracks_id_seq; Type: SEQUENCE OWNED BY; Schema: audio; Owner: postgres
--

ALTER SEQUENCE audio.playlist_tracks_id_seq OWNED BY audio.playlist_tracks.id;


--
-- Name: playlists; Type: TABLE; Schema: audio; Owner: postgres
--

CREATE TABLE audio.playlists (
    id integer NOT NULL,
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    playlist_name text NOT NULL,
    playlist_url text NOT NULL,
    track_count integer DEFAULT 0 NOT NULL,
    added_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE audio.playlists OWNER TO postgres;

--
-- Name: playlists_id_seq; Type: SEQUENCE; Schema: audio; Owner: postgres
--

CREATE SEQUENCE audio.playlists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE audio.playlists_id_seq OWNER TO postgres;

--
-- Name: playlists_id_seq; Type: SEQUENCE OWNED BY; Schema: audio; Owner: postgres
--

ALTER SEQUENCE audio.playlists_id_seq OWNED BY audio.playlists.id;


--
-- Name: recently_played; Type: TABLE; Schema: audio; Owner: postgres
--

CREATE TABLE audio.recently_played (
    id integer NOT NULL,
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    track_title text NOT NULL,
    track_uri text,
    track_author text,
    artwork_url text,
    playlist_name text,
    playlist_url text,
    played_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE audio.recently_played OWNER TO postgres;

--
-- Name: recently_played_id_seq; Type: SEQUENCE; Schema: audio; Owner: postgres
--

CREATE SEQUENCE audio.recently_played_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE audio.recently_played_id_seq OWNER TO postgres;

--
-- Name: recently_played_id_seq; Type: SEQUENCE OWNED BY; Schema: audio; Owner: postgres
--

ALTER SEQUENCE audio.recently_played_id_seq OWNED BY audio.recently_played.id;


--
-- Name: statistics; Type: TABLE; Schema: audio; Owner: postgres
--

CREATE TABLE audio.statistics (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    tracks_played integer DEFAULT 0 NOT NULL
);


ALTER TABLE audio.statistics OWNER TO postgres;

--
-- Name: media; Type: TABLE; Schema: auto; Owner: postgres
--

CREATE TABLE auto.media (
    id integer NOT NULL,
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    type text NOT NULL,
    category text NOT NULL,
    CONSTRAINT media_category_check CHECK ((category = ANY (ARRAY['girls'::text, 'boys'::text, 'anime'::text]))),
    CONSTRAINT media_type_check CHECK ((type = ANY (ARRAY['banner'::text, 'pfp'::text])))
);


ALTER TABLE auto.media OWNER TO postgres;

--
-- Name: media_id_seq; Type: SEQUENCE; Schema: auto; Owner: postgres
--

CREATE SEQUENCE auto.media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE auto.media_id_seq OWNER TO postgres;

--
-- Name: media_id_seq; Type: SEQUENCE OWNED BY; Schema: auto; Owner: postgres
--

ALTER SEQUENCE auto.media_id_seq OWNED BY auto.media.id;


--
-- Name: disabled; Type: TABLE; Schema: commands; Owner: postgres
--

CREATE TABLE commands.disabled (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    command text NOT NULL
);


ALTER TABLE commands.disabled OWNER TO postgres;

--
-- Name: ignore; Type: TABLE; Schema: commands; Owner: postgres
--

CREATE TABLE commands.ignore (
    guild_id bigint NOT NULL,
    target_id bigint NOT NULL
);


ALTER TABLE commands.ignore OWNER TO postgres;

--
-- Name: restricted; Type: TABLE; Schema: commands; Owner: postgres
--

CREATE TABLE commands.restricted (
    guild_id bigint NOT NULL,
    role_id bigint NOT NULL,
    command text NOT NULL
);


ALTER TABLE commands.restricted OWNER TO postgres;

--
-- Name: usage; Type: TABLE; Schema: commands; Owner: postgres
--

CREATE TABLE commands.usage (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    user_id bigint NOT NULL,
    command text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE commands.usage OWNER TO postgres;

--
-- Name: config; Type: TABLE; Schema: counting; Owner: postgres
--

CREATE TABLE counting.config (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    current_count integer DEFAULT 0 NOT NULL,
    high_score integer DEFAULT 0 NOT NULL,
    last_user_id bigint,
    safe_mode boolean DEFAULT false NOT NULL,
    allow_fails boolean DEFAULT false NOT NULL,
    success_emoji text DEFAULT '✅'::text NOT NULL,
    fail_emoji text DEFAULT '❌'::text NOT NULL
);


ALTER TABLE counting.config OWNER TO postgres;

--
-- Name: bump; Type: TABLE; Schema: disboard; Owner: postgres
--

CREATE TABLE disboard.bump (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    bumped_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE disboard.bump OWNER TO postgres;

--
-- Name: config; Type: TABLE; Schema: disboard; Owner: postgres
--

CREATE TABLE disboard.config (
    guild_id bigint NOT NULL,
    status boolean DEFAULT true NOT NULL,
    channel_id bigint,
    last_channel_id bigint,
    last_user_id bigint,
    message text,
    thank_message text,
    next_bump timestamp with time zone
);


ALTER TABLE disboard.config OWNER TO postgres;

--
-- Name: transactions; Type: TABLE; Schema: economy; Owner: postgres
--

CREATE TABLE economy.transactions (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    amount bigint NOT NULL,
    type text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE economy.transactions OWNER TO postgres;

--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: economy; Owner: postgres
--

CREATE SEQUENCE economy.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE economy.transactions_id_seq OWNER TO postgres;

--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: economy; Owner: postgres
--

ALTER SEQUENCE economy.transactions_id_seq OWNED BY economy.transactions.id;


--
-- Name: transactions; Type: TABLE; Schema: economy_schema; Owner: postgres
--

CREATE TABLE economy_schema.transactions (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    amount integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE economy_schema.transactions OWNER TO postgres;

--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: economy_schema; Owner: postgres
--

CREATE SEQUENCE economy_schema.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE economy_schema.transactions_id_seq OWNER TO postgres;

--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: economy_schema; Owner: postgres
--

ALTER SEQUENCE economy_schema.transactions_id_seq OWNED BY economy_schema.transactions.id;


--
-- Name: marriages; Type: TABLE; Schema: family; Owner: postgres
--

CREATE TABLE family.marriages (
    user_id bigint NOT NULL,
    partner_id bigint NOT NULL,
    active boolean DEFAULT true NOT NULL,
    marriage_date timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE family.marriages OWNER TO postgres;

--
-- Name: members; Type: TABLE; Schema: family; Owner: postgres
--

CREATE TABLE family.members (
    user_id bigint NOT NULL,
    related_id bigint NOT NULL,
    relationship text NOT NULL
);


ALTER TABLE family.members OWNER TO postgres;

--
-- Name: profiles; Type: TABLE; Schema: family; Owner: postgres
--

CREATE TABLE family.profiles (
    user_id bigint NOT NULL,
    bio text
);


ALTER TABLE family.profiles OWNER TO postgres;

--
-- Name: instagram; Type: TABLE; Schema: feeds; Owner: postgres
--

CREATE TABLE feeds.instagram (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    instagram_id bigint NOT NULL,
    instagram_name text NOT NULL,
    template text
);


ALTER TABLE feeds.instagram OWNER TO postgres;

--
-- Name: pinterest; Type: TABLE; Schema: feeds; Owner: postgres
--

CREATE TABLE feeds.pinterest (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    pinterest_id text NOT NULL,
    pinterest_name text NOT NULL,
    board text,
    board_id text,
    embeds boolean DEFAULT true NOT NULL,
    only_new boolean DEFAULT false NOT NULL
);


ALTER TABLE feeds.pinterest OWNER TO postgres;

--
-- Name: reddit; Type: TABLE; Schema: feeds; Owner: postgres
--

CREATE TABLE feeds.reddit (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    subreddit_name text NOT NULL
);


ALTER TABLE feeds.reddit OWNER TO postgres;

--
-- Name: soundcloud; Type: TABLE; Schema: feeds; Owner: postgres
--

CREATE TABLE feeds.soundcloud (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    soundcloud_id bigint NOT NULL,
    soundcloud_name text NOT NULL,
    template text
);


ALTER TABLE feeds.soundcloud OWNER TO postgres;

--
-- Name: tiktok; Type: TABLE; Schema: feeds; Owner: postgres
--

CREATE TABLE feeds.tiktok (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    tiktok_id bigint NOT NULL,
    tiktok_name text NOT NULL,
    template text
);


ALTER TABLE feeds.tiktok OWNER TO postgres;

--
-- Name: twitter; Type: TABLE; Schema: feeds; Owner: postgres
--

CREATE TABLE feeds.twitter (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    twitter_id bigint NOT NULL,
    twitter_name text NOT NULL,
    template text,
    color text
);


ALTER TABLE feeds.twitter OWNER TO postgres;

--
-- Name: youtube; Type: TABLE; Schema: feeds; Owner: postgres
--

CREATE TABLE feeds.youtube (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    youtube_id text NOT NULL,
    youtube_name text NOT NULL,
    template text,
    shorts boolean DEFAULT false NOT NULL
);


ALTER TABLE feeds.youtube OWNER TO postgres;

--
-- Name: authorization; Type: TABLE; Schema: fortnite; Owner: postgres
--

CREATE TABLE fortnite."authorization" (
    user_id bigint NOT NULL,
    display_name text NOT NULL,
    account_id text NOT NULL,
    access_token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    refresh_token text NOT NULL
);


ALTER TABLE fortnite."authorization" OWNER TO postgres;

--
-- Name: reminder; Type: TABLE; Schema: fortnite; Owner: postgres
--

CREATE TABLE fortnite.reminder (
    user_id bigint NOT NULL,
    item_id text NOT NULL,
    item_name text NOT NULL,
    item_type text NOT NULL
);


ALTER TABLE fortnite.reminder OWNER TO postgres;

--
-- Name: rotation; Type: TABLE; Schema: fortnite; Owner: postgres
--

CREATE TABLE fortnite.rotation (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    message text
);


ALTER TABLE fortnite.rotation OWNER TO postgres;

--
-- Name: wyr_channels; Type: TABLE; Schema: fun; Owner: postgres
--

CREATE TABLE fun.wyr_channels (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    rating text NOT NULL
);


ALTER TABLE fun.wyr_channels OWNER TO postgres;

--
-- Name: moderation; Type: TABLE; Schema: history; Owner: postgres
--

CREATE TABLE history.moderation (
    id integer NOT NULL,
    guild_id bigint NOT NULL,
    case_id integer NOT NULL,
    user_id bigint NOT NULL,
    moderator_id bigint NOT NULL,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    action text NOT NULL,
    reason text NOT NULL,
    duration integer
);


ALTER TABLE history.moderation OWNER TO postgres;

--
-- Name: moderation_id_seq; Type: SEQUENCE; Schema: history; Owner: postgres
--

CREATE SEQUENCE history.moderation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE history.moderation_id_seq OWNER TO postgres;

--
-- Name: moderation_id_seq; Type: SEQUENCE OWNED BY; Schema: history; Owner: postgres
--

ALTER SEQUENCE history.moderation_id_seq OWNED BY history.moderation.id;


--
-- Name: commands; Type: TABLE; Schema: invoke_history; Owner: postgres
--

CREATE TABLE invoke_history.commands (
    id integer NOT NULL,
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    command_name text NOT NULL,
    category text NOT NULL,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE invoke_history.commands OWNER TO postgres;

--
-- Name: commands_id_seq; Type: SEQUENCE; Schema: invoke_history; Owner: postgres
--

CREATE SEQUENCE invoke_history.commands_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE invoke_history.commands_id_seq OWNER TO postgres;

--
-- Name: commands_id_seq; Type: SEQUENCE OWNED BY; Schema: invoke_history; Owner: postgres
--

ALTER SEQUENCE invoke_history.commands_id_seq OWNED BY invoke_history.commands.id;


--
-- Name: config; Type: TABLE; Schema: joindm; Owner: postgres
--

CREATE TABLE joindm.config (
    guild_id bigint NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    message text
);


ALTER TABLE joindm.config OWNER TO postgres;

--
-- Name: albums; Type: TABLE; Schema: lastfm; Owner: postgres
--

CREATE TABLE lastfm.albums (
    user_id bigint NOT NULL,
    username text NOT NULL,
    artist public.citext NOT NULL,
    album public.citext NOT NULL,
    plays bigint NOT NULL
);


ALTER TABLE lastfm.albums OWNER TO postgres;

--
-- Name: artists; Type: TABLE; Schema: lastfm; Owner: postgres
--

CREATE TABLE lastfm.artists (
    user_id bigint NOT NULL,
    username text NOT NULL,
    artist public.citext NOT NULL,
    plays bigint NOT NULL
);


ALTER TABLE lastfm.artists OWNER TO postgres;

--
-- Name: config; Type: TABLE; Schema: lastfm; Owner: postgres
--

CREATE TABLE lastfm.config (
    user_id bigint NOT NULL,
    username public.citext NOT NULL,
    color bigint,
    command text,
    reactions text[] DEFAULT '{}'::text[] NOT NULL,
    embed_mode text DEFAULT 'default'::text NOT NULL,
    last_indexed timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE lastfm.config OWNER TO postgres;

--
-- Name: crown_updates; Type: TABLE; Schema: lastfm; Owner: postgres
--

CREATE TABLE lastfm.crown_updates (
    guild_id bigint NOT NULL,
    last_update timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE lastfm.crown_updates OWNER TO postgres;

--
-- Name: crowns; Type: TABLE; Schema: lastfm; Owner: postgres
--

CREATE TABLE lastfm.crowns (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    artist public.citext NOT NULL,
    claimed_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE lastfm.crowns OWNER TO postgres;

--
-- Name: hidden; Type: TABLE; Schema: lastfm; Owner: postgres
--

CREATE TABLE lastfm.hidden (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE lastfm.hidden OWNER TO postgres;

--
-- Name: tracks; Type: TABLE; Schema: lastfm; Owner: postgres
--

CREATE TABLE lastfm.tracks (
    user_id bigint NOT NULL,
    username text NOT NULL,
    artist public.citext NOT NULL,
    track public.citext NOT NULL,
    plays bigint NOT NULL
);


ALTER TABLE lastfm.tracks OWNER TO postgres;

--
-- Name: config; Type: TABLE; Schema: level; Owner: postgres
--

CREATE TABLE level.config (
    guild_id bigint NOT NULL,
    status boolean DEFAULT true NOT NULL,
    cooldown integer DEFAULT 60 NOT NULL,
    max_level integer DEFAULT 0 NOT NULL,
    stack_roles boolean DEFAULT true NOT NULL,
    formula_multiplier double precision DEFAULT 1 NOT NULL,
    xp_multiplier double precision DEFAULT 1 NOT NULL,
    xp_min integer DEFAULT 15 NOT NULL,
    xp_max integer DEFAULT 40 NOT NULL,
    effort_status boolean DEFAULT false NOT NULL,
    effort_text bigint DEFAULT 25 NOT NULL,
    effort_image bigint DEFAULT 3 NOT NULL,
    effort_booster bigint DEFAULT 10 NOT NULL
);


ALTER TABLE level.config OWNER TO postgres;

--
-- Name: member; Type: TABLE; Schema: level; Owner: postgres
--

CREATE TABLE level.member (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    xp integer DEFAULT 0 NOT NULL,
    level integer DEFAULT 0 NOT NULL,
    total_xp integer DEFAULT 0 NOT NULL,
    last_message timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE level.member OWNER TO postgres;

--
-- Name: notification; Type: TABLE; Schema: level; Owner: postgres
--

CREATE TABLE level.notification (
    guild_id bigint NOT NULL,
    channel_id bigint,
    dm boolean DEFAULT false NOT NULL,
    template text
);


ALTER TABLE level.notification OWNER TO postgres;

--
-- Name: role; Type: TABLE; Schema: level; Owner: postgres
--

CREATE TABLE level.role (
    guild_id bigint NOT NULL,
    role_id bigint NOT NULL,
    level integer NOT NULL
);


ALTER TABLE level.role OWNER TO postgres;

--
-- Name: history; Type: TABLE; Schema: music; Owner: postgres
--

CREATE TABLE music.history (
    id integer NOT NULL,
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    title text NOT NULL,
    artist text NOT NULL,
    duration integer NOT NULL,
    thumbnail text NOT NULL,
    uri text NOT NULL,
    played_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE music.history OWNER TO postgres;

--
-- Name: history_id_seq; Type: SEQUENCE; Schema: music; Owner: postgres
--

CREATE SEQUENCE music.history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE music.history_id_seq OWNER TO postgres;

--
-- Name: history_id_seq; Type: SEQUENCE OWNED BY; Schema: music; Owner: postgres
--

ALTER SEQUENCE music.history_id_seq OWNED BY music.history.id;


--
-- Name: playlist_tracks; Type: TABLE; Schema: music; Owner: postgres
--

CREATE TABLE music.playlist_tracks (
    id integer NOT NULL,
    playlist_id integer,
    title text NOT NULL,
    artist text NOT NULL,
    duration integer NOT NULL,
    thumbnail text NOT NULL,
    uri text NOT NULL,
    added_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    added_by bigint NOT NULL
);


ALTER TABLE music.playlist_tracks OWNER TO postgres;

--
-- Name: playlist_tracks_id_seq; Type: SEQUENCE; Schema: music; Owner: postgres
--

CREATE SEQUENCE music.playlist_tracks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE music.playlist_tracks_id_seq OWNER TO postgres;

--
-- Name: playlist_tracks_id_seq; Type: SEQUENCE OWNED BY; Schema: music; Owner: postgres
--

ALTER SEQUENCE music.playlist_tracks_id_seq OWNED BY music.playlist_tracks.id;


--
-- Name: playlists; Type: TABLE; Schema: music; Owner: postgres
--

CREATE TABLE music.playlists (
    id integer NOT NULL,
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    name text NOT NULL,
    thumbnail text DEFAULT 'https://img.freepik.com/premium-photo/treble-clef-circle-musical-notes-black-background-design-3d-illustration_116124-10456.jpg?semt=ais'::text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE music.playlists OWNER TO postgres;

--
-- Name: playlists_id_seq; Type: SEQUENCE; Schema: music; Owner: postgres
--

CREATE SEQUENCE music.playlists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE music.playlists_id_seq OWNER TO postgres;

--
-- Name: playlists_id_seq; Type: SEQUENCE OWNED BY; Schema: music; Owner: postgres
--

ALTER SEQUENCE music.playlists_id_seq OWNED BY music.playlists.id;


--
-- Name: config; Type: TABLE; Schema: porn; Owner: postgres
--

CREATE TABLE porn.config (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    webhook_id bigint NOT NULL,
    webhook_token text NOT NULL,
    spoiler boolean DEFAULT false
);


ALTER TABLE porn.config OWNER TO postgres;

--
-- Name: access_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.access_tokens (
    user_id bigint NOT NULL,
    token text NOT NULL,
    discord_token text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.access_tokens OWNER TO postgres;

--
-- Name: afk; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.afk (
    user_id bigint NOT NULL,
    status text DEFAULT 'AFK'::text NOT NULL,
    left_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.afk OWNER TO postgres;

--
-- Name: aliases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.aliases (
    guild_id bigint NOT NULL,
    name text NOT NULL,
    invoke text NOT NULL,
    command text NOT NULL
);


ALTER TABLE public.aliases OWNER TO postgres;

--
-- Name: antinuke; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.antinuke (
    guild_id bigint NOT NULL,
    whitelist bigint[] DEFAULT '{}'::bigint[] NOT NULL,
    trusted_admins bigint[] DEFAULT '{}'::bigint[] NOT NULL,
    bot boolean DEFAULT false NOT NULL,
    ban jsonb,
    kick jsonb,
    role jsonb,
    channel jsonb,
    webhook jsonb,
    emoji jsonb
);


ALTER TABLE public.antinuke OWNER TO postgres;

--
-- Name: antiraid; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.antiraid (
    guild_id bigint NOT NULL,
    locked boolean DEFAULT false NOT NULL,
    joins jsonb,
    mentions jsonb,
    avatar jsonb,
    browser jsonb
);


ALTER TABLE public.antiraid OWNER TO postgres;

--
-- Name: appeal_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appeal_config (
    guild_id bigint NOT NULL,
    appeal_server_id bigint,
    appeal_channel_id bigint,
    logs_channel_id bigint,
    direct_appeal boolean DEFAULT false NOT NULL,
    questions jsonb,
    bypass_roles bigint[] DEFAULT '{}'::bigint[]
);


ALTER TABLE public.appeal_config OWNER TO postgres;

--
-- Name: appeal_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appeal_templates (
    guild_id bigint NOT NULL,
    name text NOT NULL,
    response text NOT NULL
);


ALTER TABLE public.appeal_templates OWNER TO postgres;

--
-- Name: appeals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appeals (
    id integer NOT NULL,
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    action_type text,
    status text DEFAULT 'pending'::text NOT NULL,
    moderator_id bigint,
    flags text[] DEFAULT '{}'::text[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.appeals OWNER TO postgres;

--
-- Name: appeals_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.appeals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appeals_id_seq OWNER TO postgres;

--
-- Name: appeals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.appeals_id_seq OWNED BY public.appeals.id;


--
-- Name: auto_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auto_role (
    guild_id bigint NOT NULL,
    role_id bigint NOT NULL,
    action text NOT NULL,
    delay integer
);


ALTER TABLE public.auto_role OWNER TO postgres;

--
-- Name: autokick; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.autokick (
    user_id bigint,
    guild_id bigint,
    reason text,
    author_id bigint
);


ALTER TABLE public.autokick OWNER TO postgres;

--
-- Name: avatar_current; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.avatar_current (
    user_id bigint NOT NULL,
    avatar_hash text NOT NULL,
    avatar_url text NOT NULL,
    last_updated timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.avatar_current OWNER TO postgres;

--
-- Name: avatar_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.avatar_history (
    user_id bigint NOT NULL,
    avatar_url text NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.avatar_history OWNER TO postgres;

--
-- Name: avatar_history_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.avatar_history_settings (
    user_id bigint NOT NULL,
    enabled boolean DEFAULT false NOT NULL
);


ALTER TABLE public.avatar_history_settings OWNER TO postgres;

--
-- Name: backup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backup (
    key text NOT NULL,
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    data text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.backup OWNER TO postgres;

--
-- Name: beta_dashboard; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.beta_dashboard (
    user_id bigint NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    added_by bigint,
    notes text,
    added_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.beta_dashboard OWNER TO postgres;

--
-- Name: birthdays; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.birthdays (
    user_id bigint NOT NULL,
    birthday timestamp without time zone NOT NULL
);


ALTER TABLE public.birthdays OWNER TO postgres;

--
-- Name: blacklist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blacklist (
    user_id bigint NOT NULL,
    information text
);


ALTER TABLE public.blacklist OWNER TO postgres;

--
-- Name: blunt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blunt (
    guild_id bigint NOT NULL,
    user_id bigint,
    hits bigint DEFAULT 0,
    passes bigint DEFAULT 0,
    members jsonb[] DEFAULT '{}'::jsonb[]
);


ALTER TABLE public.blunt OWNER TO postgres;

--
-- Name: boost_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.boost_history (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    boost_count integer DEFAULT 0 NOT NULL,
    last_boost_date timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.boost_history OWNER TO postgres;

--
-- Name: boost_message; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.boost_message (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    template text NOT NULL,
    delete_after integer
);


ALTER TABLE public.boost_message OWNER TO postgres;

--
-- Name: booster_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.booster_role (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role_id bigint NOT NULL
);


ALTER TABLE public.booster_role OWNER TO postgres;

--
-- Name: boosters_lost; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.boosters_lost (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    lasted_for interval NOT NULL,
    ended_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.boosters_lost OWNER TO postgres;

--
-- Name: business_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.business_jobs (
    job_id integer NOT NULL,
    business_id integer NOT NULL,
    "position" text NOT NULL,
    salary integer NOT NULL,
    description text
);


ALTER TABLE public.business_jobs OWNER TO postgres;

--
-- Name: business_jobs_job_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.business_jobs_job_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.business_jobs_job_id_seq OWNER TO postgres;

--
-- Name: business_jobs_job_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.business_jobs_job_id_seq OWNED BY public.business_jobs.job_id;


--
-- Name: business_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.business_stats (
    business_id integer NOT NULL,
    total_revenue integer DEFAULT 0 NOT NULL,
    total_expenses integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.business_stats OWNER TO postgres;

--
-- Name: businesses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.businesses (
    business_id integer NOT NULL,
    name text NOT NULL,
    owner_id bigint NOT NULL,
    balance integer DEFAULT 0 NOT NULL,
    employee_limit integer DEFAULT 5 NOT NULL
);


ALTER TABLE public.businesses OWNER TO postgres;

--
-- Name: businesses_business_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.businesses_business_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.businesses_business_id_seq OWNER TO postgres;

--
-- Name: businesses_business_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.businesses_business_id_seq OWNED BY public.businesses.business_id;


--
-- Name: card_daily; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_daily (
    user_id bigint NOT NULL,
    last_claim timestamp with time zone
);


ALTER TABLE public.card_daily OWNER TO postgres;

--
-- Name: card_drop_channels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_drop_channels (
    channel_id bigint NOT NULL,
    guild_id bigint NOT NULL,
    added_by bigint
);


ALTER TABLE public.card_drop_channels OWNER TO postgres;

--
-- Name: card_market; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_market (
    listing_id integer NOT NULL,
    seller_id bigint NOT NULL,
    card_id text NOT NULL,
    price integer NOT NULL,
    listed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.card_market OWNER TO postgres;

--
-- Name: card_market_listing_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.card_market_listing_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.card_market_listing_id_seq OWNER TO postgres;

--
-- Name: card_market_listing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.card_market_listing_id_seq OWNED BY public.card_market.listing_id;


--
-- Name: cases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cases (
    guild_id bigint,
    count integer
);


ALTER TABLE public.cases OWNER TO postgres;

--
-- Name: clownboard; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clownboard (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    self_clown boolean DEFAULT true NOT NULL,
    threshold integer DEFAULT 3 NOT NULL,
    emoji text DEFAULT '🤡'::text NOT NULL
);


ALTER TABLE public.clownboard OWNER TO postgres;

--
-- Name: clownboard_entry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clownboard_entry (
    guild_id bigint NOT NULL,
    clown_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    message_id bigint NOT NULL,
    emoji text NOT NULL
);


ALTER TABLE public.clownboard_entry OWNER TO postgres;

--
-- Name: confess; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.confess (
    guild_id bigint,
    channel_id bigint,
    confession integer
);


ALTER TABLE public.confess OWNER TO postgres;

--
-- Name: confess_blacklist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.confess_blacklist (
    guild_id bigint NOT NULL,
    word text NOT NULL
);


ALTER TABLE public.confess_blacklist OWNER TO postgres;

--
-- Name: confess_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.confess_members (
    guild_id bigint,
    user_id bigint,
    confession integer
);


ALTER TABLE public.confess_members OWNER TO postgres;

--
-- Name: confess_mute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.confess_mute (
    guild_id bigint,
    user_id bigint
);


ALTER TABLE public.confess_mute OWNER TO postgres;

--
-- Name: confess_replies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.confess_replies (
    message_id bigint NOT NULL,
    user_id bigint NOT NULL,
    guild_id bigint NOT NULL
);


ALTER TABLE public.confess_replies OWNER TO postgres;

--
-- Name: config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.config (
    guild_id bigint NOT NULL,
    prefix text DEFAULT ','::text,
    baserole bigint,
    voicemaster jsonb DEFAULT '{}'::jsonb,
    mod_log bigint,
    invoke jsonb DEFAULT '{}'::jsonb,
    lock_ignore jsonb[] DEFAULT '{}'::jsonb[],
    reskin jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.config OWNER TO postgres;

--
-- Name: contracts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contracts (
    business_id integer NOT NULL,
    employee_id bigint NOT NULL,
    owner_id bigint NOT NULL,
    "position" text NOT NULL,
    salary integer NOT NULL
);


ALTER TABLE public.contracts OWNER TO postgres;

--
-- Name: counter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.counter (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    option text NOT NULL,
    last_update timestamp with time zone DEFAULT now() NOT NULL,
    rate_limited_until timestamp with time zone
);


ALTER TABLE public.counter OWNER TO postgres;

--
-- Name: crypto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.crypto (
    user_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    transaction_id text NOT NULL,
    transaction_type text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.crypto OWNER TO postgres;

--
-- Name: daily_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.daily_messages (
    guild_id bigint NOT NULL,
    date date NOT NULL,
    messages integer DEFAULT 0 NOT NULL,
    voice_minutes double precision DEFAULT 0 NOT NULL
);


ALTER TABLE public.daily_messages OWNER TO postgres;

--
-- Name: daily_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.daily_metrics (
    date date NOT NULL,
    update_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.daily_metrics OWNER TO postgres;

--
-- Name: daily_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.daily_stats (
    guild_id bigint NOT NULL,
    date date NOT NULL,
    messages_sent integer DEFAULT 0 NOT NULL,
    voice_minutes double precision DEFAULT 0 NOT NULL
);


ALTER TABLE public.daily_stats OWNER TO postgres;

--
-- Name: dalle_credits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dalle_credits (
    user_id bigint NOT NULL,
    credits numeric DEFAULT 15.00 NOT NULL,
    last_reset timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dalle_credits OWNER TO postgres;

--
-- Name: docket_channels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.docket_channels (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    message_id bigint NOT NULL,
    thread_id bigint,
    last_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.docket_channels OWNER TO postgres;

--
-- Name: dockets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dockets (
    id integer NOT NULL,
    thread_id bigint NOT NULL,
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    title text NOT NULL,
    original_content text,
    gpt_summary text,
    image_urls text[],
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.dockets OWNER TO postgres;

--
-- Name: dockets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dockets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dockets_id_seq OWNER TO postgres;

--
-- Name: dockets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dockets_id_seq OWNED BY public.dockets.id;


--
-- Name: donators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.donators (
    user_id bigint NOT NULL
);


ALTER TABLE public.donators OWNER TO postgres;

--
-- Name: economy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.economy (
    user_id bigint NOT NULL,
    wallet integer DEFAULT 0 NOT NULL,
    bank integer DEFAULT 0 NOT NULL,
    bank_capacity integer DEFAULT 10000 NOT NULL,
    gems integer DEFAULT 0 NOT NULL,
    balance integer DEFAULT 0 NOT NULL,
    earnings numeric DEFAULT 0 NOT NULL,
    last_daily timestamp with time zone,
    daily_streak integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.economy OWNER TO postgres;

--
-- Name: economy_access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.economy_access (
    user_id bigint NOT NULL
);


ALTER TABLE public.economy_access OWNER TO postgres;

--
-- Name: employee_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_stats (
    business_id integer NOT NULL,
    employee_id bigint NOT NULL,
    work_count integer DEFAULT 0 NOT NULL,
    total_earned integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.employee_stats OWNER TO postgres;

--
-- Name: fake_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fake_permissions (
    guild_id bigint NOT NULL,
    role_id bigint NOT NULL,
    permission text NOT NULL
);


ALTER TABLE public.fake_permissions OWNER TO postgres;

--
-- Name: feedback; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feedback (
    user_id bigint NOT NULL,
    message text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.feedback OWNER TO postgres;

--
-- Name: forcenick; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.forcenick (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    nickname text NOT NULL
);


ALTER TABLE public.forcenick OWNER TO postgres;

--
-- Name: gallery; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gallery (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL
);


ALTER TABLE public.gallery OWNER TO postgres;

--
-- Name: gift_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gift_logs (
    id integer NOT NULL,
    sender_id bigint NOT NULL,
    receiver_id bigint NOT NULL,
    item_id integer NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.gift_logs OWNER TO postgres;

--
-- Name: gift_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gift_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gift_logs_id_seq OWNER TO postgres;

--
-- Name: gift_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gift_logs_id_seq OWNED BY public.gift_logs.id;


--
-- Name: giveaway; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.giveaway (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    message_id bigint NOT NULL,
    prize text NOT NULL,
    emoji text NOT NULL,
    winners integer NOT NULL,
    ended boolean DEFAULT false NOT NULL,
    ends_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.giveaway OWNER TO postgres;

--
-- Name: giveaway_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.giveaway_settings (
    guild_id bigint NOT NULL,
    bonus_roles jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.giveaway_settings OWNER TO postgres;

--
-- Name: gnames; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gnames (
    guild_id bigint NOT NULL,
    name text NOT NULL,
    changed_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gnames OWNER TO postgres;

--
-- Name: goodbye_message; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.goodbye_message (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    template text NOT NULL,
    delete_after integer
);


ALTER TABLE public.goodbye_message OWNER TO postgres;

--
-- Name: guild_verification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.guild_verification (
    guild_id bigint NOT NULL,
    platform text,
    level integer,
    kick_after integer,
    ratelimit integer,
    antialt boolean DEFAULT false,
    prevent_vpn boolean DEFAULT false,
    verified_role_id bigint,
    log_channel_id bigint,
    manual_verification boolean DEFAULT false,
    verification_channel_id bigint
);


ALTER TABLE public.guild_verification OWNER TO postgres;

--
-- Name: guildblacklist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.guildblacklist (
    guild_id bigint NOT NULL,
    information text
);


ALTER TABLE public.guildblacklist OWNER TO postgres;

--
-- Name: hardban; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hardban (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.hardban OWNER TO postgres;

--
-- Name: highlights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.highlights (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    word text NOT NULL
);


ALTER TABLE public.highlights OWNER TO postgres;

--
-- Name: hourly_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hourly_metrics (
    hour timestamp with time zone NOT NULL,
    avg_cpu numeric,
    avg_memory numeric,
    sample_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.hourly_metrics OWNER TO postgres;

--
-- Name: immune; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.immune (
    guild_id bigint NOT NULL,
    entity_id bigint NOT NULL,
    role_id bigint,
    type text NOT NULL
);


ALTER TABLE public.immune OWNER TO postgres;

--
-- Name: incidents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.incidents (
    id text NOT NULL,
    title text NOT NULL,
    start_time bigint NOT NULL,
    end_time bigint,
    status text DEFAULT 'investigating'::text NOT NULL,
    severity text NOT NULL,
    affected_services text[] DEFAULT '{}'::text[],
    affected_shards text[] DEFAULT '{}'::text[],
    updates text
);


ALTER TABLE public.incidents OWNER TO postgres;

--
-- Name: invite_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invite_config (
    guild_id bigint NOT NULL,
    is_enabled boolean DEFAULT false NOT NULL,
    log_channel_id bigint,
    fake_join_threshold integer,
    account_age_requirement integer,
    server_age_requirement integer
);


ALTER TABLE public.invite_config OWNER TO postgres;

--
-- Name: invite_rewards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invite_rewards (
    guild_id bigint NOT NULL,
    role_id bigint NOT NULL,
    required_invites integer NOT NULL
);


ALTER TABLE public.invite_rewards OWNER TO postgres;

--
-- Name: invite_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invite_stats (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    regular_invites integer DEFAULT 0 NOT NULL,
    bonus_invites integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.invite_stats OWNER TO postgres;

--
-- Name: invite_tracking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invite_tracking (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    inviter_id bigint,
    invite_code text,
    uses integer DEFAULT 0 NOT NULL,
    bonus_uses integer DEFAULT 0 NOT NULL,
    joined_at timestamp with time zone,
    left_at timestamp with time zone
);


ALTER TABLE public.invite_tracking OWNER TO postgres;

--
-- Name: jail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jail (
    guild_id bigint,
    user_id bigint,
    roles text
);


ALTER TABLE public.jail OWNER TO postgres;

--
-- Name: job_applications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_applications (
    application_id integer NOT NULL,
    job_id integer NOT NULL,
    applicant_id bigint NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.job_applications OWNER TO postgres;

--
-- Name: job_applications_application_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.job_applications_application_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.job_applications_application_id_seq OWNER TO postgres;

--
-- Name: job_applications_application_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.job_applications_application_id_seq OWNED BY public.job_applications.application_id;


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jobs (
    user_id bigint NOT NULL,
    current_job text,
    employer_id bigint,
    job_level integer DEFAULT 1 NOT NULL,
    job_experience integer DEFAULT 0 NOT NULL,
    last_work timestamp with time zone
);


ALTER TABLE public.jobs OWNER TO postgres;

--
-- Name: logging; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.logging (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    events integer NOT NULL
);


ALTER TABLE public.logging OWNER TO postgres;

--
-- Name: logging_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.logging_history (
    id integer NOT NULL,
    guild_id bigint NOT NULL,
    channel_id bigint,
    event_type text NOT NULL,
    content jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.logging_history OWNER TO postgres;

--
-- Name: logging_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.logging_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.logging_history_id_seq OWNER TO postgres;

--
-- Name: logging_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.logging_history_id_seq OWNED BY public.logging_history.id;


--
-- Name: lottery_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lottery_history (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    pot_amount bigint NOT NULL,
    total_tickets integer NOT NULL,
    winner_tickets integer NOT NULL,
    won_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lottery_history OWNER TO postgres;

--
-- Name: lottery_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lottery_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lottery_history_id_seq OWNER TO postgres;

--
-- Name: lottery_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lottery_history_id_seq OWNED BY public.lottery_history.id;


--
-- Name: lovense_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lovense_config (
    guild_id bigint NOT NULL,
    is_enabled boolean DEFAULT false NOT NULL,
    log_channel_id bigint
);


ALTER TABLE public.lovense_config OWNER TO postgres;

--
-- Name: lovense_connections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lovense_connections (
    token text NOT NULL,
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lovense_connections OWNER TO postgres;

--
-- Name: lovense_consent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lovense_consent (
    user_id bigint NOT NULL,
    agreed boolean DEFAULT false NOT NULL,
    locked boolean DEFAULT false NOT NULL
);


ALTER TABLE public.lovense_consent OWNER TO postgres;

--
-- Name: lovense_devices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lovense_devices (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    device_id text NOT NULL,
    device_type text,
    last_active timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lovense_devices OWNER TO postgres;

--
-- Name: lovense_shares; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lovense_shares (
    guild_id bigint NOT NULL,
    owner_id bigint NOT NULL,
    target_id bigint NOT NULL,
    device_id text NOT NULL
);


ALTER TABLE public.lovense_shares OWNER TO postgres;

--
-- Name: member_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.member_stats (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    messages integer DEFAULT 0 NOT NULL,
    voice_hours double precision DEFAULT 0 NOT NULL
);


ALTER TABLE public.member_stats OWNER TO postgres;

--
-- Name: message_ranks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.message_ranks (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    messages integer DEFAULT 0 NOT NULL,
    msg_rank integer
);


ALTER TABLE public.message_ranks OWNER TO postgres;

--
-- Name: mod; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mod (
    guild_id bigint,
    channel_id bigint,
    jail_id bigint,
    role_id bigint
);


ALTER TABLE public.mod OWNER TO postgres;

--
-- Name: name_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.name_history (
    user_id bigint NOT NULL,
    username text NOT NULL,
    is_nickname boolean DEFAULT false NOT NULL,
    is_hidden boolean DEFAULT false NOT NULL,
    changed_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.name_history OWNER TO postgres;

--
-- Name: payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment (
    guild_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    method text NOT NULL,
    amount bigint NOT NULL,
    transfers integer DEFAULT 0 NOT NULL,
    paid_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payment OWNER TO postgres;

--
-- Name: pet_adventures; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pet_adventures (
    id integer NOT NULL,
    pet_id integer NOT NULL,
    adventure_type text NOT NULL,
    start_time timestamp with time zone DEFAULT now() NOT NULL,
    end_time timestamp with time zone NOT NULL,
    completed boolean DEFAULT false NOT NULL
);


ALTER TABLE public.pet_adventures OWNER TO postgres;

--
-- Name: pet_adventures_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pet_adventures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pet_adventures_id_seq OWNER TO postgres;

--
-- Name: pet_adventures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pet_adventures_id_seq OWNED BY public.pet_adventures.id;


--
-- Name: pet_trades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pet_trades (
    id integer NOT NULL,
    pet1_id integer NOT NULL,
    pet2_id integer NOT NULL,
    user1_id bigint NOT NULL,
    user2_id bigint NOT NULL,
    trade_fee integer DEFAULT 0 NOT NULL,
    trade_time timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.pet_trades OWNER TO postgres;

--
-- Name: pet_trades_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pet_trades_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pet_trades_id_seq OWNER TO postgres;

--
-- Name: pet_trades_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pet_trades_id_seq OWNED BY public.pet_trades.id;


--
-- Name: pets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pets (
    pet_id integer NOT NULL,
    owner_id bigint NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    rarity text NOT NULL,
    level integer DEFAULT 1 NOT NULL,
    xp integer DEFAULT 0 NOT NULL,
    hunger integer DEFAULT 100 NOT NULL,
    happiness integer DEFAULT 100 NOT NULL,
    active boolean DEFAULT false NOT NULL
);


ALTER TABLE public.pets OWNER TO postgres;

--
-- Name: pets_pet_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pets_pet_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pets_pet_id_seq OWNER TO postgres;

--
-- Name: pets_pet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pets_pet_id_seq OWNED BY public.pets.pet_id;


--
-- Name: pingonjoin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pingonjoin (
    channel_id bigint,
    guild_id bigint
);


ALTER TABLE public.pingonjoin OWNER TO postgres;

--
-- Name: poll_votes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.poll_votes (
    vote_id integer NOT NULL,
    poll_id uuid NOT NULL,
    user_id bigint NOT NULL,
    choice_ids integer[] NOT NULL
);


ALTER TABLE public.poll_votes OWNER TO postgres;

--
-- Name: poll_votes_vote_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.poll_votes_vote_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.poll_votes_vote_id_seq OWNER TO postgres;

--
-- Name: poll_votes_vote_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.poll_votes_vote_id_seq OWNED BY public.poll_votes.vote_id;


--
-- Name: polls; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.polls (
    poll_id uuid DEFAULT gen_random_uuid() NOT NULL,
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    message_id bigint DEFAULT 0 NOT NULL,
    creator_id bigint NOT NULL,
    title text NOT NULL,
    description text,
    choices text NOT NULL,
    settings text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    ends_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.polls OWNER TO postgres;

--
-- Name: prefix; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prefix (
    guild_id bigint NOT NULL,
    prefix text NOT NULL
);


ALTER TABLE public.prefix OWNER TO postgres;

--
-- Name: prefixex; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prefixex (
    guild_id bigint,
    prefix text
);


ALTER TABLE public.prefixex OWNER TO postgres;

--
-- Name: publisher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.publisher (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL
);


ALTER TABLE public.publisher OWNER TO postgres;

--
-- Name: pubsub; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pubsub (
    id text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.pubsub OWNER TO postgres;

--
-- Name: quoter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoter (
    guild_id bigint NOT NULL,
    channel_id bigint,
    emoji text,
    embeds boolean DEFAULT true NOT NULL
);


ALTER TABLE public.quoter OWNER TO postgres;

--
-- Name: reaction_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reaction_role (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    message_id bigint NOT NULL,
    role_id bigint NOT NULL,
    emoji text NOT NULL
);


ALTER TABLE public.reaction_role OWNER TO postgres;

--
-- Name: reaction_trigger; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reaction_trigger (
    guild_id bigint NOT NULL,
    trigger public.citext NOT NULL,
    emoji text NOT NULL
);


ALTER TABLE public.reaction_trigger OWNER TO postgres;

--
-- Name: reminders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reminders (
    user_id bigint NOT NULL,
    reminder text NOT NULL,
    remind_at timestamp with time zone NOT NULL,
    invoked_at timestamp with time zone NOT NULL
);


ALTER TABLE public.reminders OWNER TO postgres;

--
-- Name: reskin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reskin (
    user_id bigint NOT NULL,
    toggled boolean DEFAULT false,
    username character varying(100),
    avatar text
);


ALTER TABLE public.reskin OWNER TO postgres;

--
-- Name: reskin_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reskin_user (
    user_id bigint,
    toggled boolean,
    username text,
    avatar text
);


ALTER TABLE public.reskin_user OWNER TO postgres;

--
-- Name: response_trigger; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.response_trigger (
    guild_id bigint NOT NULL,
    trigger public.citext NOT NULL,
    template text NOT NULL,
    strict boolean DEFAULT false NOT NULL,
    reply boolean DEFAULT false NOT NULL,
    delete boolean DEFAULT false NOT NULL,
    delete_after integer DEFAULT 0 NOT NULL,
    role_id bigint
);


ALTER TABLE public.response_trigger OWNER TO postgres;

--
-- Name: role_shops; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_shops (
    guild_id bigint NOT NULL,
    role_id bigint NOT NULL,
    price integer NOT NULL,
    description text
);


ALTER TABLE public.role_shops OWNER TO postgres;

--
-- Name: roleplay; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roleplay (
    user_id bigint NOT NULL,
    target_id bigint NOT NULL,
    category text NOT NULL,
    amount integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.roleplay OWNER TO postgres;

--
-- Name: selfprefix; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.selfprefix (
    user_id bigint,
    prefix text
);


ALTER TABLE public.selfprefix OWNER TO postgres;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settings (
    guild_id bigint NOT NULL,
    prefixes text[] DEFAULT '{}'::text[] NOT NULL,
    reskin boolean DEFAULT false NOT NULL,
    reposter_prefix boolean DEFAULT true NOT NULL,
    reposter_delete boolean DEFAULT false NOT NULL,
    reposter_embed boolean DEFAULT true NOT NULL,
    transcription boolean DEFAULT false NOT NULL,
    welcome_removal boolean DEFAULT false NOT NULL,
    booster_role_base_id bigint,
    booster_role_include_ids bigint[] DEFAULT '{}'::bigint[] NOT NULL,
    lock_role_id bigint,
    lock_ignore_ids bigint[] DEFAULT '{}'::bigint[] NOT NULL,
    log_ignore_ids bigint[] DEFAULT '{}'::bigint[] NOT NULL,
    reassign_ignore_ids bigint[] DEFAULT '{}'::bigint[] NOT NULL,
    reassign_roles boolean DEFAULT false NOT NULL,
    invoke_kick text,
    invoke_ban text,
    invoke_unban text,
    invoke_timeout text,
    invoke_untimeout text,
    invoke_play text,
    play_panel boolean DEFAULT true NOT NULL,
    play_deletion boolean DEFAULT false NOT NULL,
    safesearch_level text DEFAULT 'strict'::text NOT NULL,
    author text
);


ALTER TABLE public.settings OWNER TO postgres;

--
-- Name: shop_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shop_items (
    item_id integer NOT NULL,
    name text NOT NULL,
    description text,
    price integer NOT NULL,
    effect_type text,
    effect_value numeric,
    duration integer,
    effect_description text,
    effect_example jsonb
);


ALTER TABLE public.shop_items OWNER TO postgres;

--
-- Name: shop_items_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shop_items_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shop_items_item_id_seq OWNER TO postgres;

--
-- Name: shop_items_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shop_items_item_id_seq OWNED BY public.shop_items.item_id;


--
-- Name: shutup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shutup (
    guild_id bigint,
    user_id bigint
);


ALTER TABLE public.shutup OWNER TO postgres;

--
-- Name: social_links; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.social_links (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    type text NOT NULL,
    url text NOT NULL
);


ALTER TABLE public.social_links OWNER TO postgres;

--
-- Name: social_links_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.social_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.social_links_id_seq OWNER TO postgres;

--
-- Name: social_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.social_links_id_seq OWNED BY public.social_links.id;


--
-- Name: socials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.socials (
    user_id bigint NOT NULL,
    bio text,
    profile_image text,
    last_avatar text,
    last_background text,
    background_url text,
    audio_url text,
    audio_title text,
    show_friends boolean DEFAULT true,
    show_activity boolean DEFAULT true,
    click_enabled boolean DEFAULT false,
    click_text text DEFAULT 'Click to enter...'::text,
    discord_guild text,
    glass_effect boolean DEFAULT false,
    profile_color text DEFAULT 'linear'::text,
    linear_color text DEFAULT '#ffffff'::text,
    domains jsonb,
    verified_domains jsonb
);


ALTER TABLE public.socials OWNER TO postgres;

--
-- Name: socials_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.socials_details (
    user_id bigint NOT NULL,
    friends bigint NOT NULL
);


ALTER TABLE public.socials_details OWNER TO postgres;

--
-- Name: socials_gradients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.socials_gradients (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    element text NOT NULL,
    color text NOT NULL,
    "position" numeric
);


ALTER TABLE public.socials_gradients OWNER TO postgres;

--
-- Name: socials_gradients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.socials_gradients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.socials_gradients_id_seq OWNER TO postgres;

--
-- Name: socials_gradients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.socials_gradients_id_seq OWNED BY public.socials_gradients.id;


--
-- Name: socials_saved_colors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.socials_saved_colors (
    user_id bigint NOT NULL,
    name text NOT NULL,
    color text NOT NULL,
    type text DEFAULT 'linear'::text NOT NULL
);


ALTER TABLE public.socials_saved_colors OWNER TO postgres;

--
-- Name: socials_saved_gradients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.socials_saved_gradients (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    name text NOT NULL,
    color text NOT NULL,
    "position" numeric
);


ALTER TABLE public.socials_saved_gradients OWNER TO postgres;

--
-- Name: socials_saved_gradients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.socials_saved_gradients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.socials_saved_gradients_id_seq OWNER TO postgres;

--
-- Name: socials_saved_gradients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.socials_saved_gradients_id_seq OWNED BY public.socials_saved_gradients.id;


--
-- Name: starboard; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.starboard (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    self_star boolean DEFAULT true NOT NULL,
    threshold integer DEFAULT 3 NOT NULL,
    emoji text DEFAULT '⭐'::text NOT NULL,
    color integer
);


ALTER TABLE public.starboard OWNER TO postgres;

--
-- Name: starboard_entry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.starboard_entry (
    guild_id bigint NOT NULL,
    star_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    message_id bigint NOT NULL,
    emoji text NOT NULL
);


ALTER TABLE public.starboard_entry OWNER TO postgres;

--
-- Name: sticky_message; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sticky_message (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    message_id bigint NOT NULL,
    template text NOT NULL
);


ALTER TABLE public.sticky_message OWNER TO postgres;

--
-- Name: suggestion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suggestion (
    guild_id bigint NOT NULL,
    channel_id bigint,
    suggestion_id integer DEFAULT 0,
    author_id bigint,
    blacklisted_id bigint,
    thread_enabled boolean DEFAULT false,
    anonymous_allowed boolean DEFAULT false
);


ALTER TABLE public.suggestion OWNER TO postgres;

--
-- Name: suggestion_entries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suggestion_entries (
    guild_id bigint NOT NULL,
    message_id bigint NOT NULL,
    author_id bigint NOT NULL,
    suggestion_id integer NOT NULL,
    is_anonymous boolean DEFAULT false
);


ALTER TABLE public.suggestion_entries OWNER TO postgres;

--
-- Name: suggestion_votes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suggestion_votes (
    guild_id bigint NOT NULL,
    message_id bigint NOT NULL,
    user_id bigint NOT NULL,
    vote_type integer NOT NULL
);


ALTER TABLE public.suggestion_votes OWNER TO postgres;

--
-- Name: tag_aliases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tag_aliases (
    guild_id bigint NOT NULL,
    alias text NOT NULL,
    original text NOT NULL
);


ALTER TABLE public.tag_aliases OWNER TO postgres;

--
-- Name: tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tags (
    guild_id bigint NOT NULL,
    name text NOT NULL,
    owner_id bigint NOT NULL,
    template text NOT NULL,
    uses integer DEFAULT 0 NOT NULL,
    restricted_user bigint,
    restricted_role bigint
);


ALTER TABLE public.tags OWNER TO postgres;

--
-- Name: thread; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.thread (
    guild_id bigint NOT NULL,
    thread_id bigint NOT NULL
);


ALTER TABLE public.thread OWNER TO postgres;

--
-- Name: timezones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.timezones (
    user_id bigint NOT NULL,
    timezone text NOT NULL
);


ALTER TABLE public.timezones OWNER TO postgres;

--
-- Name: tracker; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tracker (
    guild_id bigint NOT NULL,
    vanity_channel_id bigint,
    username_channel_id bigint
);


ALTER TABLE public.tracker OWNER TO postgres;

--
-- Name: user_cards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_cards (
    user_id bigint NOT NULL,
    card_id text NOT NULL,
    card_name text,
    rarity text,
    quantity integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.user_cards OWNER TO postgres;

--
-- Name: user_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_items (
    user_id bigint NOT NULL,
    item_id integer NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    expires_at timestamp with time zone
);


ALTER TABLE public.user_items OWNER TO postgres;

--
-- Name: user_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_transactions (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    type text NOT NULL,
    amount integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_transactions OWNER TO postgres;

--
-- Name: user_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_transactions_id_seq OWNER TO postgres;

--
-- Name: user_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_transactions_id_seq OWNED BY public.user_transactions.id;


--
-- Name: uwulock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.uwulock (
    guild_id bigint,
    user_id bigint
);


ALTER TABLE public.uwulock OWNER TO postgres;

--
-- Name: vanity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vanity (
    guild_id bigint NOT NULL,
    channel_id bigint,
    role_id bigint,
    template text
);


ALTER TABLE public.vanity OWNER TO postgres;

--
-- Name: vanity_sniper; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vanity_sniper (
    guild_id bigint NOT NULL,
    status boolean DEFAULT true NOT NULL,
    channel_id bigint,
    vanities text[] DEFAULT '{}'::text[] NOT NULL
);


ALTER TABLE public.vanity_sniper OWNER TO postgres;

--
-- Name: vape; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vape (
    user_id bigint NOT NULL,
    flavor text,
    hits bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.vape OWNER TO postgres;

--
-- Name: warn_actions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warn_actions (
    guild_id bigint NOT NULL,
    threshold integer NOT NULL,
    action text NOT NULL,
    duration integer
);


ALTER TABLE public.warn_actions OWNER TO postgres;

--
-- Name: webhook; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.webhook (
    identifier text NOT NULL,
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    author_id bigint NOT NULL,
    webhook_id bigint NOT NULL
);


ALTER TABLE public.webhook OWNER TO postgres;

--
-- Name: welcome_message; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.welcome_message (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    template text NOT NULL,
    delete_after integer
);


ALTER TABLE public.welcome_message OWNER TO postgres;

--
-- Name: whitelist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.whitelist (
    guild_id bigint NOT NULL,
    status boolean DEFAULT false NOT NULL,
    action text DEFAULT 'kick'::text NOT NULL
);


ALTER TABLE public.whitelist OWNER TO postgres;

--
-- Name: disabled; Type: TABLE; Schema: reposters; Owner: postgres
--

CREATE TABLE reposters.disabled (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    reposter text NOT NULL
);


ALTER TABLE reposters.disabled OWNER TO postgres;

--
-- Name: config; Type: TABLE; Schema: reskin; Owner: postgres
--

CREATE TABLE reskin.config (
    user_id bigint NOT NULL,
    username text,
    avatar_url text
);


ALTER TABLE reskin.config OWNER TO postgres;

--
-- Name: webhook; Type: TABLE; Schema: reskin; Owner: postgres
--

CREATE TABLE reskin.webhook (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    webhook_id bigint NOT NULL
);


ALTER TABLE reskin.webhook OWNER TO postgres;

--
-- Name: filter; Type: TABLE; Schema: snipe; Owner: postgres
--

CREATE TABLE snipe.filter (
    guild_id bigint NOT NULL,
    invites boolean DEFAULT false NOT NULL,
    links boolean DEFAULT false NOT NULL,
    words text[] DEFAULT '{}'::text[] NOT NULL
);


ALTER TABLE snipe.filter OWNER TO postgres;

--
-- Name: ignore; Type: TABLE; Schema: snipe; Owner: postgres
--

CREATE TABLE snipe.ignore (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE snipe.ignore OWNER TO postgres;

--
-- Name: daily; Type: TABLE; Schema: statistics; Owner: postgres
--

CREATE TABLE statistics.daily (
    guild_id bigint NOT NULL,
    date date DEFAULT CURRENT_DATE NOT NULL,
    commands_used integer DEFAULT 0 NOT NULL,
    messages_sent integer DEFAULT 0 NOT NULL,
    voice_minutes integer DEFAULT 0 NOT NULL,
    member_id bigint DEFAULT 0 NOT NULL
);


ALTER TABLE statistics.daily OWNER TO postgres;

--
-- Name: daily_channels; Type: TABLE; Schema: statistics; Owner: postgres
--

CREATE TABLE statistics.daily_channels (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    date date DEFAULT CURRENT_DATE NOT NULL,
    messages_sent integer DEFAULT 0 NOT NULL
);


ALTER TABLE statistics.daily_channels OWNER TO postgres;

--
-- Name: config; Type: TABLE; Schema: stats; Owner: postgres
--

CREATE TABLE stats.config (
    guild_id bigint NOT NULL,
    min_word_length integer DEFAULT 3,
    count_bots boolean DEFAULT false,
    channel_whitelist bigint[],
    channel_blacklist bigint[]
);


ALTER TABLE stats.config OWNER TO postgres;

--
-- Name: custom_commands; Type: TABLE; Schema: stats; Owner: postgres
--

CREATE TABLE stats.custom_commands (
    guild_id bigint NOT NULL,
    command character varying(100) NOT NULL,
    word character varying(255) NOT NULL,
    created_by bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE stats.custom_commands OWNER TO postgres;

--
-- Name: word_usage; Type: TABLE; Schema: stats; Owner: postgres
--

CREATE TABLE stats.word_usage (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    word text NOT NULL,
    count integer DEFAULT 1,
    last_used timestamp with time zone DEFAULT now()
);


ALTER TABLE stats.word_usage OWNER TO postgres;

--
-- Name: config; Type: TABLE; Schema: streaks; Owner: postgres
--

CREATE TABLE streaks.config (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    notification_channel_id bigint,
    streak_emoji text DEFAULT '🔥'::text NOT NULL,
    image_only boolean DEFAULT false
);


ALTER TABLE streaks.config OWNER TO postgres;

--
-- Name: restore_log; Type: TABLE; Schema: streaks; Owner: postgres
--

CREATE TABLE streaks.restore_log (
    id integer NOT NULL,
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    restored_by text NOT NULL,
    previous_streak integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE streaks.restore_log OWNER TO postgres;

--
-- Name: restore_log_id_seq; Type: SEQUENCE; Schema: streaks; Owner: postgres
--

CREATE SEQUENCE streaks.restore_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE streaks.restore_log_id_seq OWNER TO postgres;

--
-- Name: restore_log_id_seq; Type: SEQUENCE OWNED BY; Schema: streaks; Owner: postgres
--

ALTER SEQUENCE streaks.restore_log_id_seq OWNED BY streaks.restore_log.id;


--
-- Name: users; Type: TABLE; Schema: streaks; Owner: postgres
--

CREATE TABLE streaks.users (
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    current_streak integer DEFAULT 0 NOT NULL,
    highest_streak integer DEFAULT 0 NOT NULL,
    last_streak_time timestamp with time zone,
    total_images_sent integer DEFAULT 0 NOT NULL,
    restores_available integer DEFAULT 0 NOT NULL
);


ALTER TABLE streaks.users OWNER TO postgres;

--
-- Name: button; Type: TABLE; Schema: ticket; Owner: postgres
--

CREATE TABLE ticket.button (
    identifier text NOT NULL,
    guild_id bigint NOT NULL,
    template text,
    category_id bigint,
    topic text
);


ALTER TABLE ticket.button OWNER TO postgres;

--
-- Name: config; Type: TABLE; Schema: ticket; Owner: postgres
--

CREATE TABLE ticket.config (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    message_id bigint NOT NULL,
    staff_ids bigint[] DEFAULT '{}'::bigint[] NOT NULL,
    blacklisted_ids bigint[] DEFAULT '{}'::bigint[] NOT NULL,
    channel_name text
);


ALTER TABLE ticket.config OWNER TO postgres;

--
-- Name: open; Type: TABLE; Schema: ticket; Owner: postgres
--

CREATE TABLE ticket.open (
    identifier text NOT NULL,
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE ticket.open OWNER TO postgres;

--
-- Name: message; Type: TABLE; Schema: timer; Owner: postgres
--

CREATE TABLE timer.message (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    template text NOT NULL,
    "interval" integer NOT NULL,
    next_trigger timestamp with time zone NOT NULL
);


ALTER TABLE timer.message OWNER TO postgres;

--
-- Name: purge; Type: TABLE; Schema: timer; Owner: postgres
--

CREATE TABLE timer.purge (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    "interval" integer NOT NULL,
    next_trigger timestamp with time zone NOT NULL,
    method text DEFAULT 'bulk'::text NOT NULL
);


ALTER TABLE timer.purge OWNER TO postgres;

--
-- Name: username; Type: TABLE; Schema: track; Owner: postgres
--

CREATE TABLE track.username (
    username text NOT NULL,
    user_ids bigint[]
);


ALTER TABLE track.username OWNER TO postgres;

--
-- Name: vanity; Type: TABLE; Schema: track; Owner: postgres
--

CREATE TABLE track.vanity (
    vanity text NOT NULL,
    user_ids bigint[]
);


ALTER TABLE track.vanity OWNER TO postgres;

--
-- Name: channels; Type: TABLE; Schema: transcribe; Owner: postgres
--

CREATE TABLE transcribe.channels (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    added_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE transcribe.channels OWNER TO postgres;

--
-- Name: rate_limit; Type: TABLE; Schema: transcribe; Owner: postgres
--

CREATE TABLE transcribe.rate_limit (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    last_used timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    uses integer DEFAULT 1
);


ALTER TABLE transcribe.rate_limit OWNER TO postgres;

--
-- Name: logs; Type: TABLE; Schema: verification; Owner: postgres
--

CREATE TABLE verification.logs (
    id integer NOT NULL,
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    session_id text NOT NULL,
    event_type text NOT NULL,
    details jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE verification.logs OWNER TO postgres;

--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: verification; Owner: postgres
--

CREATE SEQUENCE verification.logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE verification.logs_id_seq OWNER TO postgres;

--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: verification; Owner: postgres
--

ALTER SEQUENCE verification.logs_id_seq OWNED BY verification.logs.id;


--
-- Name: sessions; Type: TABLE; Schema: verification; Owner: postgres
--

CREATE TABLE verification.sessions (
    session_id text NOT NULL,
    guild_id bigint NOT NULL,
    user_id bigint NOT NULL,
    ip_address text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone NOT NULL,
    completed boolean DEFAULT false,
    failed_attempts integer DEFAULT 0
);


ALTER TABLE verification.sessions OWNER TO postgres;

--
-- Name: settings; Type: TABLE; Schema: verification; Owner: postgres
--

CREATE TABLE verification.settings (
    guild_id bigint NOT NULL,
    enabled boolean DEFAULT false,
    level text DEFAULT 'base'::text,
    methods text[] DEFAULT '{}'::text[],
    timeout integer DEFAULT 1800,
    ip_limit boolean DEFAULT false,
    vpn_check boolean DEFAULT false,
    private_tab_check boolean DEFAULT false,
    log_channel_id bigint,
    CONSTRAINT settings_level_check CHECK ((level = ANY (ARRAY['base'::text, 'medium'::text])))
);


ALTER TABLE verification.settings OWNER TO postgres;

--
-- Name: channels; Type: TABLE; Schema: voice; Owner: postgres
--

CREATE TABLE voice.channels (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    owner_id bigint NOT NULL
);


ALTER TABLE voice.channels OWNER TO postgres;

--
-- Name: config; Type: TABLE; Schema: voice; Owner: postgres
--

CREATE TABLE voice.config (
    guild_id bigint NOT NULL,
    category_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    bitrate integer,
    name text,
    status text
);


ALTER TABLE voice.config OWNER TO postgres;

--
-- Name: channels; Type: TABLE; Schema: voicemaster; Owner: postgres
--

CREATE TABLE voicemaster.channels (
    guild_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    owner_id bigint
);


ALTER TABLE voicemaster.channels OWNER TO postgres;

--
-- Name: configuration; Type: TABLE; Schema: voicemaster; Owner: postgres
--

CREATE TABLE voicemaster.configuration (
    guild_id bigint NOT NULL,
    category_id bigint,
    interface_id bigint,
    channel_id bigint,
    role_id bigint,
    region text,
    bitrate bigint
);


ALTER TABLE voicemaster.configuration OWNER TO postgres;

--
-- Name: playlist_tracks id; Type: DEFAULT; Schema: audio; Owner: postgres
--

ALTER TABLE ONLY audio.playlist_tracks ALTER COLUMN id SET DEFAULT nextval('audio.playlist_tracks_id_seq'::regclass);


--
-- Name: playlists id; Type: DEFAULT; Schema: audio; Owner: postgres
--

ALTER TABLE ONLY audio.playlists ALTER COLUMN id SET DEFAULT nextval('audio.playlists_id_seq'::regclass);


--
-- Name: recently_played id; Type: DEFAULT; Schema: audio; Owner: postgres
--

ALTER TABLE ONLY audio.recently_played ALTER COLUMN id SET DEFAULT nextval('audio.recently_played_id_seq'::regclass);


--
-- Name: media id; Type: DEFAULT; Schema: auto; Owner: postgres
--

ALTER TABLE ONLY auto.media ALTER COLUMN id SET DEFAULT nextval('auto.media_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: economy; Owner: postgres
--

ALTER TABLE ONLY economy.transactions ALTER COLUMN id SET DEFAULT nextval('economy.transactions_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: economy_schema; Owner: postgres
--

ALTER TABLE ONLY economy_schema.transactions ALTER COLUMN id SET DEFAULT nextval('economy_schema.transactions_id_seq'::regclass);


--
-- Name: moderation id; Type: DEFAULT; Schema: history; Owner: postgres
--

ALTER TABLE ONLY history.moderation ALTER COLUMN id SET DEFAULT nextval('history.moderation_id_seq'::regclass);


--
-- Name: commands id; Type: DEFAULT; Schema: invoke_history; Owner: postgres
--

ALTER TABLE ONLY invoke_history.commands ALTER COLUMN id SET DEFAULT nextval('invoke_history.commands_id_seq'::regclass);


--
-- Name: history id; Type: DEFAULT; Schema: music; Owner: postgres
--

ALTER TABLE ONLY music.history ALTER COLUMN id SET DEFAULT nextval('music.history_id_seq'::regclass);


--
-- Name: playlist_tracks id; Type: DEFAULT; Schema: music; Owner: postgres
--

ALTER TABLE ONLY music.playlist_tracks ALTER COLUMN id SET DEFAULT nextval('music.playlist_tracks_id_seq'::regclass);


--
-- Name: playlists id; Type: DEFAULT; Schema: music; Owner: postgres
--

ALTER TABLE ONLY music.playlists ALTER COLUMN id SET DEFAULT nextval('music.playlists_id_seq'::regclass);


--
-- Name: appeals id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appeals ALTER COLUMN id SET DEFAULT nextval('public.appeals_id_seq'::regclass);


--
-- Name: business_jobs job_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.business_jobs ALTER COLUMN job_id SET DEFAULT nextval('public.business_jobs_job_id_seq'::regclass);


--
-- Name: businesses business_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.businesses ALTER COLUMN business_id SET DEFAULT nextval('public.businesses_business_id_seq'::regclass);


--
-- Name: card_market listing_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_market ALTER COLUMN listing_id SET DEFAULT nextval('public.card_market_listing_id_seq'::regclass);


--
-- Name: dockets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dockets ALTER COLUMN id SET DEFAULT nextval('public.dockets_id_seq'::regclass);


--
-- Name: gift_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gift_logs ALTER COLUMN id SET DEFAULT nextval('public.gift_logs_id_seq'::regclass);


--
-- Name: job_applications application_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_applications ALTER COLUMN application_id SET DEFAULT nextval('public.job_applications_application_id_seq'::regclass);


--
-- Name: logging_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logging_history ALTER COLUMN id SET DEFAULT nextval('public.logging_history_id_seq'::regclass);


--
-- Name: lottery_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lottery_history ALTER COLUMN id SET DEFAULT nextval('public.lottery_history_id_seq'::regclass);


--
-- Name: pet_adventures id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pet_adventures ALTER COLUMN id SET DEFAULT nextval('public.pet_adventures_id_seq'::regclass);


--
-- Name: pet_trades id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pet_trades ALTER COLUMN id SET DEFAULT nextval('public.pet_trades_id_seq'::regclass);


--
-- Name: pets pet_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pets ALTER COLUMN pet_id SET DEFAULT nextval('public.pets_pet_id_seq'::regclass);


--
-- Name: poll_votes vote_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_votes ALTER COLUMN vote_id SET DEFAULT nextval('public.poll_votes_vote_id_seq'::regclass);


--
-- Name: shop_items item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_items ALTER COLUMN item_id SET DEFAULT nextval('public.shop_items_item_id_seq'::regclass);


--
-- Name: social_links id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_links ALTER COLUMN id SET DEFAULT nextval('public.social_links_id_seq'::regclass);


--
-- Name: socials_gradients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socials_gradients ALTER COLUMN id SET DEFAULT nextval('public.socials_gradients_id_seq'::regclass);


--
-- Name: socials_saved_gradients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socials_saved_gradients ALTER COLUMN id SET DEFAULT nextval('public.socials_saved_gradients_id_seq'::regclass);


--
-- Name: user_transactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_transactions ALTER COLUMN id SET DEFAULT nextval('public.user_transactions_id_seq'::regclass);


--
-- Name: restore_log id; Type: DEFAULT; Schema: streaks; Owner: postgres
--

ALTER TABLE ONLY streaks.restore_log ALTER COLUMN id SET DEFAULT nextval('streaks.restore_log_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: verification; Owner: postgres
--

ALTER TABLE ONLY verification.logs ALTER COLUMN id SET DEFAULT nextval('verification.logs_id_seq'::regclass);


--
-- Data for Name: twitch; Type: TABLE DATA; Schema: alerts; Owner: postgres
--

COPY alerts.twitch (guild_id, channel_id, twitch_id, twitch_login, last_stream_id, role_id, template) FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: audio; Owner: postgres
--

COPY audio.config (guild_id, volume) FROM stdin;
\.


--
-- Data for Name: playlist_tracks; Type: TABLE DATA; Schema: audio; Owner: postgres
--

COPY audio.playlist_tracks (id, guild_id, user_id, playlist_url, track_title, track_uri, track_author, album_name, artwork_url, added_at) FROM stdin;
\.


--
-- Data for Name: playlists; Type: TABLE DATA; Schema: audio; Owner: postgres
--

COPY audio.playlists (id, guild_id, user_id, playlist_name, playlist_url, track_count, added_at) FROM stdin;
\.


--
-- Data for Name: recently_played; Type: TABLE DATA; Schema: audio; Owner: postgres
--

COPY audio.recently_played (id, guild_id, user_id, track_title, track_uri, track_author, artwork_url, playlist_name, playlist_url, played_at) FROM stdin;
\.


--
-- Data for Name: statistics; Type: TABLE DATA; Schema: audio; Owner: postgres
--

COPY audio.statistics (guild_id, user_id, tracks_played) FROM stdin;
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: auto; Owner: postgres
--

COPY auto.media (id, guild_id, channel_id, type, category) FROM stdin;
\.


--
-- Data for Name: disabled; Type: TABLE DATA; Schema: commands; Owner: postgres
--

COPY commands.disabled (guild_id, channel_id, command) FROM stdin;
\.


--
-- Data for Name: ignore; Type: TABLE DATA; Schema: commands; Owner: postgres
--

COPY commands.ignore (guild_id, target_id) FROM stdin;
\.


--
-- Data for Name: restricted; Type: TABLE DATA; Schema: commands; Owner: postgres
--

COPY commands.restricted (guild_id, role_id, command) FROM stdin;
\.


--
-- Data for Name: usage; Type: TABLE DATA; Schema: commands; Owner: postgres
--

COPY commands.usage (guild_id, channel_id, user_id, command, created_at) FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: counting; Owner: postgres
--

COPY counting.config (guild_id, channel_id, current_count, high_score, last_user_id, safe_mode, allow_fails, success_emoji, fail_emoji) FROM stdin;
\.


--
-- Data for Name: bump; Type: TABLE DATA; Schema: disboard; Owner: postgres
--

COPY disboard.bump (guild_id, user_id, bumped_at) FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: disboard; Owner: postgres
--

COPY disboard.config (guild_id, status, channel_id, last_channel_id, last_user_id, message, thank_message, next_bump) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: economy; Owner: postgres
--

COPY economy.transactions (id, user_id, amount, type, created_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: economy_schema; Owner: postgres
--

COPY economy_schema.transactions (id, user_id, amount, created_at) FROM stdin;
\.


--
-- Data for Name: marriages; Type: TABLE DATA; Schema: family; Owner: postgres
--

COPY family.marriages (user_id, partner_id, active, marriage_date) FROM stdin;
\.


--
-- Data for Name: members; Type: TABLE DATA; Schema: family; Owner: postgres
--

COPY family.members (user_id, related_id, relationship) FROM stdin;
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: family; Owner: postgres
--

COPY family.profiles (user_id, bio) FROM stdin;
\.


--
-- Data for Name: instagram; Type: TABLE DATA; Schema: feeds; Owner: postgres
--

COPY feeds.instagram (guild_id, channel_id, instagram_id, instagram_name, template) FROM stdin;
\.


--
-- Data for Name: pinterest; Type: TABLE DATA; Schema: feeds; Owner: postgres
--

COPY feeds.pinterest (guild_id, channel_id, pinterest_id, pinterest_name, board, board_id, embeds, only_new) FROM stdin;
\.


--
-- Data for Name: reddit; Type: TABLE DATA; Schema: feeds; Owner: postgres
--

COPY feeds.reddit (guild_id, channel_id, subreddit_name) FROM stdin;
\.


--
-- Data for Name: soundcloud; Type: TABLE DATA; Schema: feeds; Owner: postgres
--

COPY feeds.soundcloud (guild_id, channel_id, soundcloud_id, soundcloud_name, template) FROM stdin;
\.


--
-- Data for Name: tiktok; Type: TABLE DATA; Schema: feeds; Owner: postgres
--

COPY feeds.tiktok (guild_id, channel_id, tiktok_id, tiktok_name, template) FROM stdin;
\.


--
-- Data for Name: twitter; Type: TABLE DATA; Schema: feeds; Owner: postgres
--

COPY feeds.twitter (guild_id, channel_id, twitter_id, twitter_name, template, color) FROM stdin;
\.


--
-- Data for Name: youtube; Type: TABLE DATA; Schema: feeds; Owner: postgres
--

COPY feeds.youtube (guild_id, channel_id, youtube_id, youtube_name, template, shorts) FROM stdin;
\.


--
-- Data for Name: authorization; Type: TABLE DATA; Schema: fortnite; Owner: postgres
--

COPY fortnite."authorization" (user_id, display_name, account_id, access_token, expires_at, refresh_token) FROM stdin;
\.


--
-- Data for Name: reminder; Type: TABLE DATA; Schema: fortnite; Owner: postgres
--

COPY fortnite.reminder (user_id, item_id, item_name, item_type) FROM stdin;
\.


--
-- Data for Name: rotation; Type: TABLE DATA; Schema: fortnite; Owner: postgres
--

COPY fortnite.rotation (guild_id, channel_id, message) FROM stdin;
\.


--
-- Data for Name: wyr_channels; Type: TABLE DATA; Schema: fun; Owner: postgres
--

COPY fun.wyr_channels (guild_id, channel_id, rating) FROM stdin;
\.


--
-- Data for Name: moderation; Type: TABLE DATA; Schema: history; Owner: postgres
--

COPY history.moderation (id, guild_id, case_id, user_id, moderator_id, "timestamp", action, reason, duration) FROM stdin;
\.


--
-- Data for Name: commands; Type: TABLE DATA; Schema: invoke_history; Owner: postgres
--

COPY invoke_history.commands (id, guild_id, user_id, command_name, category, "timestamp") FROM stdin;
1	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 15:56:04.773537+00
2	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 15:57:50.860085+00
3	1443314822182732010	1435974392810307604	translator	Config	2026-02-19 15:59:21.066244+00
4	1443314822182732010	1435974392810307604	translator	Config	2026-02-19 16:00:15.876589+00
5	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 16:00:33.487203+00
6	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 16:00:44.327808+00
7	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 16:01:02.631622+00
8	1443314822182732010	1435974392810307604	start	Economy	2026-02-19 16:01:16.135368+00
9	1443314822182732010	1435974392810307604	daily	Economy	2026-02-19 16:02:22.85658+00
10	1443314822182732010	1435974392810307604	work	Economy	2026-02-19 16:02:33.726075+00
11	1443314822182732010	1435974392810307604	jobs	Economy	2026-02-19 16:02:42.951784+00
12	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 16:02:55.962437+00
13	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 16:03:05.678672+00
14	1443314822182732010	1435974392810307604	business	Economy	2026-02-19 16:04:46.738561+00
15	1443314822182732010	1435974392810307604	business create	Economy	2026-02-19 16:05:02.681623+00
16	1443314822182732010	1435974392810307604	business create	Economy	2026-02-19 16:05:28.447991+00
17	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 16:05:42.498649+00
18	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 16:06:02.948382+00
19	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 16:06:07.500399+00
20	1443314822182732010	1435974392810307604	blunt	Fun	2026-02-19 16:06:35.636339+00
21	1443314822182732010	1435974392810307604	howgay	Fun	2026-02-19 16:07:10.031808+00
22	1443314822182732010	1435974392810307604	howgay	Fun	2026-02-19 16:07:29.505138+00
23	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 16:09:29.247764+00
24	1443314822182732010	1435974392810307604	gun	Fun	2026-02-19 16:10:02.401763+00
25	1443314822182732010	1435974392810307604	dog	Fun	2026-02-19 16:10:18.937725+00
26	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 16:10:56.829451+00
27	1443314822182732010	1435974392810307604	ping	Information	2026-02-19 16:11:18.113457+00
28	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 16:11:59.208624+00
29	1443314822182732010	1435974392810307604	snipe	Utility	2026-02-19 16:12:48.242882+00
30	1443314822182732010	1435974392810307604	premium	Utility	2026-02-19 16:14:44.258633+00
31	1443314822182732010	1435974392810307604	premium	Utility	2026-02-19 16:25:53.235619+00
32	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 16:26:03.055556+00
33	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 16:26:09.883596+00
34	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 16:26:25.282434+00
35	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 16:26:32.228659+00
36	1443314822182732010	1435974392810307604	twitter	Social	2026-02-19 16:29:39.245874+00
37	1443314822182732010	1435974392810307604	emojis	Information	2026-02-19 16:30:01.222462+00
38	1443314822182732010	1435974392810307604	sudo	Owner	2026-02-19 16:35:15.000537+00
39	1443314822182732010	1435974392810307604	sudo	Owner	2026-02-19 16:35:43.175427+00
40	1443314822182732010	1107230799977254922	help	No Category	2026-02-19 16:35:43.178774+00
41	1443314822182732010	1435974392810307604	sudo reports view	Owner	2026-02-19 16:37:05.527982+00
42	1443314822182732010	1435974392810307604	sudo reports	Owner	2026-02-19 16:37:31.436925+00
43	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 16:38:01.393589+00
44	1465825967770566752	1435974392810307604	avatar	Information	2026-02-19 16:46:54.779263+00
45	1465825967770566752	1435974392810307604	sudo avatar	Owner	2026-02-19 16:47:19.483869+00
46	1443314822182732010	1435974392810307604	sudo	Owner	2026-02-19 17:04:00.621003+00
47	1443314822182732010	1107230799977254922	sync	Owner	2026-02-19 17:04:00.625075+00
48	1443314822182732010	1435974392810307604	sync	Owner	2026-02-19 17:04:12.508928+00
49	1443314822182732010	1435974392810307604	exportcommands	Owner	2026-02-19 17:06:03.680436+00
50	1443314822182732010	1435974392810307604	sudo instances	Owner	2026-02-19 17:07:55.798581+00
51	1443314822182732010	1435974392810307604	sudo instances	Owner	2026-02-19 17:16:17.062775+00
52	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 17:17:59.41563+00
53	1443314822182732010	1435974392810307604	sudo instances	Owner	2026-02-19 17:19:21.650367+00
54	1443314822182732010	1435974392810307604	sudo entitlements	Owner	2026-02-19 17:34:27.940028+00
55	1443314822182732010	1435974392810307604	sudo entitlements skus	Owner	2026-02-19 17:34:52.653322+00
56	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 17:35:03.049162+00
57	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 17:35:18.209063+00
58	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 17:44:12.42733+00
59	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 17:46:41.382485+00
60	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 17:58:17.625397+00
61	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 18:00:05.155619+00
62	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 18:04:47.135849+00
63	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 18:13:42.313321+00
64	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 18:15:16.323016+00
65	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 18:18:13.407583+00
66	1443314822182732010	1435974392810307604	start	Economy	2026-02-19 18:18:34.064492+00
67	1443314822182732010	1435974392810307604	start	Economy	2026-02-19 18:18:56.534578+00
68	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 18:19:54.576542+00
69	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 18:22:50.034152+00
70	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 19:30:37.938873+00
71	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 19:52:54.533413+00
72	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 19:53:01.116252+00
73	1443314822182732010	1435974392810307604	daily	Economy	2026-02-19 19:55:37.040614+00
74	1443314822182732010	1470543411902808229	daily	Economy	2026-02-19 19:57:48.31525+00
75	1443314822182732010	1470543411902808229	daily	Economy	2026-02-19 19:58:02.571663+00
76	1443314822182732010	1435974392810307604	daily	Economy	2026-02-19 20:10:18.394452+00
77	1443314822182732010	1435974392810307604	daily	Economy	2026-02-19 20:11:39.796257+00
78	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 20:13:57.534598+00
79	1443314822182732010	1435974392810307604	blunt	Fun	2026-02-19 20:14:49.732202+00
80	1443314822182732010	1435974392810307604	blunt light	Fun	2026-02-19 20:15:29.506031+00
81	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 20:15:43.5985+00
82	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 20:15:59.241113+00
83	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 20:16:04.051542+00
84	1443314822182732010	1435974392810307604	blunt	Fun	2026-02-19 20:16:11.369862+00
85	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 20:16:14.448283+00
86	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 20:16:32.119919+00
87	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 20:16:44.657027+00
88	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 20:16:55.680248+00
89	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 20:17:05.032272+00
90	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 20:17:11.730524+00
91	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 20:17:47.49425+00
92	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 20:17:52.454072+00
93	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 20:17:56.930443+00
94	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 20:18:05.124472+00
95	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 20:18:16.055112+00
96	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 20:18:30.939138+00
97	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 20:18:38.364911+00
98	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 20:18:46.576797+00
99	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 20:25:40.839449+00
100	1443314822182732010	1470543411902808229	blunt	Fun	2026-02-19 20:27:22.693066+00
101	1443314822182732010	1470543411902808229	blunt hit	Fun	2026-02-19 20:27:30.481789+00
102	1443314822182732010	1470543411902808229	blunt light	Fun	2026-02-19 20:27:35.941598+00
103	1443314822182732010	1470543411902808229	blunt hit	Fun	2026-02-19 20:27:42.518315+00
105	1443314822182732010	1470543411902808229	blunt steal	Fun	2026-02-19 20:28:16.803139+00
104	1443314822182732010	1470543411902808229	blunt	Fun	2026-02-19 20:27:56.859462+00
106	1443314822182732010	1435974392810307604	blunt steal	Fun	2026-02-19 21:15:10.739654+00
107	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 21:15:33.454239+00
108	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 21:16:06.998617+00
109	1443314822182732010	1435974392810307604	blunt steal	Fun	2026-02-19 21:16:22.172755+00
110	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 21:16:32.109422+00
111	1443314822182732010	1470543411902808229	blunt steal	Fun	2026-02-19 21:16:54.853444+00
112	1443314822182732010	1470543411902808229	blunt light	Fun	2026-02-19 21:17:03.720129+00
113	1443314822182732010	1470543411902808229	blunt hit	Fun	2026-02-19 21:17:12.971516+00
114	1443314822182732010	1435974392810307604	blunt steal	Fun	2026-02-19 21:17:17.964331+00
115	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 21:17:28.346907+00
116	1443314822182732010	1435974392810307604	blunt steal	Fun	2026-02-19 21:17:43.415896+00
117	1443314822182732010	1435974392810307604	blunt hit	Fun	2026-02-19 21:17:49.943089+00
118	1443314822182732010	1435974392810307604	blunt pass	Fun	2026-02-19 21:18:00.932484+00
119	1443314822182732010	1470543411902808229	blunt hit	Fun	2026-02-19 21:18:15.112165+00
120	1443314822182732010	1435974392810307604	vape	Fun	2026-02-19 21:18:20.932874+00
121	1443314822182732010	1435974392810307604	vape	Fun	2026-02-19 21:18:41.186891+00
122	1443314822182732010	1435974392810307604	vape flavor	Fun	2026-02-19 21:18:54.803688+00
123	1443314822182732010	1435974392810307604	vape	Fun	2026-02-19 21:19:16.127155+00
124	1443314822182732010	1435974392810307604	vape hit	Fun	2026-02-19 21:19:28.37741+00
125	1443314822182732010	1470543411902808229	vape	Fun	2026-02-19 21:37:15.322716+00
126	1443314822182732010	1470543411902808229	vape flavor	Fun	2026-02-19 21:37:26.743376+00
127	1443314822182732010	1435974392810307604	vape flavors	Fun	2026-02-19 21:51:43.771174+00
128	1443314822182732010	1470543411902808229	vape flavor	Fun	2026-02-19 21:52:25.050573+00
129	1443314822182732010	1470543411902808229	vape flavor	Fun	2026-02-19 21:52:39.462199+00
130	1443314822182732010	1470543411902808229	vape	Fun	2026-02-19 21:52:43.571854+00
131	1443314822182732010	1435974392810307604	vape hit	Fun	2026-02-19 21:53:56.827424+00
132	1443314822182732010	1435974392810307604	vape hit	Fun	2026-02-19 21:55:52.199618+00
133	1443314822182732010	1435974392810307604	banner	Information	2026-02-19 22:03:00.414302+00
134	1443314822182732010	1435974392810307604	sudo banner	Owner	2026-02-19 22:03:29.788536+00
135	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 22:04:19.133319+00
136	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 22:04:56.556288+00
137	1443314822182732010	1435974392810307604	vape hit	Fun	2026-02-19 22:06:23.795326+00
138	1443314822182732010	1435974392810307604	invite	Information	2026-02-19 22:06:36.63821+00
139	1443314822182732010	1435974392810307604	purge	Moderation	2026-02-19 22:08:08.913664+00
140	1443314822182732010	1435974392810307604	about	Information	2026-02-19 22:08:44.910031+00
141	1443314822182732010	1435974392810307604	blunt	Fun	2026-02-19 22:09:39.201917+00
142	1443314822182732010	1435974392810307604	help	No Category	2026-02-19 22:15:01.609517+00
143	1443314822182732010	1435974392810307604	help	No Category	2026-02-20 12:31:12.436154+00
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: joindm; Owner: postgres
--

COPY joindm.config (guild_id, enabled, message) FROM stdin;
\.


--
-- Data for Name: albums; Type: TABLE DATA; Schema: lastfm; Owner: postgres
--

COPY lastfm.albums (user_id, username, artist, album, plays) FROM stdin;
\.


--
-- Data for Name: artists; Type: TABLE DATA; Schema: lastfm; Owner: postgres
--

COPY lastfm.artists (user_id, username, artist, plays) FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: lastfm; Owner: postgres
--

COPY lastfm.config (user_id, username, color, command, reactions, embed_mode, last_indexed) FROM stdin;
\.


--
-- Data for Name: crown_updates; Type: TABLE DATA; Schema: lastfm; Owner: postgres
--

COPY lastfm.crown_updates (guild_id, last_update) FROM stdin;
\.


--
-- Data for Name: crowns; Type: TABLE DATA; Schema: lastfm; Owner: postgres
--

COPY lastfm.crowns (guild_id, user_id, artist, claimed_at) FROM stdin;
\.


--
-- Data for Name: hidden; Type: TABLE DATA; Schema: lastfm; Owner: postgres
--

COPY lastfm.hidden (guild_id, user_id) FROM stdin;
\.


--
-- Data for Name: tracks; Type: TABLE DATA; Schema: lastfm; Owner: postgres
--

COPY lastfm.tracks (user_id, username, artist, track, plays) FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: level; Owner: postgres
--

COPY level.config (guild_id, status, cooldown, max_level, stack_roles, formula_multiplier, xp_multiplier, xp_min, xp_max, effort_status, effort_text, effort_image, effort_booster) FROM stdin;
\.


--
-- Data for Name: member; Type: TABLE DATA; Schema: level; Owner: postgres
--

COPY level.member (guild_id, user_id, xp, level, total_xp, last_message) FROM stdin;
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: level; Owner: postgres
--

COPY level.notification (guild_id, channel_id, dm, template) FROM stdin;
\.


--
-- Data for Name: role; Type: TABLE DATA; Schema: level; Owner: postgres
--

COPY level.role (guild_id, role_id, level) FROM stdin;
\.


--
-- Data for Name: history; Type: TABLE DATA; Schema: music; Owner: postgres
--

COPY music.history (id, guild_id, user_id, title, artist, duration, thumbnail, uri, played_at) FROM stdin;
\.


--
-- Data for Name: playlist_tracks; Type: TABLE DATA; Schema: music; Owner: postgres
--

COPY music.playlist_tracks (id, playlist_id, title, artist, duration, thumbnail, uri, added_at, added_by) FROM stdin;
\.


--
-- Data for Name: playlists; Type: TABLE DATA; Schema: music; Owner: postgres
--

COPY music.playlists (id, guild_id, user_id, name, thumbnail, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: porn; Owner: postgres
--

COPY porn.config (guild_id, channel_id, webhook_id, webhook_token, spoiler) FROM stdin;
\.


--
-- Data for Name: access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.access_tokens (user_id, token, discord_token, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: afk; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.afk (user_id, status, left_at) FROM stdin;
\.


--
-- Data for Name: aliases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.aliases (guild_id, name, invoke, command) FROM stdin;
\.


--
-- Data for Name: antinuke; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.antinuke (guild_id, whitelist, trusted_admins, bot, ban, kick, role, channel, webhook, emoji) FROM stdin;
1443314822182732010	{}	{}	f	\N	\N	\N	\N	\N	\N
1465825967770566752	{}	{}	f	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: antiraid; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.antiraid (guild_id, locked, joins, mentions, avatar, browser) FROM stdin;
\.


--
-- Data for Name: appeal_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appeal_config (guild_id, appeal_server_id, appeal_channel_id, logs_channel_id, direct_appeal, questions, bypass_roles) FROM stdin;
\.


--
-- Data for Name: appeal_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appeal_templates (guild_id, name, response) FROM stdin;
\.


--
-- Data for Name: appeals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appeals (id, guild_id, user_id, action_type, status, moderator_id, flags, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: auto_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auto_role (guild_id, role_id, action, delay) FROM stdin;
\.


--
-- Data for Name: autokick; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.autokick (user_id, guild_id, reason, author_id) FROM stdin;
\.


--
-- Data for Name: avatar_current; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.avatar_current (user_id, avatar_hash, avatar_url, last_updated) FROM stdin;
\.


--
-- Data for Name: avatar_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.avatar_history (user_id, avatar_url, "timestamp", deleted_at) FROM stdin;
\.


--
-- Data for Name: avatar_history_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.avatar_history_settings (user_id, enabled) FROM stdin;
\.


--
-- Data for Name: backup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backup (key, guild_id, user_id, data, created_at) FROM stdin;
\.


--
-- Data for Name: beta_dashboard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.beta_dashboard (user_id, status, added_by, notes, added_at) FROM stdin;
\.


--
-- Data for Name: birthdays; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.birthdays (user_id, birthday) FROM stdin;
\.


--
-- Data for Name: blacklist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blacklist (user_id, information) FROM stdin;
\.


--
-- Data for Name: blunt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blunt (guild_id, user_id, hits, passes, members) FROM stdin;
1443314822182732010	1470543411902808229	5	1	{1470543411902808229,1435974392810307604}
\.


--
-- Data for Name: boost_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.boost_history (guild_id, user_id, boost_count, last_boost_date) FROM stdin;
\.


--
-- Data for Name: boost_message; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.boost_message (guild_id, channel_id, template, delete_after) FROM stdin;
\.


--
-- Data for Name: booster_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.booster_role (guild_id, user_id, role_id) FROM stdin;
\.


--
-- Data for Name: boosters_lost; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.boosters_lost (guild_id, user_id, lasted_for, ended_at) FROM stdin;
\.


--
-- Data for Name: business_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.business_jobs (job_id, business_id, "position", salary, description) FROM stdin;
\.


--
-- Data for Name: business_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.business_stats (business_id, total_revenue, total_expenses) FROM stdin;
\.


--
-- Data for Name: businesses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.businesses (business_id, name, owner_id, balance, employee_limit) FROM stdin;
\.


--
-- Data for Name: card_daily; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_daily (user_id, last_claim) FROM stdin;
\.


--
-- Data for Name: card_drop_channels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_drop_channels (channel_id, guild_id, added_by) FROM stdin;
\.


--
-- Data for Name: card_market; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_market (listing_id, seller_id, card_id, price, listed_at) FROM stdin;
\.


--
-- Data for Name: cases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cases (guild_id, count) FROM stdin;
\.


--
-- Data for Name: clownboard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clownboard (guild_id, channel_id, self_clown, threshold, emoji) FROM stdin;
\.


--
-- Data for Name: clownboard_entry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clownboard_entry (guild_id, clown_id, channel_id, message_id, emoji) FROM stdin;
\.


--
-- Data for Name: confess; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.confess (guild_id, channel_id, confession) FROM stdin;
\.


--
-- Data for Name: confess_blacklist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.confess_blacklist (guild_id, word) FROM stdin;
\.


--
-- Data for Name: confess_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.confess_members (guild_id, user_id, confession) FROM stdin;
\.


--
-- Data for Name: confess_mute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.confess_mute (guild_id, user_id) FROM stdin;
\.


--
-- Data for Name: confess_replies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.confess_replies (message_id, user_id, guild_id) FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.config (guild_id, prefix, baserole, voicemaster, mod_log, invoke, lock_ignore, reskin) FROM stdin;
\.


--
-- Data for Name: contracts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contracts (business_id, employee_id, owner_id, "position", salary) FROM stdin;
\.


--
-- Data for Name: counter; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.counter (guild_id, channel_id, option, last_update, rate_limited_until) FROM stdin;
\.


--
-- Data for Name: crypto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.crypto (user_id, channel_id, transaction_id, transaction_type, created_at) FROM stdin;
\.


--
-- Data for Name: daily_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.daily_messages (guild_id, date, messages, voice_minutes) FROM stdin;
\.


--
-- Data for Name: daily_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.daily_metrics (date, update_count) FROM stdin;
\.


--
-- Data for Name: daily_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.daily_stats (guild_id, date, messages_sent, voice_minutes) FROM stdin;
\.


--
-- Data for Name: dalle_credits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dalle_credits (user_id, credits, last_reset) FROM stdin;
\.


--
-- Data for Name: docket_channels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.docket_channels (guild_id, channel_id, message_id, thread_id, last_updated) FROM stdin;
\.


--
-- Data for Name: dockets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dockets (id, thread_id, guild_id, user_id, title, original_content, gpt_summary, image_urls, status, created_at, last_updated) FROM stdin;
\.


--
-- Data for Name: donators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.donators (user_id) FROM stdin;
\.


--
-- Data for Name: economy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.economy (user_id, wallet, bank, bank_capacity, gems, balance, earnings, last_daily, daily_streak) FROM stdin;
1435974392810307604	2000	0	10000	0	0	0	2026-02-19 16:02:22.855433+00	1
1470543411902808229	1000	0	10000	0	0	0	2026-02-19 19:57:48.317295+00	1
\.


--
-- Data for Name: economy_access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.economy_access (user_id) FROM stdin;
\.


--
-- Data for Name: employee_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_stats (business_id, employee_id, work_count, total_earned) FROM stdin;
\.


--
-- Data for Name: fake_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fake_permissions (guild_id, role_id, permission) FROM stdin;
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feedback (user_id, message, created_at) FROM stdin;
\.


--
-- Data for Name: forcenick; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.forcenick (guild_id, user_id, nickname) FROM stdin;
\.


--
-- Data for Name: gallery; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gallery (guild_id, channel_id) FROM stdin;
\.


--
-- Data for Name: gift_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gift_logs (id, sender_id, receiver_id, item_id, quantity, created_at) FROM stdin;
\.


--
-- Data for Name: giveaway; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.giveaway (guild_id, user_id, channel_id, message_id, prize, emoji, winners, ended, ends_at, created_at) FROM stdin;
\.


--
-- Data for Name: giveaway_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.giveaway_settings (guild_id, bonus_roles) FROM stdin;
\.


--
-- Data for Name: gnames; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gnames (guild_id, name, changed_at) FROM stdin;
\.


--
-- Data for Name: goodbye_message; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.goodbye_message (guild_id, channel_id, template, delete_after) FROM stdin;
\.


--
-- Data for Name: guild_verification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.guild_verification (guild_id, platform, level, kick_after, ratelimit, antialt, prevent_vpn, verified_role_id, log_channel_id, manual_verification, verification_channel_id) FROM stdin;
\.


--
-- Data for Name: guildblacklist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.guildblacklist (guild_id, information) FROM stdin;
\.


--
-- Data for Name: hardban; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hardban (guild_id, user_id) FROM stdin;
\.


--
-- Data for Name: highlights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.highlights (guild_id, user_id, word) FROM stdin;
\.


--
-- Data for Name: hourly_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hourly_metrics (hour, avg_cpu, avg_memory, sample_count) FROM stdin;
\.


--
-- Data for Name: immune; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.immune (guild_id, entity_id, role_id, type) FROM stdin;
\.


--
-- Data for Name: incidents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.incidents (id, title, start_time, end_time, status, severity, affected_services, affected_shards, updates) FROM stdin;
\.


--
-- Data for Name: invite_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invite_config (guild_id, is_enabled, log_channel_id, fake_join_threshold, account_age_requirement, server_age_requirement) FROM stdin;
\.


--
-- Data for Name: invite_rewards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invite_rewards (guild_id, role_id, required_invites) FROM stdin;
\.


--
-- Data for Name: invite_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invite_stats (guild_id, user_id, regular_invites, bonus_invites) FROM stdin;
\.


--
-- Data for Name: invite_tracking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invite_tracking (guild_id, user_id, inviter_id, invite_code, uses, bonus_uses, joined_at, left_at) FROM stdin;
\.


--
-- Data for Name: jail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jail (guild_id, user_id, roles) FROM stdin;
\.


--
-- Data for Name: job_applications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_applications (application_id, job_id, applicant_id, status, applied_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jobs (user_id, current_job, employer_id, job_level, job_experience, last_work) FROM stdin;
\.


--
-- Data for Name: logging; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.logging (guild_id, channel_id, events) FROM stdin;
\.


--
-- Data for Name: logging_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.logging_history (id, guild_id, channel_id, event_type, content, created_at) FROM stdin;
1	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T15:55:59.537480+00:00\\"}, \\"message\\": {\\"id\\": \\"1474071991890739200\\", \\"content\\": \\",help\\", \\"created_at\\": \\"2026-02-19T15:55:49.800000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 15:55:59.538207+00
2	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:00:33.725601+00:00\\"}, \\"message\\": {\\"id\\": \\"1474073181110145066\\", \\"content\\": \\";purge 4\\", \\"created_at\\": \\"2026-02-19T16:00:33.332000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 16:00:33.726004+00
3	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:00:34.183175+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474072499233755206\\", \\"content\\": \\";help\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T15:57:50.760000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474072499787665460\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T15:57:50.892000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474072877652512976\\", \\"content\\": \\";translator\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T15:59:20.982000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474073106682347614\\", \\"content\\": \\";translator\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:00:15.587000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"4 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 16:00:34.183494+00
4	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:00:44.501075+00:00\\"}, \\"message\\": {\\"id\\": \\"1474073226849292502\\", \\"content\\": \\";purge 2\\", \\"created_at\\": \\"2026-02-19T16:00:44.237000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 16:00:44.501354+00
5	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:00:44.860188+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474072054402912330\\", \\"content\\": \\";help\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T15:56:04.704000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474072117967327367\\", \\"content\\": \\"fuck\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T15:56:19.859000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"2 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 16:00:44.860456+00
6	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:02:56.109542+00:00\\"}, \\"message\\": {\\"id\\": \\"1474073779050254551\\", \\"content\\": \\";purge 6\\", \\"created_at\\": \\"2026-02-19T16:02:55.892000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 16:02:56.109889+00
7	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:02:56.653590+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474073640088633496\\", \\"content\\": \\";daily\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:02:22.761000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474073640806121504\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T16:02:22.932000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474073685672464610\\", \\"content\\": \\";work\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:02:33.629000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474073686163194040\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T16:02:33.746000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474073724427698187\\", \\"content\\": \\";jobs\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:02:42.869000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474073725094727791\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T16:02:43.028000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"6 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 16:02:56.653922+00
8	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:03:05.895197+00:00\\"}, \\"message\\": {\\"id\\": \\"1474073819789660180\\", \\"content\\": \\";purge 2\\", \\"created_at\\": \\"2026-02-19T16:03:05.605000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 16:03:05.895556+00
27	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T17:04:27.106741+00:00\\"}, \\"message\\": {\\"id\\": \\"1474089148481671218\\", \\"content\\": \\";sudo sync\\", \\"created_at\\": \\"2026-02-19T17:04:00.250000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 17:04:27.107055+00
9	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:03:06.627853+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474073360345333913\\", \\"content\\": \\";start\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:01:16.065000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474073360672755723\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T16:01:16.143000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"2 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 16:03:06.628223+00
10	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:05:43.403240+00:00\\"}, \\"message\\": {\\"id\\": \\"1474074477280104636\\", \\"content\\": \\";purge 6\\", \\"created_at\\": \\"2026-02-19T16:05:42.363000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 16:05:43.403576+00
11	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:05:44.162111+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474074243619618968\\", \\"content\\": \\";business\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:04:46.654000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474074244689301678\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T16:04:46.909000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474074309092966569\\", \\"content\\": \\";business create\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:05:02.264000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474074316671946935\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T16:05:04.071000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474074418593534143\\", \\"content\\": \\";business create Lucid Raiding\\\\u2122\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:05:28.371000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474074419537248437\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T16:05:28.596000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"6 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 16:05:44.162499+00
12	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:06:03.120136+00:00\\"}, \\"message\\": {\\"id\\": \\"1474074562973929474\\", \\"content\\": \\";purge 2\\", \\"created_at\\": \\"2026-02-19T16:06:02.794000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 16:06:03.120436+00
13	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:07:15.010539+00:00\\"}, \\"message\\": {\\"id\\": \\"1474074700333318400\\", \\"content\\": \\";blunt\\", \\"created_at\\": \\"2026-02-19T16:06:35.543000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 16:07:15.011619+00
14	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:09:29.482124+00:00\\"}, \\"message\\": {\\"id\\": \\"1474075428615491808\\", \\"content\\": \\";purge 4\\", \\"created_at\\": \\"2026-02-19T16:09:29.179000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 16:09:29.482486+00
15	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:09:30.050887+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474074844495872040\\", \\"content\\": \\";howgay\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:07:09.914000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474074845615489176\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T16:07:10.181000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474074926410502348\\", \\"content\\": \\";howgay <@1440159933776527463>\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:07:29.444000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474074927089979464\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T16:07:29.606000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"4 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 16:09:30.051147+00
16	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:10:57.285348+00:00\\"}, \\"message\\": {\\"id\\": \\"1474075795919212797\\", \\"content\\": \\";purge 5\\", \\"created_at\\": \\"2026-02-19T16:10:56.751000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 16:10:57.286322+00
19	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:13:01.490163+00:00\\"}, \\"message\\": {\\"id\\": \\"1474076262560563301\\", \\"content\\": \\";s\\", \\"created_at\\": \\"2026-02-19T16:12:48.007000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 16:13:01.502837+00
17	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:10:57.870827+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474075567715520766\\", \\"content\\": \\";gun\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:10:02.343000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474075573033893990\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T16:10:03.611000+00:00\\", \\"attachments\\": [{\\"filename\\": \\"gun.png\\", \\"url\\": \\"https://cdn.discordapp.com/attachments/1443314822971265171/1474075572786302997/gun.png?ex=6998875b&is=699735db&hm=7596c38a460fd4dcdab1d76da6105e6bd7b8ef6e476584b54664bd373e2ec212&\\", \\"size\\": 915567}]}, {\\"id\\": \\"1474075637009481728\\", \\"content\\": \\";dog\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:10:18.864000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474075638712373280\\", \\"content\\": \\"Failed to fetch the dog image\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T16:10:19.270000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474075711802445825\\", \\"content\\": \\";shard\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:10:36.696000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"5 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 16:10:57.871772+00
18	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:11:39.016018+00:00\\"}, \\"message\\": {\\"id\\": \\"1474075954178556086\\", \\"content\\": \\";shardinfo\\", \\"created_at\\": \\"2026-02-19T16:11:34.483000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 16:11:39.016367+00
20	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:26:03.249148+00:00\\"}, \\"message\\": {\\"id\\": \\"1474079596231135314\\", \\"content\\": \\";purge 4\\", \\"created_at\\": \\"2026-02-19T16:26:02.816000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 16:26:03.250722+00
21	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:26:03.938631+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474079555680469033\\", \\"content\\": \\";premium\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:25:53.148000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474079556632707298\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T16:25:53.375000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"2 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 16:26:03.939172+00
22	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:26:32.427099+00:00\\"}, \\"message\\": {\\"id\\": \\"1474079719204061381\\", \\"content\\": \\";purge 2\\", \\"created_at\\": \\"2026-02-19T16:26:32.135000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 16:26:32.428204+00
23	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:26:32.826173+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474079690116567123\\", \\"content\\": \\";help owner\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:26:25.200000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474079690854502421\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T16:26:25.376000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"2 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 16:26:32.826628+00
24	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:30:20.253187+00:00\\"}, \\"message\\": {\\"id\\": \\"1474080503266279627\\", \\"content\\": \\";x\\", \\"created_at\\": \\"2026-02-19T16:29:39.070000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 16:30:20.25413+00
25	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:38:01.659993+00:00\\"}, \\"message\\": {\\"id\\": \\"1474082609662529781\\", \\"content\\": \\";purge 50\\", \\"created_at\\": \\"2026-02-19T16:38:01.274000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 16:38:01.66028+00
26	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T16:38:03.580912+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474079625582870761\\", \\"content\\": \\";help\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:26:09.814000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474079626690170982\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T16:26:10.078000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474080595553419397\\", \\"content\\": \\";emojis\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:30:01.073000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474080597759754525\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T16:30:01.599000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474080638293246256\\", \\"content\\": \\"shit\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:30:11.263000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474081911730343980\\", \\"content\\": \\";sudo\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:35:14.874000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474082029477040323\\", \\"content\\": \\";sudo help\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:35:42.947000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474082030823276565\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T16:35:43.268000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474082213380231353\\", \\"content\\": \\";reports\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:36:26.793000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474082254568296580\\", \\"content\\": \\";reports view\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:36:36.613000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474082375360053442\\", \\"content\\": \\";sudo reports view\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:37:05.412000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474082376362492066\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T16:37:05.651000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474082483976011827\\", \\"content\\": \\";sudo reports\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T16:37:31.308000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"13 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 16:38:03.581865+00
28	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T17:04:55.317872+00:00\\"}, \\"message\\": {\\"id\\": \\"1474085080254386361\\", \\"content\\": \\"<@1473751805094662398>\\", \\"created_at\\": \\"2026-02-19T16:47:50.309000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 17:04:55.318196+00
29	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T17:17:59.625210+00:00\\"}, \\"message\\": {\\"id\\": \\"1474092667678883983\\", \\"content\\": \\";purge 4\\", \\"created_at\\": \\"2026-02-19T17:17:59.292000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 17:17:59.625537+00
30	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T17:18:00.120873+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474092238525960194\\", \\"content\\": \\";sudo instances\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T17:16:16.974000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474092245803208898\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T17:16:18.709000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"2 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 17:18:00.121221+00
31	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T17:35:03.190802+00:00\\"}, \\"message\\": {\\"id\\": \\"1474096961006338346\\", \\"content\\": \\";purge 4\\", \\"created_at\\": \\"2026-02-19T17:35:02.901000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 17:35:03.191986+00
32	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T17:35:03.699111+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474093039843803396\\", \\"content\\": \\"better\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T17:19:28.023000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474096812431507637\\", \\"content\\": \\";sudo entitlements\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T17:34:27.478000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474096917410742324\\", \\"content\\": \\";sudo entitlements skus\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T17:34:52.507000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474096919214166127\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T17:34:52.937000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"4 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 17:35:03.699421+00
33	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T17:35:18.393595+00:00\\"}, \\"message\\": {\\"id\\": \\"1474097024935923946\\", \\"content\\": \\";purge 7\\", \\"created_at\\": \\"2026-02-19T17:35:18.143000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 17:35:18.393986+00
34	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T17:35:18.932597+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474093012127584561\\", \\"content\\": \\";sudo instances\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T17:19:21.415000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474093014937894913\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T17:19:22.085000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"2 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 17:35:18.932919+00
35	1443314822182732010	\N	MEMBER	"{\\"event\\": {\\"type\\": \\"MEMBER_ADD\\", \\"timestamp\\": \\"2026-02-19T17:46:10.822169+00:00\\"}, \\"member\\": {\\"id\\": \\"1203514684326805524\\", \\"name\\": \\"evict\\", \\"display_name\\": \\"evict\\", \\"bot\\": true, \\"created_at\\": \\"2024-02-04T01:37:40.965000+00:00\\", \\"joined_at\\": \\"2026-02-19T17:46:10.762113+00:00\\", \\"roles\\": [\\"1474099761752707075\\"], \\"avatar_url\\": \\"https://cdn.discordapp.com/avatars/1203514684326805524/abfe32ab1ce0de8726e505191954c348.png?size=1024\\"}, \\"action\\": \\"JOIN\\", \\"details\\": {\\"new_account\\": false}}"	2026-02-19 17:46:10.822571+00
36	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T17:46:34.401308+00:00\\"}, \\"message\\": {\\"id\\": \\"1474099826068291706\\", \\"content\\": \\",help\\", \\"created_at\\": \\"2026-02-19T17:46:25.985000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 17:46:34.40163+00
37	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T17:47:01.337096+00:00\\"}, \\"message\\": {\\"id\\": \\"1474099264635404289\\", \\"content\\": \\";help\\", \\"created_at\\": \\"2026-02-19T17:44:12.129000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 17:47:01.337387+00
38	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T18:19:12.090400+00:00\\"}, \\"message\\": {\\"id\\": \\"1474107912749322423\\", \\"content\\": \\";start\\", \\"created_at\\": \\"2026-02-19T18:18:34+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 18:19:12.090857+00
39	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T18:19:54.772614+00:00\\"}, \\"message\\": {\\"id\\": \\"1474108250365493459\\", \\"content\\": \\";purge 3\\", \\"created_at\\": \\"2026-02-19T18:19:54.494000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 18:19:54.773241+00
40	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T18:19:55.194283+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474108006680760506\\", \\"content\\": \\";start\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T18:18:56.395000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474108007586467852\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1203514684326805524\\", \\"name\\": \\"evict#6621\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T18:18:56.611000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474108007955566643\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T18:18:56.699000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"3 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 18:19:55.194607+00
41	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T18:19:55.541350+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474107825255874692\\", \\"content\\": \\";help\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T18:18:13.140000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474107826153586975\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1203514684326805524\\", \\"name\\": \\"evict#6621\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T18:18:13.354000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474107826946314443\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"Evict | Beta#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T18:18:13.543000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"3 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 18:19:55.541625+00
42	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_EDIT\\", \\"timestamp\\": \\"2026-02-19T19:41:04.830163+00:00\\"}, \\"message\\": {\\"id\\": \\"1474127411099467938\\", \\"jump_url\\": \\"https://discord.com/channels/1443314822182732010/1443314822971265171/1474127411099467938\\", \\"changes\\": {\\"content\\": {\\"before\\": \\"discord.gg/harlem\\", \\"after\\": \\"discord.gg/harlemn\\"}, \\"attachments\\": null, \\"embeds\\": null}}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 19:41:04.832833+00
43	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_EDIT\\", \\"timestamp\\": \\"2026-02-19T19:41:13.403825+00:00\\"}, \\"message\\": {\\"id\\": \\"1474127411099467938\\", \\"jump_url\\": \\"https://discord.com/channels/1443314822182732010/1443314822971265171/1474127411099467938\\", \\"changes\\": {\\"content\\": {\\"before\\": \\"discord.gg/harlemn\\", \\"after\\": \\"discord.gg/harlam\\"}, \\"attachments\\": null, \\"embeds\\": null}}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 19:41:13.405184+00
44	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_EDIT\\", \\"timestamp\\": \\"2026-02-19T19:41:39.145701+00:00\\"}, \\"message\\": {\\"id\\": \\"1474127411099467938\\", \\"jump_url\\": \\"https://discord.com/channels/1443314822182732010/1443314822971265171/1474127411099467938\\", \\"changes\\": {\\"content\\": {\\"before\\": \\"discord.gg/harlam\\", \\"after\\": \\"discord.gg/Harlem\\"}, \\"attachments\\": null, \\"embeds\\": null}}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 19:41:39.145924+00
45	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_EDIT\\", \\"timestamp\\": \\"2026-02-19T19:41:48.900799+00:00\\"}, \\"message\\": {\\"id\\": \\"1474127411099467938\\", \\"jump_url\\": \\"https://discord.com/channels/1443314822182732010/1443314822971265171/1474127411099467938\\", \\"changes\\": {\\"content\\": {\\"before\\": \\"discord.gg/Harlem\\", \\"after\\": \\"discord.gg/harlem\\"}, \\"attachments\\": null, \\"embeds\\": null}}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 19:41:48.901028+00
46	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T19:47:00.956650+00:00\\"}, \\"message\\": {\\"id\\": \\"1474128473697030155\\", \\"content\\": \\"discord.gg/deaf\\", \\"created_at\\": \\"2026-02-19T19:40:16.112000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 19:47:00.958188+00
47	1465825967770566752	\N	MEMBER	"{\\"event\\": {\\"type\\": \\"MEMBER_ADD\\", \\"timestamp\\": \\"2026-02-19T19:47:56.313030+00:00\\"}, \\"member\\": {\\"id\\": \\"1232778508426809365\\", \\"name\\": \\"slam\\", \\"display_name\\": \\"slam\\", \\"bot\\": true, \\"created_at\\": \\"2024-04-24T19:41:40.326000+00:00\\", \\"joined_at\\": \\"2026-02-19T19:47:56.243250+00:00\\", \\"roles\\": [\\"1474130402783268942\\"], \\"avatar_url\\": \\"https://cdn.discordapp.com/avatars/1232778508426809365/821c284250ef48a5fcea256abbcda15d.png?size=1024\\"}, \\"action\\": \\"JOIN\\", \\"details\\": {\\"new_account\\": false}}"	2026-02-19 19:47:56.313373+00
48	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T19:48:12.869313+00:00\\"}, \\"message\\": {\\"id\\": \\"1474128544882888928\\", \\"content\\": \\"discord.gg/since\\", \\"created_at\\": \\"2026-02-19T19:40:33.084000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 19:48:12.869642+00
49	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T19:48:18.032296+00:00\\"}, \\"message\\": {\\"id\\": \\"1474127411099467938\\", \\"content\\": \\"discord.gg/harlem\\", \\"created_at\\": \\"2026-02-19T19:36:02.769000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 19:48:18.033234+00
50	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T19:48:21.076046+00:00\\"}, \\"message\\": {\\"id\\": \\"1474127442112151678\\", \\"content\\": \\"https://azron.net\\", \\"created_at\\": \\"2026-02-19T19:36:10.163000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 19:48:21.07637+00
51	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T19:52:54.699035+00:00\\"}, \\"message\\": {\\"id\\": \\"1474131653982163076\\", \\"content\\": \\";purge 4\\", \\"created_at\\": \\"2026-02-19T19:52:54.351000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 19:52:54.699353+00
52	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T19:52:55.220791+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474126047472517315\\", \\"content\\": \\";help\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T19:30:37.655000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474126048676286505\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1203514684326805524\\", \\"name\\": \\"evict#6621\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T19:30:37.942000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474126049305694281\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"evict#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T19:30:38.092000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474126088136298496\\", \\"content\\": \\"nice\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T19:30:47.350000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"4 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 19:52:55.221919+00
53	1443314822182732010	\N	MEMBER	"{\\"event\\": {\\"type\\": \\"MEMBER_REMOVE\\", \\"timestamp\\": \\"2026-02-19T20:17:44.857762+00:00\\"}, \\"member\\": {\\"id\\": \\"1439973742548615290\\", \\"name\\": \\"Axion\\", \\"display_name\\": \\"Axion\\", \\"bot\\": true, \\"created_at\\": \\"2025-11-17T13:41:33.642000+00:00\\", \\"joined_at\\": \\"2025-12-25T03:04:53.632000+00:00\\", \\"roles\\": [\\"1461053786553454837\\"], \\"avatar_url\\": \\"https://cdn.discordapp.com/avatars/1439973742548615290/ea73c32c3c8187a0e0ff724725f554ef.png?size=1024\\"}, \\"action\\": \\"LEAVE\\", \\"reason\\": null}"	2026-02-19 20:17:44.858082+00
54	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T20:18:16.144770+00:00\\"}, \\"message\\": {\\"id\\": \\"1474138036068683796\\", \\"content\\": \\";purge 20\\", \\"created_at\\": \\"2026-02-19T20:18:15.959000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 20:18:16.145094+00
55	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T20:18:19.175173+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474137698909294763\\", \\"content\\": \\";blunt hit\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T20:16:55.574000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137699706339441\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"evict#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T20:16:55.764000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137737950007378\\", \\"content\\": \\";blunt hit\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T20:17:04.882000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137738008596667\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1203514684326805524\\", \\"name\\": \\"evict#6621\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T20:17:04.896000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137766336921700\\", \\"content\\": \\";blunt hit\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T20:17:11.650000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137767083638794\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"evict#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T20:17:11.828000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137916191150296\\", \\"content\\": \\";blunt hit\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T20:17:47.378000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137917298573353\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"evict#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T20:17:47.642000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137936852422667\\", \\"content\\": \\";blunt hit\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T20:17:52.304000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137956783620239\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1203514684326805524\\", \\"name\\": \\"evict#6621\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T20:17:57.056000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137957051928698\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"evict#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T20:17:57.120000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137990220747044\\", \\"content\\": \\";blunt hit\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T20:18:05.028000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137990375800976\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1203514684326805524\\", \\"name\\": \\"evict#6621\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T20:18:05.065000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137991067992295\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"evict#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T20:18:05.230000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"14 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 20:18:19.175496+00
56	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T20:18:31.025230+00:00\\"}, \\"message\\": {\\"id\\": \\"1474138098425135285\\", \\"content\\": \\";purge 10\\", \\"created_at\\": \\"2026-02-19T20:18:30.826000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 20:18:31.025603+00
57	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T20:18:31.635281+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474137512992571423\\", \\"content\\": \\";blunt hit;blunt hit\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T20:16:11.248000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137514540273807\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1203514684326805524\\", \\"name\\": \\"evict#6621\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T20:16:11.617000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137525743255594\\", \\"content\\": \\";blunt hit\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T20:16:14.288000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137526729179220\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"evict#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T20:16:14.523000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137526498234414\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1203514684326805524\\", \\"name\\": \\"evict#6621\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T20:16:14.468000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137600100139049\\", \\"content\\": \\";blunt hit\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T20:16:32.016000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137600494276790\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1203514684326805524\\", \\"name\\": \\"evict#6621\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T20:16:32.110000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137601286996114\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"evict#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T20:16:32.299000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137652767883328\\", \\"content\\": \\";blunt hit\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T20:16:44.573000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137653178925118\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1203514684326805524\\", \\"name\\": \\"evict#6621\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T20:16:44.671000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"10 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 20:18:31.635577+00
58	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T20:18:38.495017+00:00\\"}, \\"message\\": {\\"id\\": \\"1474138129597206842\\", \\"content\\": \\";purge 10\\", \\"created_at\\": \\"2026-02-19T20:18:38.258000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 20:18:38.495311+00
59	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T20:18:39.116192+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474137170477449440\\", \\"content\\": \\";blunt\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T20:14:49.586000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137338304135208\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1203514684326805524\\", \\"name\\": \\"evict#6621\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T20:15:29.599000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137396475068629\\", \\"content\\": \\";blunt hit\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T20:15:43.468000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137397397815367\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"evict#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T20:15:43.688000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474137462321316096\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1203514684326805524\\", \\"name\\": \\"evict#6621\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T20:15:59.167000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"5 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 20:18:39.116516+00
60	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_EDIT\\", \\"timestamp\\": \\"2026-02-19T21:37:33.304334+00:00\\"}, \\"message\\": {\\"id\\": \\"1474157981045362902\\", \\"jump_url\\": \\"https://discord.com/channels/1443314822182732010/1443314822971265171/1474157981045362902\\", \\"changes\\": {\\"content\\": {\\"before\\": \\"good boy\\", \\"after\\": \\"good bot\\"}, \\"attachments\\": null, \\"embeds\\": null}}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1470543411902808229\\", \\"name\\": \\"nexo.2\\", \\"display_name\\": \\"Nexo\\", \\"bot\\": false}}"	2026-02-19 21:37:33.304667+00
61	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T22:04:19.233248+00:00\\"}, \\"message\\": {\\"id\\": \\"1474164724857045145\\", \\"content\\": \\";purge 6\\", \\"created_at\\": \\"2026-02-19T22:04:19.062000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 22:04:19.233606+00
62	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T22:04:19.762870+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474164394521923655\\", \\"content\\": \\";banner <@1203514684326805524>\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T22:03:00.304000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474164395914432513\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"evict#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T22:03:00.636000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474164396145115279\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1203514684326805524\\", \\"name\\": \\"evict#6621\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T22:03:00.691000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474164517847175250\\", \\"content\\": \\";sudo banner https://cdn.discordapp.com/banners/1203514684326805524/bcc31394f05e646c21e266ca63299e2f.png?size=512\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T22:03:29.707000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474164527724626112\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"evict#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T22:03:32.062000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474164694859120805\\", \\"content\\": \\"i will fix that later\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T22:04:11.910000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"6 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 22:04:19.76316+00
63	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T22:04:38.210067+00:00\\"}, \\"message\\": {\\"id\\": \\"1474164786961846324\\", \\"content\\": \\"https://cdn.discordapp.com/banners/1203514684326805524/bcc31394f05e646c21e266ca63299e2f.png?size=512\\", \\"created_at\\": \\"2026-02-19T22:04:33.869000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 22:04:38.210369+00
64	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T22:04:43.065696+00:00\\"}, \\"message\\": {\\"id\\": \\"1474164777034186895\\", \\"content\\": \\"https://discord.com/oauth2/authorize?client_id=1203514684326805524\\", \\"created_at\\": \\"2026-02-19T22:04:31.502000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 22:04:43.065996+00
65	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T22:04:56.653021+00:00\\"}, \\"message\\": {\\"id\\": \\"1474164881791123629\\", \\"content\\": \\";purge 100\\", \\"created_at\\": \\"2026-02-19T22:04:56.478000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 22:04:56.653292+00
66	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T22:04:58.891468+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474162597938069623\\", \\"content\\": \\";vape hit\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T21:55:51.965000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474162598915080481\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1203514684326805524\\", \\"name\\": \\"evict#6621\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T21:55:52.198000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474162599514869932\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"evict#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T21:55:52.341000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474162704406286607\\", \\"content\\": \\"now they match :)\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T21:56:17.349000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474162771741638817\\", \\"content\\": \\"i just need to fix the emojis\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T21:56:33.403000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474163497930588254\\", \\"content\\": \\"Yep\\", \\"author\\": {\\"id\\": \\"1470543411902808229\\", \\"name\\": \\"nexo.2\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T21:59:26.540000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474164064665079920\\", \\"content\\": \\"the bios match too btw\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T22:01:41.660000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474164172286722232\\", \\"content\\": \\"https://discord.com/oauth2/authorize?client_id=1473751805094662398\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T22:02:07.319000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474164229689970861\\", \\"content\\": \\"https://discord.com/oauth2/authorize?client_id=1203514684326805524\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T22:02:21.005000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474164837943738408\\", \\"content\\": \\"https://discord.com/oauth2/authorize?client_id=1473751805094662398\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T22:04:46.024000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"10 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 22:04:58.891876+00
67	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T22:08:09.043200+00:00\\"}, \\"message\\": {\\"id\\": \\"1474165688645189765\\", \\"content\\": \\";purge 3\\", \\"created_at\\": \\"2026-02-19T22:08:08.847000+00:00\\", \\"attachments\\": [], \\"stickers\\": [], \\"embeds\\": []}, \\"channel\\": {\\"id\\": \\"1443314822971265171\\", \\"name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"type\\": \\"text\\"}, \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"display_name\\": \\"\\\\ud835\\\\udc0d\\\\ud835\\\\udc32\\\\ud835\\\\udc31\\\\ud835\\\\udc1e\\\\ud835\\\\udc27\\", \\"bot\\": false}}"	2026-02-19 22:08:09.045345+00
68	1443314822182732010	1443314822971265171	MESSAGE	"{\\"event\\": {\\"type\\": \\"BULK_MESSAGE_DELETE\\", \\"timestamp\\": \\"2026-02-19T22:08:10.233164+00:00\\"}, \\"target\\": {\\"channel_id\\": \\"1443314822971265171\\", \\"channel_name\\": \\"\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"channel_type\\": \\"text\\"}, \\"messages\\": [{\\"id\\": \\"1474165301535969301\\", \\"content\\": \\";invite\\", \\"author\\": {\\"id\\": \\"1435974392810307604\\", \\"name\\": \\".n.y.x.e.n.\\", \\"bot\\": false}, \\"created_at\\": \\"2026-02-19T22:06:36.553000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474165302249132144\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1473751805094662398\\", \\"name\\": \\"evict#9776\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T22:06:36.723000+00:00\\", \\"attachments\\": []}, {\\"id\\": \\"1474165301963653254\\", \\"content\\": \\"\\", \\"author\\": {\\"id\\": \\"1203514684326805524\\", \\"name\\": \\"evict#6621\\", \\"bot\\": true}, \\"created_at\\": \\"2026-02-19T22:06:36.655000+00:00\\", \\"attachments\\": []}], \\"details\\": \\"3 messages deleted in #\\\\ud83d\\\\udde8\\\\ufe0f\\\\u30fb\\\\ud835\\\\udd8c\\\\ud835\\\\udd8a\\\\ud835\\\\udd93\\\\ud835\\\\udd8a\\\\ud835\\\\udd97\\\\ud835\\\\udd86\\\\ud835\\\\udd91\\", \\"files\\": null}"	2026-02-19 22:08:10.23347+00
69	1443314822182732010	\N	MEMBER	"{\\"event\\": {\\"type\\": \\"MEMBER_ADD\\", \\"timestamp\\": \\"2026-02-20T00:07:05.039135+00:00\\"}, \\"member\\": {\\"id\\": \\"961022851517939763\\", \\"name\\": \\"joe_moma.\\", \\"display_name\\": \\"joe_moma\\", \\"bot\\": false, \\"created_at\\": \\"2022-04-05T22:01:42.743000+00:00\\", \\"joined_at\\": \\"2026-02-20T00:07:04.799611+00:00\\", \\"roles\\": [], \\"avatar_url\\": \\"https://cdn.discordapp.com/avatars/961022851517939763/561b82549c3cc4edaa952a495c4285cb.png?size=1024\\"}, \\"action\\": \\"JOIN\\", \\"details\\": {\\"new_account\\": false}}"	2026-02-20 00:07:05.049967+00
\.


--
-- Data for Name: lottery_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lottery_history (id, user_id, pot_amount, total_tickets, winner_tickets, won_at) FROM stdin;
\.


--
-- Data for Name: lovense_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lovense_config (guild_id, is_enabled, log_channel_id) FROM stdin;
\.


--
-- Data for Name: lovense_connections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lovense_connections (token, guild_id, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: lovense_consent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lovense_consent (user_id, agreed, locked) FROM stdin;
\.


--
-- Data for Name: lovense_devices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lovense_devices (guild_id, user_id, device_id, device_type, last_active) FROM stdin;
\.


--
-- Data for Name: lovense_shares; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lovense_shares (guild_id, owner_id, target_id, device_id) FROM stdin;
\.


--
-- Data for Name: member_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.member_stats (guild_id, user_id, messages, voice_hours) FROM stdin;
\.


--
-- Data for Name: message_ranks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.message_ranks (guild_id, user_id, messages, msg_rank) FROM stdin;
\.


--
-- Data for Name: mod; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mod (guild_id, channel_id, jail_id, role_id) FROM stdin;
\.


--
-- Data for Name: name_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.name_history (user_id, username, is_nickname, is_hidden, changed_at) FROM stdin;
1473751805094662398	AIO Bot	f	f	2026-02-19 15:48:25.459609+00
1470543411902808229	pinknegro | aka Nexo	f	f	2026-02-19 18:03:26.188067+00
1473751805094662398	evict | Beta	f	f	2026-02-19 19:52:12.973655+00
1473751805094662398	evict | Beta	f	f	2026-02-19 19:52:13.380577+00
1470543411902808229	Nexo	f	f	2026-02-19 21:41:32.566542+00
1289843499834937418	dplayere	f	f	2026-02-20 00:01:06.772879+00
1289843499834937418	deleted_account	f	f	2026-02-20 00:01:55.602738+00
\.


--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment (guild_id, customer_id, method, amount, transfers, paid_at) FROM stdin;
\.


--
-- Data for Name: pet_adventures; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pet_adventures (id, pet_id, adventure_type, start_time, end_time, completed) FROM stdin;
\.


--
-- Data for Name: pet_trades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pet_trades (id, pet1_id, pet2_id, user1_id, user2_id, trade_fee, trade_time) FROM stdin;
\.


--
-- Data for Name: pets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pets (pet_id, owner_id, name, type, rarity, level, xp, hunger, happiness, active) FROM stdin;
\.


--
-- Data for Name: pingonjoin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pingonjoin (channel_id, guild_id) FROM stdin;
\.


--
-- Data for Name: poll_votes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.poll_votes (vote_id, poll_id, user_id, choice_ids) FROM stdin;
\.


--
-- Data for Name: polls; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.polls (poll_id, guild_id, channel_id, message_id, creator_id, title, description, choices, settings, is_active, ends_at, created_at) FROM stdin;
\.


--
-- Data for Name: prefix; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.prefix (guild_id, prefix) FROM stdin;
\.


--
-- Data for Name: prefixex; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.prefixex (guild_id, prefix) FROM stdin;
\.


--
-- Data for Name: publisher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.publisher (guild_id, channel_id) FROM stdin;
\.


--
-- Data for Name: pubsub; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pubsub (id, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: quoter; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoter (guild_id, channel_id, emoji, embeds) FROM stdin;
\.


--
-- Data for Name: reaction_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reaction_role (guild_id, channel_id, message_id, role_id, emoji) FROM stdin;
\.


--
-- Data for Name: reaction_trigger; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reaction_trigger (guild_id, trigger, emoji) FROM stdin;
\.


--
-- Data for Name: reminders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reminders (user_id, reminder, remind_at, invoked_at) FROM stdin;
\.


--
-- Data for Name: reskin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reskin (user_id, toggled, username, avatar) FROM stdin;
\.


--
-- Data for Name: reskin_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reskin_user (user_id, toggled, username, avatar) FROM stdin;
\.


--
-- Data for Name: response_trigger; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.response_trigger (guild_id, trigger, template, strict, reply, delete, delete_after, role_id) FROM stdin;
\.


--
-- Data for Name: role_shops; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_shops (guild_id, role_id, price, description) FROM stdin;
\.


--
-- Data for Name: roleplay; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roleplay (user_id, target_id, category, amount) FROM stdin;
\.


--
-- Data for Name: selfprefix; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.selfprefix (user_id, prefix) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settings (guild_id, prefixes, reskin, reposter_prefix, reposter_delete, reposter_embed, transcription, welcome_removal, booster_role_base_id, booster_role_include_ids, lock_role_id, lock_ignore_ids, log_ignore_ids, reassign_ignore_ids, reassign_roles, invoke_kick, invoke_ban, invoke_unban, invoke_timeout, invoke_untimeout, invoke_play, play_panel, play_deletion, safesearch_level, author) FROM stdin;
1465825967770566752	{}	f	t	f	t	f	f	\N	{}	\N	{}	{}	{}	f	\N	\N	\N	\N	\N	\N	t	f	strict	\N
1443314822182732010	{}	f	t	f	t	f	f	\N	{}	\N	{}	{}	{}	f	\N	\N	\N	\N	\N	\N	t	f	strict	\N
\.


--
-- Data for Name: shop_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shop_items (item_id, name, description, price, effect_type, effect_value, duration, effect_description, effect_example) FROM stdin;
1	Lucky Charm	Increases gambling win chances by 50% for 24 hours	50000	gambling_luck	1.5	24	🎲 **Gambling**\n• Win chance increased by {boost_percent}%\n• Duration: {duration}	"{\\"base\\": 50, \\"format\\": \\"Normal coin flip: {base}% chance\\\\nWith {name}: {boosted}% chance\\"}"
2	Money Magnet	Increases all earnings by 25% for 12 hours	75000	earnings_boost	1.25	12	💰 **All Earnings**\n• Increased by {boost_percent}%\n• Duration: {duration}	"{\\"base\\": 1000, \\"format\\": \\"Normal earnings: {base:,} coins\\\\nWith {name}: {boosted:,} coins\\"}"
3	Golden Ticket	Doubles your next gambling win (one-time use)	100000	next_gamble_multiplier	2	\N	\N	\N
4	Royal Pass	Access to high-stakes gambling tables for 48 hours	250000	high_stakes_access	1	48	\N	\N
5	Business Booster	Increases business revenue by 40% for 24 hours	150000	business_boost	1.399999999999999911182158029987476766109466552734375	24	\N	\N
6	Jackpot Jewel	10% chance for 5x payout on your next win	200000	jackpot_chance	5	\N	\N	\N
7	Daily Doubler	Doubles your next daily reward	25000	daily_boost	2	\N	\N	\N
8	Work Whistle	Reduces work command cooldown by 50% for 12 hours	40000	work_cooldown	0.5	12	\N	\N
9	Rich Ritual	All earnings go straight to bank for 6 hours	30000	auto_bank	1	6	\N	\N
10	Midas Touch	15% chance to double any earnings for 24 hours	125000	random_double	2	24	\N	\N
\.


--
-- Data for Name: shutup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shutup (guild_id, user_id) FROM stdin;
\.


--
-- Data for Name: social_links; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.social_links (id, user_id, type, url) FROM stdin;
\.


--
-- Data for Name: socials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.socials (user_id, bio, profile_image, last_avatar, last_background, background_url, audio_url, audio_title, show_friends, show_activity, click_enabled, click_text, discord_guild, glass_effect, profile_color, linear_color, domains, verified_domains) FROM stdin;
\.


--
-- Data for Name: socials_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.socials_details (user_id, friends) FROM stdin;
\.


--
-- Data for Name: socials_gradients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.socials_gradients (id, user_id, element, color, "position") FROM stdin;
\.


--
-- Data for Name: socials_saved_colors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.socials_saved_colors (user_id, name, color, type) FROM stdin;
\.


--
-- Data for Name: socials_saved_gradients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.socials_saved_gradients (id, user_id, name, color, "position") FROM stdin;
\.


--
-- Data for Name: starboard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.starboard (guild_id, channel_id, self_star, threshold, emoji, color) FROM stdin;
\.


--
-- Data for Name: starboard_entry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.starboard_entry (guild_id, star_id, channel_id, message_id, emoji) FROM stdin;
\.


--
-- Data for Name: sticky_message; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sticky_message (guild_id, channel_id, message_id, template) FROM stdin;
\.


--
-- Data for Name: suggestion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suggestion (guild_id, channel_id, suggestion_id, author_id, blacklisted_id, thread_enabled, anonymous_allowed) FROM stdin;
\.


--
-- Data for Name: suggestion_entries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suggestion_entries (guild_id, message_id, author_id, suggestion_id, is_anonymous) FROM stdin;
\.


--
-- Data for Name: suggestion_votes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suggestion_votes (guild_id, message_id, user_id, vote_type) FROM stdin;
\.


--
-- Data for Name: tag_aliases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tag_aliases (guild_id, alias, original) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tags (guild_id, name, owner_id, template, uses, restricted_user, restricted_role) FROM stdin;
\.


--
-- Data for Name: thread; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.thread (guild_id, thread_id) FROM stdin;
\.


--
-- Data for Name: timezones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.timezones (user_id, timezone) FROM stdin;
\.


--
-- Data for Name: tracker; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tracker (guild_id, vanity_channel_id, username_channel_id) FROM stdin;
\.


--
-- Data for Name: user_cards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_cards (user_id, card_id, card_name, rarity, quantity) FROM stdin;
\.


--
-- Data for Name: user_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_items (user_id, item_id, quantity, expires_at) FROM stdin;
\.


--
-- Data for Name: user_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_transactions (id, user_id, type, amount, created_at) FROM stdin;
1	1435974392810307604	account_created	1000	2026-02-19 16:01:16.138406+00
2	1435974392810307604	daily	1000	2026-02-19 16:02:22.862004+00
3	1470543411902808229	daily	1000	2026-02-19 19:57:48.325412+00
\.


--
-- Data for Name: uwulock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.uwulock (guild_id, user_id) FROM stdin;
\.


--
-- Data for Name: vanity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vanity (guild_id, channel_id, role_id, template) FROM stdin;
\.


--
-- Data for Name: vanity_sniper; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vanity_sniper (guild_id, status, channel_id, vanities) FROM stdin;
\.


--
-- Data for Name: vape; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vape (user_id, flavor, hits) FROM stdin;
1470543411902808229	Mango	0
1435974392810307604	Watermelon	4
\.


--
-- Data for Name: warn_actions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warn_actions (guild_id, threshold, action, duration) FROM stdin;
\.


--
-- Data for Name: webhook; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.webhook (identifier, guild_id, channel_id, author_id, webhook_id) FROM stdin;
\.


--
-- Data for Name: welcome_message; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.welcome_message (guild_id, channel_id, template, delete_after) FROM stdin;
\.


--
-- Data for Name: whitelist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.whitelist (guild_id, status, action) FROM stdin;
\.


--
-- Data for Name: disabled; Type: TABLE DATA; Schema: reposters; Owner: postgres
--

COPY reposters.disabled (guild_id, channel_id, reposter) FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: reskin; Owner: postgres
--

COPY reskin.config (user_id, username, avatar_url) FROM stdin;
\.


--
-- Data for Name: webhook; Type: TABLE DATA; Schema: reskin; Owner: postgres
--

COPY reskin.webhook (guild_id, channel_id, webhook_id) FROM stdin;
\.


--
-- Data for Name: filter; Type: TABLE DATA; Schema: snipe; Owner: postgres
--

COPY snipe.filter (guild_id, invites, links, words) FROM stdin;
\.


--
-- Data for Name: ignore; Type: TABLE DATA; Schema: snipe; Owner: postgres
--

COPY snipe.ignore (guild_id, user_id) FROM stdin;
\.


--
-- Data for Name: daily; Type: TABLE DATA; Schema: statistics; Owner: postgres
--

COPY statistics.daily (guild_id, date, commands_used, messages_sent, voice_minutes, member_id) FROM stdin;
1443314822182732010	2026-02-19	0	3	0	1465896339236978933
1443314822182732010	2026-02-19	0	165	0	1435974392810307604
1443314822182732010	2026-02-20	0	1	0	961022851517939763
1443314822182732010	2026-02-20	0	1	0	1435974392810307604
1443314822182732010	2026-02-19	0	35	0	1470543411902808229
1443314822182732010	2026-02-19	0	0	0	1107230799977254922
1465825967770566752	2026-02-19	0	10	0	1435974392810307604
\.


--
-- Data for Name: daily_channels; Type: TABLE DATA; Schema: statistics; Owner: postgres
--

COPY statistics.daily_channels (guild_id, channel_id, date, messages_sent) FROM stdin;
1443314822182732010	1443314822971265171	2026-02-19	202
1443314822182732010	1468002772795527255	2026-02-20	1
1443314822182732010	1443314822971265171	2026-02-20	1
1465825967770566752	1474048582259576937	2026-02-19	9
1443314822182732010	1460761162625847581	2026-02-19	1
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: stats; Owner: postgres
--

COPY stats.config (guild_id, min_word_length, count_bots, channel_whitelist, channel_blacklist) FROM stdin;
\.


--
-- Data for Name: custom_commands; Type: TABLE DATA; Schema: stats; Owner: postgres
--

COPY stats.custom_commands (guild_id, command, word, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: word_usage; Type: TABLE DATA; Schema: stats; Owner: postgres
--

COPY stats.word_usage (guild_id, user_id, word, count, last_used) FROM stdin;
1443314822182732010	1435974392810307604	translator	1	2026-02-19 16:00:15.811095+00
1443314822182732010	1470543411902808229	1443767802560512110	1	2026-02-19 17:39:39.04462+00
1443314822182732010	1435974392810307604	work	1	2026-02-19 16:02:33.729261+00
1443314822182732010	1435974392810307604	jobs	1	2026-02-19 16:02:42.946357+00
1443314822182732010	1470543411902808229	1469487720257814660	1	2026-02-19 17:39:39.04462+00
1443314822182732010	1465896339236978933	lucid	2	2026-02-19 19:55:28.767094+00
1443314822182732010	1465896339236978933	source	1	2026-02-19 19:55:28.767094+00
1443314822182732010	1465896339236978933	code	1	2026-02-19 19:55:28.767094+00
1443314822182732010	1435974392810307604	business	3	2026-02-19 16:05:28.445804+00
1443314822182732010	1435974392810307604	create	2	2026-02-19 16:05:28.445804+00
1443314822182732010	1435974392810307604	lucid	1	2026-02-19 16:05:28.445804+00
1443314822182732010	1435974392810307604	raiding	1	2026-02-19 16:05:28.445804+00
1443314822182732010	1465896339236978933	and	1	2026-02-19 19:55:28.767094+00
1443314822182732010	1435974392810307604	https	11	2026-02-19 22:08:17.361923+00
1443314822182732010	1465896339236978933	everyone	1	2026-02-19 19:55:28.767094+00
1443314822182732010	1465896339236978933	haopy	1	2026-02-19 19:55:28.767094+00
1443314822182732010	1435974392810307604	shit	2	2026-02-19 22:15:16.569281+00
1443314822182732010	1435974392810307604	howgay	2	2026-02-19 16:07:29.487149+00
1443314822182732010	1435974392810307604	1440159933776527463	1	2026-02-19 16:07:29.487149+00
1443314822182732010	1435974392810307604	ummm	1	2026-02-19 19:55:52.916412+00
1443314822182732010	1435974392810307604	fuck	2	2026-02-19 19:55:56.068908+00
1443314822182732010	1435974392810307604	67	1	2026-02-19 16:09:34.717168+00
1443314822182732010	1435974392810307604	gun	1	2026-02-19 16:10:02.39477+00
1443314822182732010	1435974392810307604	dog	1	2026-02-19 16:10:18.918894+00
1443314822182732010	1435974392810307604	shard	1	2026-02-19 16:10:36.826926+00
1443314822182732010	1435974392810307604	5	1	2026-02-19 16:10:56.813474+00
1443314822182732010	1435974392810307604	ping	1	2026-02-19 16:11:18.115491+00
1443314822182732010	1435974392810307604	shardinfo	1	2026-02-19 16:11:34.583793+00
1443314822182732010	1435974392810307604	start	3	2026-02-19 18:18:56.527536+00
1443314822182732010	1435974392810307604	s	1	2026-02-19 16:12:48.083995+00
1443314822182732010	1435974392810307604	premium	2	2026-02-19 16:25:53.235169+00
1443314822182732010	1435974392810307604	is	1	2026-02-19 19:57:41.422288+00
1443314822182732010	1435974392810307604	yet	1	2026-02-19 19:57:41.422288+00
1443314822182732010	1435974392810307604	another	1	2026-02-19 19:57:41.422288+00
1443314822182732010	1435974392810307604	owner	1	2026-02-19 16:26:25.280663+00
1443314822182732010	1435974392810307604	there	2	2026-02-19 22:08:24.48512+00
1443314822182732010	1435974392810307604	2	4	2026-02-19 16:26:32.201127+00
1443314822182732010	1435974392810307604	x	1	2026-02-19 16:29:39.240021+00
1465825967770566752	1435974392810307604	help	1	2026-02-19 18:26:25.709107+00
1443314822182732010	1435974392810307604	missing	1	2026-02-19 19:57:41.422288+00
1465825967770566752	1435974392810307604	https	4	2026-02-19 18:28:37.484057+00
1465825967770566752	1435974392810307604	discord	1	2026-02-19 18:28:37.484057+00
1465825967770566752	1435974392810307604	com	1	2026-02-19 18:28:37.484057+00
1443314822182732010	1435974392810307604	view	2	2026-02-19 16:37:05.535527+00
1465825967770566752	1435974392810307604	oauth2	1	2026-02-19 18:28:37.484057+00
1443314822182732010	1435974392810307604	reports	4	2026-02-19 16:37:31.419044+00
1465825967770566752	1435974392810307604	authorize	1	2026-02-19 18:28:37.484057+00
1443314822182732010	1435974392810307604	50	1	2026-02-19 16:38:01.334093+00
1465825967770566752	1435974392810307604	client_id	1	2026-02-19 18:28:37.484057+00
1465825967770566752	1435974392810307604	1149535834756874250	1	2026-02-19 18:28:37.484057+00
1465825967770566752	1435974392810307604	antinuke	1	2026-02-19 18:29:02.194633+00
1443314822182732010	1435974392810307604	database	1	2026-02-19 19:57:41.422288+00
1443314822182732010	1435974392810307604	nice	1	2026-02-19 19:30:47.415308+00
1465825967770566752	1435974392810307604	sudo	1	2026-02-19 16:47:19.482563+00
1465825967770566752	1435974392810307604	pfp	2	2026-02-19 16:47:19.482563+00
1443314822182732010	1435974392810307604	table	1	2026-02-19 19:57:41.422288+00
1465825967770566752	1435974392810307604	r2	3	2026-02-19 16:47:19.482563+00
1465825967770566752	1435974392810307604	evict	6	2026-02-19 16:47:19.482563+00
1465825967770566752	1435974392810307604	bot	3	2026-02-19 16:47:19.482563+00
1465825967770566752	1435974392810307604	png	3	2026-02-19 16:47:19.482563+00
1443314822182732010	1435974392810307604	sync	2	2026-02-19 17:04:12.505599+00
1443314822182732010	1435974392810307604	exportcommands	1	2026-02-19 17:06:03.649172+00
1443314822182732010	1435974392810307604	harlem	1	2026-02-19 19:36:02.859245+00
1443314822182732010	1435974392810307604	instances	3	2026-02-19 17:19:21.607257+00
1443314822182732010	1435974392810307604	better	1	2026-02-19 17:19:28.13144+00
1443314822182732010	1435974392810307604	azron	2	2026-02-19 19:36:10.40953+00
1443314822182732010	1435974392810307604	i	3	2026-02-19 22:04:12.098878+00
1443314822182732010	1435974392810307604	entitlements	2	2026-02-19 17:34:52.63706+00
1443314822182732010	1435974392810307604	skus	1	2026-02-19 17:34:52.63706+00
1443314822182732010	1435974392810307604	net	2	2026-02-19 19:36:10.40953+00
1443314822182732010	1470543411902808229	open	1	2026-02-19 19:57:58.27112+00
1443314822182732010	1470543411902808229	daily	2	2026-02-19 19:58:02.550737+00
1443314822182732010	1435974392810307604	7	1	2026-02-19 17:35:18.208019+00
1443314822182732010	1470543411902808229	wtf	1	2026-02-19 19:58:09.499669+00
1443314822182732010	1435974392810307604	deaf	1	2026-02-19 19:40:16.202904+00
1443314822182732010	1470543411902808229	am	1	2026-02-19 19:58:16.545258+00
1443314822182732010	1435974392810307604	gg	3	2026-02-19 19:40:33.135864+00
1443314822182732010	1435974392810307604	since	1	2026-02-19 19:40:33.135864+00
1443314822182732010	1470543411902808229	blunt	10	2026-02-19 21:18:15.04266+00
1443314822182732010	1435974392810307604	4	6	2026-02-19 19:52:54.519507+00
1443314822182732010	1435974392810307604	hit	26	2026-02-19 22:06:23.757669+00
1443314822182732010	1435974392810307604	purge	23	2026-02-19 22:08:08.902149+00
1443314822182732010	1435974392810307604	sudo	11	2026-02-19 22:03:29.762648+00
1443314822182732010	1435974392810307604	here	1	2026-02-19 19:53:23.345943+00
1443314822182732010	1465896339236978933	no	1	2026-02-19 19:53:42.273583+00
1443314822182732010	1465896339236978933	bro	1	2026-02-19 19:53:55.066505+00
1443314822182732010	1465896339236978933	is	1	2026-02-19 19:53:55.066505+00
1443314822182732010	1465896339236978933	doing	1	2026-02-19 19:53:55.066505+00
1443314822182732010	1465896339236978933	anything	1	2026-02-19 19:53:55.066505+00
1443314822182732010	1465896339236978933	but	1	2026-02-19 19:53:55.066505+00
1443314822182732010	1465896339236978933	work	1	2026-02-19 19:53:55.066505+00
1443314822182732010	1465896339236978933	on	1	2026-02-19 19:53:55.066505+00
1443314822182732010	1470543411902808229	cool	1	2026-02-19 19:54:07.373004+00
1443314822182732010	1470543411902808229	xd	1	2026-02-19 19:54:29.123046+00
1443314822182732010	1465896339236978933	release	1	2026-02-19 19:55:28.767094+00
1443314822182732010	1465896339236978933	the	1	2026-02-19 19:55:28.767094+00
1443314822182732010	1470543411902808229	so	1	2026-02-19 19:58:16.545258+00
1443314822182732010	1470543411902808229	confused	1	2026-02-19 19:58:16.545258+00
1443314822182732010	1435974392810307604	6	3	2026-02-19 22:04:19.107592+00
1443314822182732010	1435974392810307604	daily	4	2026-02-19 20:11:39.653305+00
1443314822182732010	1435974392810307604	fixed	1	2026-02-19 20:11:50.043197+00
1443314822182732010	1435974392810307604	it	1	2026-02-19 20:11:50.043197+00
1443314822182732010	1435974392810307604	light	1	2026-02-19 20:15:29.493468+00
1443314822182732010	1470543411902808229	i	2	2026-02-19 21:16:47.242972+00
1443314822182732010	1435974392810307604	20	1	2026-02-19 20:18:16.011665+00
1443314822182732010	1435974392810307604	10	2	2026-02-19 20:18:38.341304+00
1443314822182732010	1435974392810307604	3	3	2026-02-19 22:08:08.902149+00
1443314822182732010	1470543411902808229	hit	4	2026-02-19 21:18:15.04266+00
1443314822182732010	1470543411902808229	n	2	2026-02-19 20:28:16.797838+00
1443314822182732010	1470543411902808229	y	1	2026-02-19 20:28:16.797838+00
1443314822182732010	1470543411902808229	light	2	2026-02-19 21:17:03.7067+00
1443314822182732010	1435974392810307604	emojis	2	2026-02-19 21:56:33.458159+00
1443314822182732010	1435974392810307604	discord	10	2026-02-19 22:08:17.361923+00
1443314822182732010	1435974392810307604	help	21	2026-02-20 12:31:12.429011+00
1443314822182732010	1470543411902808229	x	1	2026-02-19 20:28:16.797838+00
1443314822182732010	1470543411902808229	e	1	2026-02-19 20:28:16.797838+00
1443314822182732010	1470543411902808229	no	1	2026-02-19 20:28:23.217099+00
1443314822182732010	1435974392810307604	fix	2	2026-02-19 22:04:12.098878+00
1443314822182732010	1435974392810307604	that	1	2026-02-19 22:04:12.098878+00
1443314822182732010	1435974392810307604	later	1	2026-02-19 22:04:12.098878+00
1443314822182732010	1470543411902808229	wow	1	2026-02-19 21:16:39.632776+00
1443314822182732010	1470543411902808229	see	1	2026-02-19 21:16:47.242972+00
1443314822182732010	1470543411902808229	how	1	2026-02-19 21:16:47.242972+00
1443314822182732010	1470543411902808229	steal	2	2026-02-19 21:16:54.824933+00
1443314822182732010	1470543411902808229	1435974392810307604	1	2026-02-19 21:16:54.824933+00
1443314822182732010	1435974392810307604	cdn	2	2026-02-19 22:04:33.964633+00
1443314822182732010	1470543411902808229	pepe_devil	2	2026-02-19 21:17:28.985877+00
1443314822182732010	1470543411902808229	https	1	2026-02-19 21:17:28.985877+00
1443314822182732010	1470543411902808229	cdn	1	2026-02-19 21:17:28.985877+00
1443314822182732010	1470543411902808229	discordapp	1	2026-02-19 21:17:28.985877+00
1443314822182732010	1470543411902808229	com	1	2026-02-19 21:17:28.985877+00
1443314822182732010	1470543411902808229	emojis	1	2026-02-19 21:17:28.985877+00
1443314822182732010	1470543411902808229	1474056733923082343	1	2026-02-19 21:17:28.985877+00
1443314822182732010	1470543411902808229	webp	1	2026-02-19 21:17:28.985877+00
1443314822182732010	1470543411902808229	size	1	2026-02-19 21:17:28.985877+00
1443314822182732010	1470543411902808229	48	1	2026-02-19 21:17:28.985877+00
1443314822182732010	1470543411902808229	name	1	2026-02-19 21:17:28.985877+00
1443314822182732010	1470543411902808229	lossless	1	2026-02-19 21:17:28.985877+00
1443314822182732010	1470543411902808229	true	1	2026-02-19 21:17:28.985877+00
1443314822182732010	1435974392810307604	discordapp	2	2026-02-19 22:04:33.964633+00
1443314822182732010	1435974392810307604	steal	4	2026-02-19 21:17:43.390458+00
1443314822182732010	1435974392810307604	banners	2	2026-02-19 22:04:33.964633+00
1443314822182732010	1435974392810307604	pass	1	2026-02-19 21:18:00.910338+00
1443314822182732010	1435974392810307604	1470543411902808229	4	2026-02-19 21:18:00.910338+00
1443314822182732010	1470543411902808229	yay	1	2026-02-19 21:18:06.984283+00
1443314822182732010	1470543411902808229	why	1	2026-02-19 21:18:24.116078+00
1443314822182732010	1470543411902808229	is	2	2026-02-19 21:18:24.116078+00
1443314822182732010	1470543411902808229	it	2	2026-02-19 21:18:24.116078+00
1443314822182732010	1470543411902808229	2	1	2026-02-19 21:18:24.116078+00
1443314822182732010	1470543411902808229	bots	1	2026-02-19 21:18:24.116078+00
1443314822182732010	1435974392810307604	bcc31394f05e646c21e266ca63299e2f	2	2026-02-19 22:04:33.964633+00
1443314822182732010	1435974392810307604	flavor	1	2026-02-19 21:18:54.765019+00
1443314822182732010	1435974392810307604	watermelon	2	2026-02-19 21:18:54.765019+00
1443314822182732010	1435974392810307604	png	2	2026-02-19 22:04:33.964633+00
1443314822182732010	1435974392810307604	size	2	2026-02-19 22:04:33.964633+00
1443314822182732010	1435974392810307604	noice	1	2026-02-19 21:19:40.951412+00
1443314822182732010	1435974392810307604	512	2	2026-02-19 22:04:33.964633+00
1443314822182732010	1470543411902808229	blueberry	1	2026-02-19 21:37:26.731781+00
1443314822182732010	1470543411902808229	good	1	2026-02-19 21:37:31.29581+00
1443314822182732010	1470543411902808229	boy	1	2026-02-19 21:37:31.29581+00
1443314822182732010	1435974392810307604	flavors	1	2026-02-19 21:51:43.70931+00
1443314822182732010	1470543411902808229	mangp	1	2026-02-19 21:52:25.036022+00
1443314822182732010	1470543411902808229	shut	1	2026-02-19 21:52:33.319036+00
1443314822182732010	1470543411902808229	flavor	3	2026-02-19 21:52:39.451813+00
1443314822182732010	1470543411902808229	mango	1	2026-02-19 21:52:39.451813+00
1443314822182732010	1470543411902808229	vape	5	2026-02-19 21:52:43.561464+00
1443314822182732010	1435974392810307604	now	1	2026-02-19 21:56:17.440943+00
1443314822182732010	1435974392810307604	they	1	2026-02-19 21:56:17.440943+00
1443314822182732010	1435974392810307604	just	1	2026-02-19 21:56:33.458159+00
1443314822182732010	1435974392810307604	need	1	2026-02-19 21:56:33.458159+00
1443314822182732010	1435974392810307604	to	1	2026-02-19 21:56:33.458159+00
1443314822182732010	1470543411902808229	yep	1	2026-02-19 21:59:26.659903+00
1443314822182732010	1435974392810307604	the	2	2026-02-19 22:01:41.747488+00
1443314822182732010	1435974392810307604	bios	1	2026-02-19 22:01:41.747488+00
1443314822182732010	1435974392810307604	match	2	2026-02-19 22:01:41.747488+00
1443314822182732010	1435974392810307604	too	1	2026-02-19 22:01:41.747488+00
1443314822182732010	1435974392810307604	btw	1	2026-02-19 22:01:41.747488+00
1443314822182732010	1435974392810307604	100	1	2026-02-19 22:04:56.529615+00
1443314822182732010	1435974392810307604	vape	9	2026-02-19 22:06:23.757669+00
1443314822182732010	1435974392810307604	banner	2	2026-02-19 22:03:29.762648+00
1443314822182732010	1435974392810307604	will	1	2026-02-19 22:04:12.098878+00
1443314822182732010	1435974392810307604	invite	1	2026-02-19 22:06:36.601636+00
1443314822182732010	1435974392810307604	1203514684326805524	6	2026-02-19 22:08:16.25849+00
1443314822182732010	1435974392810307604	com	9	2026-02-19 22:08:17.361923+00
1443314822182732010	1435974392810307604	oauth2	7	2026-02-19 22:08:17.361923+00
1443314822182732010	1435974392810307604	authorize	7	2026-02-19 22:08:17.361923+00
1443314822182732010	1435974392810307604	client_id	7	2026-02-19 22:08:17.361923+00
1443314822182732010	1435974392810307604	1473751805094662398	5	2026-02-19 22:08:17.361923+00
1443314822182732010	1435974392810307604	blunt	32	2026-02-19 22:15:01.579104+00
1443314822182732010	1435974392810307604	oh	1	2026-02-19 22:15:11.169539+00
1443314822182732010	961022851517939763	l	1	2026-02-20 00:07:57.443742+00
1443314822182732010	961022851517939763	blowjob	1	2026-02-20 00:07:57.443742+00
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: streaks; Owner: postgres
--

COPY streaks.config (guild_id, channel_id, notification_channel_id, streak_emoji, image_only) FROM stdin;
\.


--
-- Data for Name: restore_log; Type: TABLE DATA; Schema: streaks; Owner: postgres
--

COPY streaks.restore_log (id, guild_id, user_id, restored_by, previous_streak, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: streaks; Owner: postgres
--

COPY streaks.users (guild_id, user_id, current_streak, highest_streak, last_streak_time, total_images_sent, restores_available) FROM stdin;
\.


--
-- Data for Name: button; Type: TABLE DATA; Schema: ticket; Owner: postgres
--

COPY ticket.button (identifier, guild_id, template, category_id, topic) FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: ticket; Owner: postgres
--

COPY ticket.config (guild_id, channel_id, message_id, staff_ids, blacklisted_ids, channel_name) FROM stdin;
\.


--
-- Data for Name: open; Type: TABLE DATA; Schema: ticket; Owner: postgres
--

COPY ticket.open (identifier, guild_id, channel_id, user_id) FROM stdin;
\.


--
-- Data for Name: message; Type: TABLE DATA; Schema: timer; Owner: postgres
--

COPY timer.message (guild_id, channel_id, template, "interval", next_trigger) FROM stdin;
\.


--
-- Data for Name: purge; Type: TABLE DATA; Schema: timer; Owner: postgres
--

COPY timer.purge (guild_id, channel_id, "interval", next_trigger, method) FROM stdin;
\.


--
-- Data for Name: username; Type: TABLE DATA; Schema: track; Owner: postgres
--

COPY track.username (username, user_ids) FROM stdin;
\.


--
-- Data for Name: vanity; Type: TABLE DATA; Schema: track; Owner: postgres
--

COPY track.vanity (vanity, user_ids) FROM stdin;
\.


--
-- Data for Name: channels; Type: TABLE DATA; Schema: transcribe; Owner: postgres
--

COPY transcribe.channels (guild_id, channel_id, added_at) FROM stdin;
\.


--
-- Data for Name: rate_limit; Type: TABLE DATA; Schema: transcribe; Owner: postgres
--

COPY transcribe.rate_limit (guild_id, channel_id, last_used, uses) FROM stdin;
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: verification; Owner: postgres
--

COPY verification.logs (id, guild_id, user_id, session_id, event_type, details, created_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: verification; Owner: postgres
--

COPY verification.sessions (session_id, guild_id, user_id, ip_address, created_at, expires_at, completed, failed_attempts) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: verification; Owner: postgres
--

COPY verification.settings (guild_id, enabled, level, methods, timeout, ip_limit, vpn_check, private_tab_check, log_channel_id) FROM stdin;
\.


--
-- Data for Name: channels; Type: TABLE DATA; Schema: voice; Owner: postgres
--

COPY voice.channels (guild_id, channel_id, owner_id) FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: voice; Owner: postgres
--

COPY voice.config (guild_id, category_id, channel_id, bitrate, name, status) FROM stdin;
\.


--
-- Data for Name: channels; Type: TABLE DATA; Schema: voicemaster; Owner: postgres
--

COPY voicemaster.channels (guild_id, channel_id, owner_id) FROM stdin;
\.


--
-- Data for Name: configuration; Type: TABLE DATA; Schema: voicemaster; Owner: postgres
--

COPY voicemaster.configuration (guild_id, category_id, interface_id, channel_id, role_id, region, bitrate) FROM stdin;
\.


--
-- Name: playlist_tracks_id_seq; Type: SEQUENCE SET; Schema: audio; Owner: postgres
--

SELECT pg_catalog.setval('audio.playlist_tracks_id_seq', 1, false);


--
-- Name: playlists_id_seq; Type: SEQUENCE SET; Schema: audio; Owner: postgres
--

SELECT pg_catalog.setval('audio.playlists_id_seq', 1, false);


--
-- Name: recently_played_id_seq; Type: SEQUENCE SET; Schema: audio; Owner: postgres
--

SELECT pg_catalog.setval('audio.recently_played_id_seq', 1, false);


--
-- Name: media_id_seq; Type: SEQUENCE SET; Schema: auto; Owner: postgres
--

SELECT pg_catalog.setval('auto.media_id_seq', 1, false);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: economy; Owner: postgres
--

SELECT pg_catalog.setval('economy.transactions_id_seq', 1, false);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: economy_schema; Owner: postgres
--

SELECT pg_catalog.setval('economy_schema.transactions_id_seq', 1, false);


--
-- Name: moderation_id_seq; Type: SEQUENCE SET; Schema: history; Owner: postgres
--

SELECT pg_catalog.setval('history.moderation_id_seq', 1, false);


--
-- Name: commands_id_seq; Type: SEQUENCE SET; Schema: invoke_history; Owner: postgres
--

SELECT pg_catalog.setval('invoke_history.commands_id_seq', 143, true);


--
-- Name: history_id_seq; Type: SEQUENCE SET; Schema: music; Owner: postgres
--

SELECT pg_catalog.setval('music.history_id_seq', 1, false);


--
-- Name: playlist_tracks_id_seq; Type: SEQUENCE SET; Schema: music; Owner: postgres
--

SELECT pg_catalog.setval('music.playlist_tracks_id_seq', 1, false);


--
-- Name: playlists_id_seq; Type: SEQUENCE SET; Schema: music; Owner: postgres
--

SELECT pg_catalog.setval('music.playlists_id_seq', 1, false);


--
-- Name: appeals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.appeals_id_seq', 1, false);


--
-- Name: business_jobs_job_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.business_jobs_job_id_seq', 1, false);


--
-- Name: businesses_business_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.businesses_business_id_seq', 1, false);


--
-- Name: card_market_listing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.card_market_listing_id_seq', 1, false);


--
-- Name: dockets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dockets_id_seq', 1, false);


--
-- Name: gift_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gift_logs_id_seq', 1, false);


--
-- Name: job_applications_application_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.job_applications_application_id_seq', 1, false);


--
-- Name: logging_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.logging_history_id_seq', 69, true);


--
-- Name: lottery_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lottery_history_id_seq', 1, false);


--
-- Name: pet_adventures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pet_adventures_id_seq', 1, false);


--
-- Name: pet_trades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pet_trades_id_seq', 1, false);


--
-- Name: pets_pet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pets_pet_id_seq', 1, false);


--
-- Name: poll_votes_vote_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.poll_votes_vote_id_seq', 1, false);


--
-- Name: shop_items_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shop_items_item_id_seq', 300, true);


--
-- Name: social_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.social_links_id_seq', 1, false);


--
-- Name: socials_gradients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.socials_gradients_id_seq', 1, false);


--
-- Name: socials_saved_gradients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.socials_saved_gradients_id_seq', 1, false);


--
-- Name: user_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_transactions_id_seq', 3, true);


--
-- Name: restore_log_id_seq; Type: SEQUENCE SET; Schema: streaks; Owner: postgres
--

SELECT pg_catalog.setval('streaks.restore_log_id_seq', 1, false);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: verification; Owner: postgres
--

SELECT pg_catalog.setval('verification.logs_id_seq', 1, false);


--
-- Name: twitch twitch_pkey; Type: CONSTRAINT; Schema: alerts; Owner: postgres
--

ALTER TABLE ONLY alerts.twitch
    ADD CONSTRAINT twitch_pkey PRIMARY KEY (guild_id, twitch_id);


--
-- Name: config config_guild_id_key; Type: CONSTRAINT; Schema: audio; Owner: postgres
--

ALTER TABLE ONLY audio.config
    ADD CONSTRAINT config_guild_id_key UNIQUE (guild_id);


--
-- Name: playlist_tracks playlist_tracks_guild_id_user_id_playlist_url_track_uri_key; Type: CONSTRAINT; Schema: audio; Owner: postgres
--

ALTER TABLE ONLY audio.playlist_tracks
    ADD CONSTRAINT playlist_tracks_guild_id_user_id_playlist_url_track_uri_key UNIQUE (guild_id, user_id, playlist_url, track_uri);


--
-- Name: playlist_tracks playlist_tracks_pkey; Type: CONSTRAINT; Schema: audio; Owner: postgres
--

ALTER TABLE ONLY audio.playlist_tracks
    ADD CONSTRAINT playlist_tracks_pkey PRIMARY KEY (id);


--
-- Name: playlists playlists_guild_id_user_id_playlist_url_key; Type: CONSTRAINT; Schema: audio; Owner: postgres
--

ALTER TABLE ONLY audio.playlists
    ADD CONSTRAINT playlists_guild_id_user_id_playlist_url_key UNIQUE (guild_id, user_id, playlist_url);


--
-- Name: playlists playlists_pkey; Type: CONSTRAINT; Schema: audio; Owner: postgres
--

ALTER TABLE ONLY audio.playlists
    ADD CONSTRAINT playlists_pkey PRIMARY KEY (id);


--
-- Name: recently_played recently_played_pkey; Type: CONSTRAINT; Schema: audio; Owner: postgres
--

ALTER TABLE ONLY audio.recently_played
    ADD CONSTRAINT recently_played_pkey PRIMARY KEY (id);


--
-- Name: statistics statistics_pkey; Type: CONSTRAINT; Schema: audio; Owner: postgres
--

ALTER TABLE ONLY audio.statistics
    ADD CONSTRAINT statistics_pkey PRIMARY KEY (guild_id, user_id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: auto; Owner: postgres
--

ALTER TABLE ONLY auto.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: media unique_media_config; Type: CONSTRAINT; Schema: auto; Owner: postgres
--

ALTER TABLE ONLY auto.media
    ADD CONSTRAINT unique_media_config UNIQUE (guild_id, channel_id, type);


--
-- Name: disabled disabled_pkey; Type: CONSTRAINT; Schema: commands; Owner: postgres
--

ALTER TABLE ONLY commands.disabled
    ADD CONSTRAINT disabled_pkey PRIMARY KEY (guild_id, channel_id, command);


--
-- Name: ignore ignore_pkey; Type: CONSTRAINT; Schema: commands; Owner: postgres
--

ALTER TABLE ONLY commands.ignore
    ADD CONSTRAINT ignore_pkey PRIMARY KEY (guild_id, target_id);


--
-- Name: restricted restricted_pkey; Type: CONSTRAINT; Schema: commands; Owner: postgres
--

ALTER TABLE ONLY commands.restricted
    ADD CONSTRAINT restricted_pkey PRIMARY KEY (guild_id, role_id, command);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: counting; Owner: postgres
--

ALTER TABLE ONLY counting.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (guild_id);


--
-- Name: config config_guild_id_key; Type: CONSTRAINT; Schema: disboard; Owner: postgres
--

ALTER TABLE ONLY disboard.config
    ADD CONSTRAINT config_guild_id_key UNIQUE (guild_id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: economy; Owner: postgres
--

ALTER TABLE ONLY economy.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: economy_schema; Owner: postgres
--

ALTER TABLE ONLY economy_schema.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: marriages marriages_pkey; Type: CONSTRAINT; Schema: family; Owner: postgres
--

ALTER TABLE ONLY family.marriages
    ADD CONSTRAINT marriages_pkey PRIMARY KEY (user_id, partner_id);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: family; Owner: postgres
--

ALTER TABLE ONLY family.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (user_id, related_id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: family; Owner: postgres
--

ALTER TABLE ONLY family.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (user_id);


--
-- Name: instagram instagram_pkey; Type: CONSTRAINT; Schema: feeds; Owner: postgres
--

ALTER TABLE ONLY feeds.instagram
    ADD CONSTRAINT instagram_pkey PRIMARY KEY (guild_id, instagram_id);


--
-- Name: pinterest pinterest_pkey; Type: CONSTRAINT; Schema: feeds; Owner: postgres
--

ALTER TABLE ONLY feeds.pinterest
    ADD CONSTRAINT pinterest_pkey PRIMARY KEY (guild_id, pinterest_id);


--
-- Name: reddit reddit_pkey; Type: CONSTRAINT; Schema: feeds; Owner: postgres
--

ALTER TABLE ONLY feeds.reddit
    ADD CONSTRAINT reddit_pkey PRIMARY KEY (guild_id, subreddit_name);


--
-- Name: soundcloud soundcloud_pkey; Type: CONSTRAINT; Schema: feeds; Owner: postgres
--

ALTER TABLE ONLY feeds.soundcloud
    ADD CONSTRAINT soundcloud_pkey PRIMARY KEY (guild_id, soundcloud_id);


--
-- Name: tiktok tiktok_pkey; Type: CONSTRAINT; Schema: feeds; Owner: postgres
--

ALTER TABLE ONLY feeds.tiktok
    ADD CONSTRAINT tiktok_pkey PRIMARY KEY (guild_id, tiktok_id);


--
-- Name: twitter twitter_pkey; Type: CONSTRAINT; Schema: feeds; Owner: postgres
--

ALTER TABLE ONLY feeds.twitter
    ADD CONSTRAINT twitter_pkey PRIMARY KEY (guild_id, twitter_id);


--
-- Name: youtube youtube_pkey; Type: CONSTRAINT; Schema: feeds; Owner: postgres
--

ALTER TABLE ONLY feeds.youtube
    ADD CONSTRAINT youtube_pkey PRIMARY KEY (guild_id, youtube_id);


--
-- Name: authorization authorization_user_id_key; Type: CONSTRAINT; Schema: fortnite; Owner: postgres
--

ALTER TABLE ONLY fortnite."authorization"
    ADD CONSTRAINT authorization_user_id_key UNIQUE (user_id);


--
-- Name: reminder reminder_pkey; Type: CONSTRAINT; Schema: fortnite; Owner: postgres
--

ALTER TABLE ONLY fortnite.reminder
    ADD CONSTRAINT reminder_pkey PRIMARY KEY (user_id, item_id);


--
-- Name: rotation rotation_guild_id_key; Type: CONSTRAINT; Schema: fortnite; Owner: postgres
--

ALTER TABLE ONLY fortnite.rotation
    ADD CONSTRAINT rotation_guild_id_key UNIQUE (guild_id);


--
-- Name: wyr_channels wyr_channels_pkey; Type: CONSTRAINT; Schema: fun; Owner: postgres
--

ALTER TABLE ONLY fun.wyr_channels
    ADD CONSTRAINT wyr_channels_pkey PRIMARY KEY (guild_id, channel_id);


--
-- Name: moderation moderation_pkey; Type: CONSTRAINT; Schema: history; Owner: postgres
--

ALTER TABLE ONLY history.moderation
    ADD CONSTRAINT moderation_pkey PRIMARY KEY (id);


--
-- Name: commands commands_pkey; Type: CONSTRAINT; Schema: invoke_history; Owner: postgres
--

ALTER TABLE ONLY invoke_history.commands
    ADD CONSTRAINT commands_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: joindm; Owner: postgres
--

ALTER TABLE ONLY joindm.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (guild_id);


--
-- Name: albums albums_pkey; Type: CONSTRAINT; Schema: lastfm; Owner: postgres
--

ALTER TABLE ONLY lastfm.albums
    ADD CONSTRAINT albums_pkey PRIMARY KEY (user_id, artist, album);


--
-- Name: artists artists_pkey; Type: CONSTRAINT; Schema: lastfm; Owner: postgres
--

ALTER TABLE ONLY lastfm.artists
    ADD CONSTRAINT artists_pkey PRIMARY KEY (user_id, artist);


--
-- Name: config config_user_id_key; Type: CONSTRAINT; Schema: lastfm; Owner: postgres
--

ALTER TABLE ONLY lastfm.config
    ADD CONSTRAINT config_user_id_key UNIQUE (user_id);


--
-- Name: crown_updates crown_updates_pkey; Type: CONSTRAINT; Schema: lastfm; Owner: postgres
--

ALTER TABLE ONLY lastfm.crown_updates
    ADD CONSTRAINT crown_updates_pkey PRIMARY KEY (guild_id);


--
-- Name: crowns crowns_pkey; Type: CONSTRAINT; Schema: lastfm; Owner: postgres
--

ALTER TABLE ONLY lastfm.crowns
    ADD CONSTRAINT crowns_pkey PRIMARY KEY (guild_id, artist);


--
-- Name: hidden hidden_pkey; Type: CONSTRAINT; Schema: lastfm; Owner: postgres
--

ALTER TABLE ONLY lastfm.hidden
    ADD CONSTRAINT hidden_pkey PRIMARY KEY (guild_id, user_id);


--
-- Name: tracks tracks_pkey; Type: CONSTRAINT; Schema: lastfm; Owner: postgres
--

ALTER TABLE ONLY lastfm.tracks
    ADD CONSTRAINT tracks_pkey PRIMARY KEY (user_id, artist, track);


--
-- Name: config config_guild_id_key; Type: CONSTRAINT; Schema: level; Owner: postgres
--

ALTER TABLE ONLY level.config
    ADD CONSTRAINT config_guild_id_key UNIQUE (guild_id);


--
-- Name: member member_pkey; Type: CONSTRAINT; Schema: level; Owner: postgres
--

ALTER TABLE ONLY level.member
    ADD CONSTRAINT member_pkey PRIMARY KEY (guild_id, user_id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: level; Owner: postgres
--

ALTER TABLE ONLY level.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (guild_id);


--
-- Name: role role_pkey; Type: CONSTRAINT; Schema: level; Owner: postgres
--

ALTER TABLE ONLY level.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (guild_id, level);


--
-- Name: role role_role_id_key; Type: CONSTRAINT; Schema: level; Owner: postgres
--

ALTER TABLE ONLY level.role
    ADD CONSTRAINT role_role_id_key UNIQUE (role_id);


--
-- Name: history history_pkey; Type: CONSTRAINT; Schema: music; Owner: postgres
--

ALTER TABLE ONLY music.history
    ADD CONSTRAINT history_pkey PRIMARY KEY (id);


--
-- Name: playlist_tracks playlist_tracks_pkey; Type: CONSTRAINT; Schema: music; Owner: postgres
--

ALTER TABLE ONLY music.playlist_tracks
    ADD CONSTRAINT playlist_tracks_pkey PRIMARY KEY (id);


--
-- Name: playlists playlists_pkey; Type: CONSTRAINT; Schema: music; Owner: postgres
--

ALTER TABLE ONLY music.playlists
    ADD CONSTRAINT playlists_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: porn; Owner: postgres
--

ALTER TABLE ONLY porn.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (guild_id);


--
-- Name: access_tokens access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_tokens
    ADD CONSTRAINT access_tokens_pkey PRIMARY KEY (user_id);


--
-- Name: afk afk_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.afk
    ADD CONSTRAINT afk_user_id_key UNIQUE (user_id);


--
-- Name: aliases aliases_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aliases
    ADD CONSTRAINT aliases_pkey PRIMARY KEY (guild_id, name);


--
-- Name: antinuke antinuke_guild_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.antinuke
    ADD CONSTRAINT antinuke_guild_id_key UNIQUE (guild_id);


--
-- Name: antiraid antiraid_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.antiraid
    ADD CONSTRAINT antiraid_pkey PRIMARY KEY (guild_id);


--
-- Name: appeal_config appeal_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appeal_config
    ADD CONSTRAINT appeal_config_pkey PRIMARY KEY (guild_id);


--
-- Name: appeal_templates appeal_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appeal_templates
    ADD CONSTRAINT appeal_templates_pkey PRIMARY KEY (guild_id, name);


--
-- Name: appeals appeals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appeals
    ADD CONSTRAINT appeals_pkey PRIMARY KEY (id);


--
-- Name: auto_role auto_role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auto_role
    ADD CONSTRAINT auto_role_pkey PRIMARY KEY (guild_id, role_id, action);


--
-- Name: avatar_current avatar_current_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.avatar_current
    ADD CONSTRAINT avatar_current_pkey PRIMARY KEY (user_id);


--
-- Name: avatar_history_settings avatar_history_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.avatar_history_settings
    ADD CONSTRAINT avatar_history_settings_pkey PRIMARY KEY (user_id);


--
-- Name: avatar_history avatar_history_user_id_avatar_url_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.avatar_history
    ADD CONSTRAINT avatar_history_user_id_avatar_url_key UNIQUE (user_id, avatar_url);


--
-- Name: backup backup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup
    ADD CONSTRAINT backup_pkey PRIMARY KEY (key, guild_id);


--
-- Name: beta_dashboard beta_dashboard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beta_dashboard
    ADD CONSTRAINT beta_dashboard_pkey PRIMARY KEY (user_id);


--
-- Name: birthdays birthdays_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.birthdays
    ADD CONSTRAINT birthdays_user_id_key UNIQUE (user_id);


--
-- Name: blacklist blacklist_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blacklist
    ADD CONSTRAINT blacklist_user_id_key UNIQUE (user_id);


--
-- Name: blunt blunt_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blunt
    ADD CONSTRAINT blunt_pkey PRIMARY KEY (guild_id);


--
-- Name: boost_history boost_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.boost_history
    ADD CONSTRAINT boost_history_pkey PRIMARY KEY (guild_id, user_id);


--
-- Name: boost_message boost_message_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.boost_message
    ADD CONSTRAINT boost_message_pkey PRIMARY KEY (guild_id, channel_id);


--
-- Name: booster_role booster_role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booster_role
    ADD CONSTRAINT booster_role_pkey PRIMARY KEY (guild_id, user_id);


--
-- Name: boosters_lost boosters_lost_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.boosters_lost
    ADD CONSTRAINT boosters_lost_pkey PRIMARY KEY (guild_id, user_id);


--
-- Name: business_jobs business_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.business_jobs
    ADD CONSTRAINT business_jobs_pkey PRIMARY KEY (job_id);


--
-- Name: business_stats business_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.business_stats
    ADD CONSTRAINT business_stats_pkey PRIMARY KEY (business_id);


--
-- Name: businesses businesses_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.businesses
    ADD CONSTRAINT businesses_name_key UNIQUE (name);


--
-- Name: businesses businesses_owner_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.businesses
    ADD CONSTRAINT businesses_owner_id_key UNIQUE (owner_id);


--
-- Name: businesses businesses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.businesses
    ADD CONSTRAINT businesses_pkey PRIMARY KEY (business_id);


--
-- Name: card_daily card_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_daily
    ADD CONSTRAINT card_daily_pkey PRIMARY KEY (user_id);


--
-- Name: card_drop_channels card_drop_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_drop_channels
    ADD CONSTRAINT card_drop_channels_pkey PRIMARY KEY (channel_id);


--
-- Name: card_market card_market_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_market
    ADD CONSTRAINT card_market_pkey PRIMARY KEY (listing_id);


--
-- Name: clownboard_entry clownboard_entry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clownboard_entry
    ADD CONSTRAINT clownboard_entry_pkey PRIMARY KEY (guild_id, channel_id, message_id, emoji);


--
-- Name: clownboard clownboard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clownboard
    ADD CONSTRAINT clownboard_pkey PRIMARY KEY (guild_id, emoji);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (guild_id);


--
-- Name: contracts contracts_employee_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_employee_id_key UNIQUE (employee_id);


--
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (business_id, employee_id);


--
-- Name: counter counter_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.counter
    ADD CONSTRAINT counter_pkey PRIMARY KEY (guild_id, channel_id);


--
-- Name: crypto crypto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crypto
    ADD CONSTRAINT crypto_pkey PRIMARY KEY (user_id, transaction_id);


--
-- Name: daily_messages daily_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_messages
    ADD CONSTRAINT daily_messages_pkey PRIMARY KEY (guild_id, date);


--
-- Name: daily_metrics daily_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_metrics
    ADD CONSTRAINT daily_metrics_pkey PRIMARY KEY (date);


--
-- Name: daily_stats daily_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_stats
    ADD CONSTRAINT daily_stats_pkey PRIMARY KEY (guild_id, date);


--
-- Name: dalle_credits dalle_credits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dalle_credits
    ADD CONSTRAINT dalle_credits_pkey PRIMARY KEY (user_id);


--
-- Name: docket_channels docket_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.docket_channels
    ADD CONSTRAINT docket_channels_pkey PRIMARY KEY (guild_id);


--
-- Name: dockets dockets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dockets
    ADD CONSTRAINT dockets_pkey PRIMARY KEY (id);


--
-- Name: donators donators_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.donators
    ADD CONSTRAINT donators_pkey PRIMARY KEY (user_id);


--
-- Name: economy_access economy_access_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.economy_access
    ADD CONSTRAINT economy_access_pkey PRIMARY KEY (user_id);


--
-- Name: economy economy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.economy
    ADD CONSTRAINT economy_pkey PRIMARY KEY (user_id);


--
-- Name: employee_stats employee_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_stats
    ADD CONSTRAINT employee_stats_pkey PRIMARY KEY (business_id, employee_id);


--
-- Name: fake_permissions fake_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fake_permissions
    ADD CONSTRAINT fake_permissions_pkey PRIMARY KEY (guild_id, role_id, permission);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (user_id);


--
-- Name: forcenick forcenick_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forcenick
    ADD CONSTRAINT forcenick_pkey PRIMARY KEY (guild_id, user_id);


--
-- Name: gallery gallery_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gallery
    ADD CONSTRAINT gallery_pkey PRIMARY KEY (guild_id, channel_id);


--
-- Name: gift_logs gift_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gift_logs
    ADD CONSTRAINT gift_logs_pkey PRIMARY KEY (id);


--
-- Name: giveaway_settings giveaway_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.giveaway_settings
    ADD CONSTRAINT giveaway_settings_pkey PRIMARY KEY (guild_id);


--
-- Name: goodbye_message goodbye_message_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goodbye_message
    ADD CONSTRAINT goodbye_message_pkey PRIMARY KEY (guild_id, channel_id);


--
-- Name: guild_verification guild_verification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guild_verification
    ADD CONSTRAINT guild_verification_pkey PRIMARY KEY (guild_id);


--
-- Name: guildblacklist guildblacklist_guild_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guildblacklist
    ADD CONSTRAINT guildblacklist_guild_id_key UNIQUE (guild_id);


--
-- Name: hardban hardban_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hardban
    ADD CONSTRAINT hardban_pkey PRIMARY KEY (guild_id, user_id);


--
-- Name: highlights highlights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.highlights
    ADD CONSTRAINT highlights_pkey PRIMARY KEY (guild_id, user_id, word);


--
-- Name: hourly_metrics hourly_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hourly_metrics
    ADD CONSTRAINT hourly_metrics_pkey PRIMARY KEY (hour);


--
-- Name: incidents incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT incidents_pkey PRIMARY KEY (id);


--
-- Name: invite_config invite_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_config
    ADD CONSTRAINT invite_config_pkey PRIMARY KEY (guild_id);


--
-- Name: invite_rewards invite_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_rewards
    ADD CONSTRAINT invite_rewards_pkey PRIMARY KEY (guild_id, role_id);


--
-- Name: invite_stats invite_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_stats
    ADD CONSTRAINT invite_stats_pkey PRIMARY KEY (guild_id, user_id);


--
-- Name: invite_tracking invite_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_tracking
    ADD CONSTRAINT invite_tracking_pkey PRIMARY KEY (guild_id, user_id);


--
-- Name: job_applications job_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_pkey PRIMARY KEY (application_id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (user_id);


--
-- Name: logging_history logging_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logging_history
    ADD CONSTRAINT logging_history_pkey PRIMARY KEY (id);


--
-- Name: logging logging_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logging
    ADD CONSTRAINT logging_pkey PRIMARY KEY (guild_id, channel_id);


--
-- Name: lottery_history lottery_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lottery_history
    ADD CONSTRAINT lottery_history_pkey PRIMARY KEY (id);


--
-- Name: lovense_config lovense_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lovense_config
    ADD CONSTRAINT lovense_config_pkey PRIMARY KEY (guild_id);


--
-- Name: lovense_consent lovense_consent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lovense_consent
    ADD CONSTRAINT lovense_consent_pkey PRIMARY KEY (user_id);


--
-- Name: lovense_devices lovense_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lovense_devices
    ADD CONSTRAINT lovense_devices_pkey PRIMARY KEY (guild_id, user_id);


--
-- Name: member_stats member_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.member_stats
    ADD CONSTRAINT member_stats_pkey PRIMARY KEY (guild_id, user_id);


--
-- Name: message_ranks message_ranks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_ranks
    ADD CONSTRAINT message_ranks_pkey PRIMARY KEY (guild_id, user_id);


--
-- Name: payment payment_guild_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_guild_id_key UNIQUE (guild_id);


--
-- Name: pet_adventures pet_adventures_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pet_adventures
    ADD CONSTRAINT pet_adventures_pkey PRIMARY KEY (id);


--
-- Name: pet_trades pet_trades_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pet_trades
    ADD CONSTRAINT pet_trades_pkey PRIMARY KEY (id);


--
-- Name: pets pets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pets
    ADD CONSTRAINT pets_pkey PRIMARY KEY (pet_id);


--
-- Name: poll_votes poll_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_votes
    ADD CONSTRAINT poll_votes_pkey PRIMARY KEY (vote_id);


--
-- Name: poll_votes poll_votes_poll_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_votes
    ADD CONSTRAINT poll_votes_poll_id_user_id_key UNIQUE (poll_id, user_id);


--
-- Name: polls polls_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT polls_pkey PRIMARY KEY (poll_id);


--
-- Name: prefix prefix_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prefix
    ADD CONSTRAINT prefix_pkey PRIMARY KEY (guild_id);


--
-- Name: publisher publisher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.publisher
    ADD CONSTRAINT publisher_pkey PRIMARY KEY (guild_id, channel_id);


--
-- Name: pubsub pubsub_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pubsub
    ADD CONSTRAINT pubsub_id_key UNIQUE (id);


--
-- Name: quoter quoter_guild_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoter
    ADD CONSTRAINT quoter_guild_id_key UNIQUE (guild_id);


--
-- Name: reaction_role reaction_role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reaction_role
    ADD CONSTRAINT reaction_role_pkey PRIMARY KEY (guild_id, message_id, emoji);


--
-- Name: reaction_trigger reaction_trigger_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reaction_trigger
    ADD CONSTRAINT reaction_trigger_pkey PRIMARY KEY (guild_id, trigger, emoji);


--
-- Name: reskin reskin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reskin
    ADD CONSTRAINT reskin_pkey PRIMARY KEY (user_id);


--
-- Name: response_trigger response_trigger_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.response_trigger
    ADD CONSTRAINT response_trigger_pkey PRIMARY KEY (guild_id, trigger);


--
-- Name: role_shops role_shops_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_shops
    ADD CONSTRAINT role_shops_pkey PRIMARY KEY (guild_id, role_id);


--
-- Name: roleplay roleplay_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roleplay
    ADD CONSTRAINT roleplay_pkey PRIMARY KEY (user_id, target_id, category);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (guild_id);


--
-- Name: shop_items shop_items_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_items
    ADD CONSTRAINT shop_items_name_key UNIQUE (name);


--
-- Name: shop_items shop_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_items
    ADD CONSTRAINT shop_items_pkey PRIMARY KEY (item_id);


--
-- Name: social_links social_links_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_links
    ADD CONSTRAINT social_links_pkey PRIMARY KEY (id);


--
-- Name: social_links social_links_user_id_type_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.social_links
    ADD CONSTRAINT social_links_user_id_type_key UNIQUE (user_id, type);


--
-- Name: socials_gradients socials_gradients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socials_gradients
    ADD CONSTRAINT socials_gradients_pkey PRIMARY KEY (id);


--
-- Name: socials socials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socials
    ADD CONSTRAINT socials_pkey PRIMARY KEY (user_id);


--
-- Name: socials_saved_colors socials_saved_colors_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socials_saved_colors
    ADD CONSTRAINT socials_saved_colors_user_id_name_key UNIQUE (user_id, name);


--
-- Name: socials_saved_gradients socials_saved_gradients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socials_saved_gradients
    ADD CONSTRAINT socials_saved_gradients_pkey PRIMARY KEY (id);


--
-- Name: starboard_entry starboard_entry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.starboard_entry
    ADD CONSTRAINT starboard_entry_pkey PRIMARY KEY (guild_id, channel_id, message_id, emoji);


--
-- Name: starboard starboard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.starboard
    ADD CONSTRAINT starboard_pkey PRIMARY KEY (guild_id, emoji);


--
-- Name: sticky_message sticky_message_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sticky_message
    ADD CONSTRAINT sticky_message_pkey PRIMARY KEY (guild_id, channel_id);


--
-- Name: suggestion_votes suggestion_votes_message_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suggestion_votes
    ADD CONSTRAINT suggestion_votes_message_id_user_id_key UNIQUE (message_id, user_id);


--
-- Name: tag_aliases tag_aliases_guild_id_alias_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tag_aliases
    ADD CONSTRAINT tag_aliases_guild_id_alias_key UNIQUE (guild_id, alias);


--
-- Name: tags tags_guild_id_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_guild_id_name_key UNIQUE (guild_id, name);


--
-- Name: thread thread_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.thread
    ADD CONSTRAINT thread_pkey PRIMARY KEY (guild_id, thread_id);


--
-- Name: timezones timezones_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.timezones
    ADD CONSTRAINT timezones_user_id_key UNIQUE (user_id);


--
-- Name: tracker tracker_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tracker
    ADD CONSTRAINT tracker_pkey PRIMARY KEY (guild_id);


--
-- Name: user_cards user_cards_user_id_card_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_cards
    ADD CONSTRAINT user_cards_user_id_card_id_key UNIQUE (user_id, card_id);


--
-- Name: user_items user_items_user_id_item_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_items
    ADD CONSTRAINT user_items_user_id_item_id_key UNIQUE (user_id, item_id);


--
-- Name: user_transactions user_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_transactions
    ADD CONSTRAINT user_transactions_pkey PRIMARY KEY (id);


--
-- Name: vanity vanity_guild_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vanity
    ADD CONSTRAINT vanity_guild_id_key UNIQUE (guild_id);


--
-- Name: vanity_sniper vanity_sniper_guild_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vanity_sniper
    ADD CONSTRAINT vanity_sniper_guild_id_key UNIQUE (guild_id);


--
-- Name: vape vape_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vape
    ADD CONSTRAINT vape_pkey PRIMARY KEY (user_id);


--
-- Name: warn_actions warn_actions_guild_id_threshold_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warn_actions
    ADD CONSTRAINT warn_actions_guild_id_threshold_key UNIQUE (guild_id, threshold);


--
-- Name: webhook webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhook
    ADD CONSTRAINT webhook_pkey PRIMARY KEY (channel_id, webhook_id);


--
-- Name: welcome_message welcome_message_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.welcome_message
    ADD CONSTRAINT welcome_message_pkey PRIMARY KEY (guild_id, channel_id);


--
-- Name: whitelist whitelist_guild_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whitelist
    ADD CONSTRAINT whitelist_guild_id_key UNIQUE (guild_id);


--
-- Name: disabled disabled_pkey; Type: CONSTRAINT; Schema: reposters; Owner: postgres
--

ALTER TABLE ONLY reposters.disabled
    ADD CONSTRAINT disabled_pkey PRIMARY KEY (guild_id, channel_id, reposter);


--
-- Name: config config_user_id_key; Type: CONSTRAINT; Schema: reskin; Owner: postgres
--

ALTER TABLE ONLY reskin.config
    ADD CONSTRAINT config_user_id_key UNIQUE (user_id);


--
-- Name: webhook webhook_pkey; Type: CONSTRAINT; Schema: reskin; Owner: postgres
--

ALTER TABLE ONLY reskin.webhook
    ADD CONSTRAINT webhook_pkey PRIMARY KEY (guild_id, channel_id);


--
-- Name: filter filter_guild_id_key; Type: CONSTRAINT; Schema: snipe; Owner: postgres
--

ALTER TABLE ONLY snipe.filter
    ADD CONSTRAINT filter_guild_id_key UNIQUE (guild_id);


--
-- Name: ignore ignore_pkey; Type: CONSTRAINT; Schema: snipe; Owner: postgres
--

ALTER TABLE ONLY snipe.ignore
    ADD CONSTRAINT ignore_pkey PRIMARY KEY (guild_id, user_id);


--
-- Name: daily_channels daily_channels_pkey; Type: CONSTRAINT; Schema: statistics; Owner: postgres
--

ALTER TABLE ONLY statistics.daily_channels
    ADD CONSTRAINT daily_channels_pkey PRIMARY KEY (guild_id, channel_id, date);


--
-- Name: daily daily_pkey; Type: CONSTRAINT; Schema: statistics; Owner: postgres
--

ALTER TABLE ONLY statistics.daily
    ADD CONSTRAINT daily_pkey PRIMARY KEY (guild_id, date, member_id);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: stats; Owner: postgres
--

ALTER TABLE ONLY stats.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (guild_id);


--
-- Name: custom_commands custom_commands_pkey; Type: CONSTRAINT; Schema: stats; Owner: postgres
--

ALTER TABLE ONLY stats.custom_commands
    ADD CONSTRAINT custom_commands_pkey PRIMARY KEY (guild_id, command);


--
-- Name: word_usage word_usage_pkey; Type: CONSTRAINT; Schema: stats; Owner: postgres
--

ALTER TABLE ONLY stats.word_usage
    ADD CONSTRAINT word_usage_pkey PRIMARY KEY (guild_id, user_id, word);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: streaks; Owner: postgres
--

ALTER TABLE ONLY streaks.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (guild_id);


--
-- Name: restore_log restore_log_pkey; Type: CONSTRAINT; Schema: streaks; Owner: postgres
--

ALTER TABLE ONLY streaks.restore_log
    ADD CONSTRAINT restore_log_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: streaks; Owner: postgres
--

ALTER TABLE ONLY streaks.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (guild_id, user_id);


--
-- Name: button button_pkey; Type: CONSTRAINT; Schema: ticket; Owner: postgres
--

ALTER TABLE ONLY ticket.button
    ADD CONSTRAINT button_pkey PRIMARY KEY (identifier, guild_id);


--
-- Name: config config_guild_id_key; Type: CONSTRAINT; Schema: ticket; Owner: postgres
--

ALTER TABLE ONLY ticket.config
    ADD CONSTRAINT config_guild_id_key UNIQUE (guild_id);


--
-- Name: open open_pkey; Type: CONSTRAINT; Schema: ticket; Owner: postgres
--

ALTER TABLE ONLY ticket.open
    ADD CONSTRAINT open_pkey PRIMARY KEY (identifier, guild_id, user_id);


--
-- Name: message message_pkey; Type: CONSTRAINT; Schema: timer; Owner: postgres
--

ALTER TABLE ONLY timer.message
    ADD CONSTRAINT message_pkey PRIMARY KEY (guild_id, channel_id);


--
-- Name: purge purge_pkey; Type: CONSTRAINT; Schema: timer; Owner: postgres
--

ALTER TABLE ONLY timer.purge
    ADD CONSTRAINT purge_pkey PRIMARY KEY (guild_id, channel_id);


--
-- Name: username username_pkey; Type: CONSTRAINT; Schema: track; Owner: postgres
--

ALTER TABLE ONLY track.username
    ADD CONSTRAINT username_pkey PRIMARY KEY (username);


--
-- Name: vanity vanity_pkey; Type: CONSTRAINT; Schema: track; Owner: postgres
--

ALTER TABLE ONLY track.vanity
    ADD CONSTRAINT vanity_pkey PRIMARY KEY (vanity);


--
-- Name: channels channels_pkey; Type: CONSTRAINT; Schema: transcribe; Owner: postgres
--

ALTER TABLE ONLY transcribe.channels
    ADD CONSTRAINT channels_pkey PRIMARY KEY (guild_id, channel_id);


--
-- Name: rate_limit rate_limit_pkey; Type: CONSTRAINT; Schema: transcribe; Owner: postgres
--

ALTER TABLE ONLY transcribe.rate_limit
    ADD CONSTRAINT rate_limit_pkey PRIMARY KEY (guild_id, channel_id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: verification; Owner: postgres
--

ALTER TABLE ONLY verification.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: verification; Owner: postgres
--

ALTER TABLE ONLY verification.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (session_id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: verification; Owner: postgres
--

ALTER TABLE ONLY verification.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (guild_id);


--
-- Name: channels channels_pkey; Type: CONSTRAINT; Schema: voice; Owner: postgres
--

ALTER TABLE ONLY voice.channels
    ADD CONSTRAINT channels_pkey PRIMARY KEY (guild_id, channel_id);


--
-- Name: config config_guild_id_key; Type: CONSTRAINT; Schema: voice; Owner: postgres
--

ALTER TABLE ONLY voice.config
    ADD CONSTRAINT config_guild_id_key UNIQUE (guild_id);


--
-- Name: channels channels_pkey; Type: CONSTRAINT; Schema: voicemaster; Owner: postgres
--

ALTER TABLE ONLY voicemaster.channels
    ADD CONSTRAINT channels_pkey PRIMARY KEY (guild_id, channel_id);


--
-- Name: configuration configuration_pkey; Type: CONSTRAINT; Schema: voicemaster; Owner: postgres
--

ALTER TABLE ONLY voicemaster.configuration
    ADD CONSTRAINT configuration_pkey PRIMARY KEY (guild_id);


--
-- Name: albums albums_user_id_fkey; Type: FK CONSTRAINT; Schema: lastfm; Owner: postgres
--

ALTER TABLE ONLY lastfm.albums
    ADD CONSTRAINT albums_user_id_fkey FOREIGN KEY (user_id) REFERENCES lastfm.config(user_id) ON DELETE CASCADE;


--
-- Name: artists artists_user_id_fkey; Type: FK CONSTRAINT; Schema: lastfm; Owner: postgres
--

ALTER TABLE ONLY lastfm.artists
    ADD CONSTRAINT artists_user_id_fkey FOREIGN KEY (user_id) REFERENCES lastfm.config(user_id) ON DELETE CASCADE;


--
-- Name: crowns crowns_user_id_artist_fkey; Type: FK CONSTRAINT; Schema: lastfm; Owner: postgres
--

ALTER TABLE ONLY lastfm.crowns
    ADD CONSTRAINT crowns_user_id_artist_fkey FOREIGN KEY (user_id, artist) REFERENCES lastfm.artists(user_id, artist) ON DELETE CASCADE;


--
-- Name: tracks tracks_user_id_fkey; Type: FK CONSTRAINT; Schema: lastfm; Owner: postgres
--

ALTER TABLE ONLY lastfm.tracks
    ADD CONSTRAINT tracks_user_id_fkey FOREIGN KEY (user_id) REFERENCES lastfm.config(user_id) ON DELETE CASCADE;


--
-- Name: config config_guild_id_fkey; Type: FK CONSTRAINT; Schema: level; Owner: postgres
--

ALTER TABLE ONLY level.config
    ADD CONSTRAINT config_guild_id_fkey FOREIGN KEY (guild_id) REFERENCES public.settings(guild_id) ON DELETE CASCADE;


--
-- Name: member member_guild_id_fkey; Type: FK CONSTRAINT; Schema: level; Owner: postgres
--

ALTER TABLE ONLY level.member
    ADD CONSTRAINT member_guild_id_fkey FOREIGN KEY (guild_id) REFERENCES level.config(guild_id) ON DELETE CASCADE;


--
-- Name: notification notification_guild_id_fkey; Type: FK CONSTRAINT; Schema: level; Owner: postgres
--

ALTER TABLE ONLY level.notification
    ADD CONSTRAINT notification_guild_id_fkey FOREIGN KEY (guild_id) REFERENCES level.config(guild_id) ON DELETE CASCADE;


--
-- Name: role role_guild_id_fkey; Type: FK CONSTRAINT; Schema: level; Owner: postgres
--

ALTER TABLE ONLY level.role
    ADD CONSTRAINT role_guild_id_fkey FOREIGN KEY (guild_id) REFERENCES level.config(guild_id) ON DELETE CASCADE;


--
-- Name: playlist_tracks playlist_tracks_playlist_id_fkey; Type: FK CONSTRAINT; Schema: music; Owner: postgres
--

ALTER TABLE ONLY music.playlist_tracks
    ADD CONSTRAINT playlist_tracks_playlist_id_fkey FOREIGN KEY (playlist_id) REFERENCES music.playlists(id) ON DELETE CASCADE;


--
-- Name: business_jobs business_jobs_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.business_jobs
    ADD CONSTRAINT business_jobs_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(business_id) ON DELETE CASCADE;


--
-- Name: business_stats business_stats_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.business_stats
    ADD CONSTRAINT business_stats_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(business_id) ON DELETE CASCADE;


--
-- Name: clownboard_entry clownboard_entry_guild_id_emoji_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clownboard_entry
    ADD CONSTRAINT clownboard_entry_guild_id_emoji_fkey FOREIGN KEY (guild_id, emoji) REFERENCES public.clownboard(guild_id, emoji) ON DELETE CASCADE;


--
-- Name: contracts contracts_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(business_id) ON DELETE CASCADE;


--
-- Name: employee_stats employee_stats_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_stats
    ADD CONSTRAINT employee_stats_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(business_id) ON DELETE CASCADE;


--
-- Name: poll_votes poll_votes_poll_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_votes
    ADD CONSTRAINT poll_votes_poll_id_fkey FOREIGN KEY (poll_id) REFERENCES public.polls(poll_id) ON DELETE CASCADE;


--
-- Name: starboard_entry starboard_entry_guild_id_emoji_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.starboard_entry
    ADD CONSTRAINT starboard_entry_guild_id_emoji_fkey FOREIGN KEY (guild_id, emoji) REFERENCES public.starboard(guild_id, emoji) ON DELETE CASCADE;


--
-- Name: user_items user_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_items
    ADD CONSTRAINT user_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.shop_items(item_id) ON DELETE CASCADE;


--
-- Name: button button_guild_id_fkey; Type: FK CONSTRAINT; Schema: ticket; Owner: postgres
--

ALTER TABLE ONLY ticket.button
    ADD CONSTRAINT button_guild_id_fkey FOREIGN KEY (guild_id) REFERENCES ticket.config(guild_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

